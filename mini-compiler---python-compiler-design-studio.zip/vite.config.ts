import tailwindcss from '@tailwindcss/vite';
import react from '@vitejs/plugin-react';
import path from 'path';
import fs from 'fs';
import {exec, spawn} from 'child_process';
import {defineConfig, Plugin} from 'vite';

function compilerApiPlugin(): Plugin {
  return {
    name: 'compiler-api',
    configureServer(server) {
      server.middlewares.use(async (req, res, next) => {
        if (!req.url?.startsWith('/api/')) {
          return next();
        }

        // POST /api/compile
        if (req.url === '/api/compile' && req.method === 'POST') {
          let body = '';
          req.on('data', chunk => {
            body += chunk;
          });
          req.on('end', () => {
            try {
              const {code} = JSON.parse(body || '{}');
              const tempPath = path.resolve(__dirname, 'mini_compiler', '__temp_compile__.mc');
              fs.writeFileSync(tempPath, code || '', 'utf-8');

              const child = spawn('python3', [
                path.resolve(__dirname, 'mini_compiler', 'main.py'),
                tempPath,
                '--json'
              ]);

              let stdoutData = '';
              let stderrData = '';

              child.stdout.on('data', data => {
                stdoutData += data.toString();
              });

              child.stderr.on('data', data => {
                stderrData += data.toString();
              });

              child.on('close', codeExit => {
                try {
                  if (fs.existsSync(tempPath)) {
                    fs.unlinkSync(tempPath);
                  }
                } catch (e) {
                  // ignore
                }

                res.setHeader('Content-Type', 'application/json');
                try {
                  const parsed = JSON.parse(stdoutData.trim());
                  res.end(JSON.stringify(parsed));
                } catch (err) {
                  res.end(JSON.stringify({
                    success: false,
                    error_phase: 'Execution',
                    errors: [{
                      phase: 'Execution',
                      line: 1,
                      column: 1,
                      message: stderrData || stdoutData || 'Execution error'
                    }],
                    raw_stdout: stdoutData,
                    raw_stderr: stderrData
                  }));
                }
              });
            } catch (err: any) {
              res.statusCode = 400;
              res.setHeader('Content-Type', 'application/json');
              res.end(JSON.stringify({error: err.message}));
            }
          });
          return;
        }

        // GET /api/python-files
        if (req.url === '/api/python-files' && req.method === 'GET') {
          try {
            const dir = path.resolve(__dirname, 'mini_compiler');
            const fileNames = [
              'main.py',
              'lexer.py',
              'parser.py',
              'semantic.py',
              'intermediate_code.py',
              'optimizer.py',
              'code_generator.py',
              'gui.py',
              'test_cases.py',
              'README.md',
              'VIVA_QUESTIONS.md',
              'DOCUMENTATION.md',
            ];

            const files = fileNames
              .filter(name => fs.existsSync(path.join(dir, name)))
              .map(name => ({
                name,
                path: `mini_compiler/${name}`,
                content: fs.readFileSync(path.join(dir, name), 'utf-8')
              }));

            res.setHeader('Content-Type', 'application/json');
            res.end(JSON.stringify({files}));
          } catch (err: any) {
            res.statusCode = 500;
            res.setHeader('Content-Type', 'application/json');
            res.end(JSON.stringify({error: err.message}));
          }
          return;
        }

        // POST /api/run-tests
        if (req.url === '/api/run-tests' && req.method === 'POST') {
          exec('python3 mini_compiler/test_cases.py', (err, stdout, stderr) => {
            res.setHeader('Content-Type', 'application/json');
            res.end(JSON.stringify({
              success: !err,
              output: stdout || stderr
            }));
          });
          return;
        }

        next();
      });
    }
  };
}

export default defineConfig(() => {
  return {
    plugins: [react(), tailwindcss(), compilerApiPlugin()],
    resolve: {
      alias: {
        '@': path.resolve(__dirname, '.'),
      },
    },
    server: {
      // HMR is disabled in AI Studio via DISABLE_HMR env var.
      // Do not modify—file watching is disabled to prevent flickering during agent edits.
      hmr: process.env.DISABLE_HMR !== 'true',
      // Disable file watching when DISABLE_HMR is true to save CPU during agent edits.
      watch: process.env.DISABLE_HMR === 'true' ? null : {},
    },
  };
});
