# Mini Compiler – Design and Implementation Using Python

A complete, production-grade 6-phase educational compiler developed in pure Python with a professional Tkinter GUI, tailored for B.Tech Artificial Intelligence & Data Science / Computer Science & Engineering Compiler Design practicals.

---

## 📋 Table of Contents
1. [Project Overview](#project-overview)
2. [Language Grammar & Features](#language-grammar--features)
3. [The 6 Compiler Phases](#the-6-compiler-phases)
4. [Project Directory Structure](#project-directory-structure)
5. [Installation & Requirements](#installation--requirements)
6. [VS Code Execution Instructions](#vs-code-execution-instructions)
7. [Running the Tkinter GUI](#running-the-tkinter-gui)
8. [Sample Programs & Expected Phase Outputs](#sample-programs--expected-phase-outputs)
9. [Automated Test Suite (12 Tests)](#automated-test-suite-12-tests)
10. [Viva Voce Questions & Answers](#viva-voce-questions--answers)

---

## 1. Project Overview

- **Course**: B.Tech 2nd Year (AI & DS / CSE) – Compiler Design Laboratory
- **Language**: 100% Pure Python (No external C/C++ lex/yacc or ANTLR dependencies)
- **GUI Engine**: Python standard `tkinter` & `ttk` with a modern dark theme
- **Execution Target**: Register-based 32-bit Virtual Machine Simulator (R0–R7)

---

## 2. Language Grammar & Features

The Mini Compiler accepts a statically typed C-like procedural language supporting:
- **Data Types**: `int` (32-bit integer) and `float` (floating-point numerical constants).
- **Variable Declarations**: `int a = 10;`, `float pi = 3.14;`, `int c;`.
- **Arithmetic Expressions**: `+`, `-`, `*`, `/`, `%` with correct operator precedence and parentheses `(...)`.
- **Relational Comparisons**: `==`, `!=`, `<`, `<=`, `>`, `>=`.
- **Assignment Statements**: `identifier = expression;`.
- **Print Statements**: `print(expression);`.
- **Conditional Branching**: `if (condition) { ... } else { ... }`.
- **Looping Statements**: `while (condition) { ... }`.
- **Comments**: Single-line (`//` or `#`) and multi-line (`/* ... */`).

### Context-Free Grammar (BNF)
```bnf
Program        ::= StatementList EOF
StatementList  ::= Statement*
Statement      ::= VarDeclStmt
                 | AssignStmt
                 | IfStmt
                 | WhileStmt
                 | PrintStmt
                 | BlockStmt
VarDeclStmt    ::= ("int" | "float") IDENTIFIER ("=" Expression)? ";"
AssignStmt     ::= IDENTIFIER "=" Expression ";"
IfStmt         ::= "if" "(" Condition ")" Statement ("else" Statement)?
WhileStmt      ::= "while" "(" Condition ")" Statement
PrintStmt      ::= "print" "(" Expression ")" ";"
BlockStmt      ::= "{" StatementList "}"
Condition      ::= Expression RelOp Expression
RelOp          ::= "==" | "!=" | "<" | "<=" | ">" | ">="
Expression     ::= Term (("+" | "-") Term)*
Term           ::= Factor (("*" | "/" | "%") Factor)*
Factor         ::= ("+" | "-")? Primary
Primary        ::= INT_CONST | FLOAT_CONST | IDENTIFIER | "(" Expression ")"
```

---

## 3. The 6 Compiler Phases

### Phase 1: Lexical Analysis (`lexer.py`)
- Reads raw source characters and matches them against regular expression patterns and keywords.
- Emits typed tokens: `KEYWORD_INT`, `KEYWORD_FLOAT`, `KEYWORD_IF`, `KEYWORD_ELSE`, `KEYWORD_WHILE`, `KEYWORD_PRINT`, `IDENTIFIER`, `INT_CONST`, `FLOAT_CONST`, operators, and delimiters.
- Records exact **line number** and **column number** for every token.
- Detects invalid characters (e.g. `@`, `$`) and logs `LexicalError`.

### Phase 2: Syntax Analysis (`parser.py`)
- Employs a deterministic **Top-Down Recursive Descent Parser** with LL(1) lookahead.
- Enforces syntactic grammar rules, operator precedence, and parenthesization.
- Constructs an Abstract Syntax Tree (`ASTNode` hierarchy: `ProgramNode`, `VarDeclNode`, `AssignNode`, `IfNode`, `WhileNode`, `BinaryOpNode`, etc.).
- Performs panic-mode error recovery on missing semicolons or mismatched delimiters.

### Phase 3: Semantic Analysis (`semantic.py`)
- Maintains a **Scoped Symbol Table** supporting nested block scopes.
- Enforces semantic integrity:
  1. Detects **undeclared variables** before use.
  2. Detects **duplicate variable declarations** in the same scope.
  3. Enforces **type compatibility** (prevents assigning float to integer without cast).
  4. Detects compile-time **division by zero** on constant denominators.
  5. Flags uninitialized variable reads as compile-time warnings.

### Phase 4: Intermediate Code Generation (`intermediate_code.py`)
- Flattens the hierarchical AST into linear **Three-Address Code (TAC)**.
- Formats every instruction into standard **Quadruples**: `(operator, argument_1, argument_2, result)`.
- Generates unique temporary variables (`t0`, `t1`, `t2`, ...) and control-flow jump labels (`L0`, `L1`, ...).

### Phase 5: Code Optimization (`optimizer.py`)
- Applies classical machine-independent optimizations in multi-pass loops:
  1. **Constant Folding**: Evaluates constant arithmetic expressions at compile time (e.g., `t0 = 3 * 4` becomes `t0 = 12`).
  2. **Constant Propagation**: Replaces variables with their static constant values throughout basic blocks.
  3. **Common Subexpression Elimination (CSE)**: Reuses previous identical computations if operands have not changed.
  4. **Dead Code Elimination (DCE)**: Removes unused temporaries, redundant assignments (`x = x`), and unreachable code blocks.
- Emits a complete audit trail showing every optimization transformation applied.

### Phase 6: Target Code Generation (`code_generator.py`)
- Maps Three-Address Code to 32-bit register-based assembly instructions.
- Generates `.data` segment for static variables and `.text` segment for machine instructions.
- Includes a built-in **Target Machine Virtual Simulator (VM)** to execute the generated assembly and display runtime console outputs and register states.

---

## 4. Project Directory Structure

```text
mini_compiler/
│
├── __init__.py               # Python package initialization
├── main.py                   # Main driver and CLI compiler pipeline
├── lexer.py                  # Phase 1: Lexical Analyzer (Tokenizer)
├── parser.py                 # Phase 2: Recursive Descent Parser & AST
├── semantic.py               # Phase 3: Symbol Table & Semantic Checks
├── intermediate_code.py      # Phase 4: Three-Address Code & Quadruples
├── optimizer.py              # Phase 5: Constant Folding, Propagation, CSE, DCE
├── code_generator.py         # Phase 6: Target Assembly Generator & VM Simulator
├── gui.py                    # Tkinter Modern Dark-Themed Desktop Interface
├── test_cases.py             # 12 Comprehensive Automated Test Cases
├── VIVA_QUESTIONS.md         # 30+ Academic Viva Questions & Detailed Answers
└── README.md                 # Complete project documentation
```

---

## 5. Installation & Requirements

- **Python Version**: Python 3.8, 3.9, 3.10, 3.11, or 3.12.
- **Operating System**: Windows 10/11, macOS, or Linux (Ubuntu/Debian/Fedora).
- **Dependencies**: Only Python standard libraries (`tkinter`, `sys`, `os`, `re`, `argparse`, `typing`, `json`).
- On Linux (Ubuntu/Debian), ensure Tkinter is installed:
  ```bash
  sudo apt update
  sudo apt install python3-tk
  ```

---

## 6. VS Code Execution Instructions

1. Open **Visual Studio Code**.
2. Select **File > Open Folder...** and choose the `mini_compiler` folder.
3. Open a new terminal inside VS Code: ``Ctrl + ` `` (or `Terminal > New Terminal`).
4. Execute any of the following commands:

```bash
# 1. Launch the Desktop GUI
python gui.py

# 2. Run the Main CLI Compiler on a sample program
python main.py

# 3. Run all 12 Automated Test Cases
python test_cases.py

# 4. Compile a custom source file
python main.py my_program.mc

# 5. Compile direct code string with JSON output
python main.py --code "int a = 10; print(a * 2);" --json
```

---

## 7. Sample Input Programs & Expected Phase Outputs

### Sample 1: Arithmetic Precedence & Assignment
**Input Code:**
```c
int a = 10;
int b = 20;
int c;
c = a + b * 2;
print(c);
```

#### Phase 1: Lexical Analysis (Tokens)
```text
Token(KEYWORD_INT, 'int', Line:1, Col:1)
Token(IDENTIFIER, 'a', Line:1, Col:5)
Token(OP_ASSIGN, '=', Line:1, Col:7)
Token(INT_CONST, 10, Line:1, Col:9)
Token(SEMICOLON, ';', Line:1, Col:11)
...
```

#### Phase 2: Syntax Analysis (AST)
```text
Program
  ├── VarDecl: int a (Line 1)
  │   └── Literal (int): 10
  ├── VarDecl: int b (Line 2)
  │   └── Literal (int): 20
  ├── VarDecl: int c (Line 3)
  ├── Assign: c = (Line 4)
  │   └── BinaryOp ('+')
  │       ├── Variable: a
  │       └── BinaryOp ('*')
  │           ├── Variable: b
  │           └── Literal (int): 2
  └── Print (Line 5)
      └── Variable: c
```

#### Phase 3: Semantic Analysis (Symbol Table)
| Identifier | Data Type | Line Declared | Scope Level | Initialized |
|:----------:|:---------:|:-------------:|:-----------:|:-----------:|
| `a`        | `int`     | 1             | 0 (Global)  | Yes         |
| `b`        | `int`     | 2             | 0 (Global)  | Yes         |
| `c`        | `int`     | 3             | 0 (Global)  | Yes         |

#### Phase 4: Intermediate Code (TAC)
```text
000:  declare int a
001:  a = 10
002:  declare int b
003:  b = 20
004:  declare int c
005:  t0 = b * 2
006:  t1 = a + t0
007:  c = t1
008:  print c
```

#### Phase 5: Optimized Code (After Folding & Propagation)
```text
000:  declare int a
001:  a = 10
002:  declare int b
003:  b = 20
004:  declare int c
005:  c = 50
006:  print 50
```

#### Phase 6: Target Assembly Code
```assembly
SECTION .data
    a            .word 0
    b            .word 0
    c            .word 0

SECTION .text
    GLOBAL _start
_start:
    LOADI    R0, 10
    STORE    [a], R0
    LOADI    R1, 20
    STORE    [b], R1
    LOADI    R2, 50
    STORE    [c], R2
    LOADI    R2, 50
    PRINT    R2
    HALT
```
**VM Execution Output:**
```text
>> 50
Final Memory State: {'a': 10, 'b': 20, 'c': 50}
```

---

## 8. Automated Test Suite (12 Tests)

The test suite in `test_cases.py` verifies both positive cases and negative error handling:

| # | Test Name | Category | Expected Behavior |
|:-:|:---|:---|:---|
| 01 | Valid Arithmetic & Print | Positive | Output `50` |
| 02 | Invalid Token (`@invalid`) | Negative (Lexical) | Catches invalid character `@` at Line 1 |
| 03 | Missing Semicolon | Negative (Syntax) | Catches missing `;` after variable declaration |
| 04 | Undeclared Variable | Negative (Semantic) | Flags variable `b` used before declaration |
| 05 | Duplicate Variable Declaration | Negative (Semantic) | Flags variable `score` redeclared in same scope |
| 06 | Type Mismatch (`int <- float`) | Negative (Semantic) | Flags assigning float literal to `int` variable |
| 07 | Parentheses & Precedence | Positive | Output `120` |
| 08 | If-Else Branching | Positive | Output `1` |
| 09 | While Loop Accumulation | Positive | Output `15` |
| 10 | Division by Zero (`x / 0`) | Negative (Semantic) | Flags compile-time division by zero |
| 11 | Constant Folding & Propagation | Optimization | Reduces 9 instructions to 5, output `19` |
| 12 | Common Subexpression Elimination | Optimization | Reuses identical subexpression, output `42` |

---

## 9. Viva Voce Questions & Answers

See [VIVA_QUESTIONS.md](VIVA_QUESTIONS.md) for 30+ commonly asked viva questions covering:
- Lexer vs Parser
- LL(1) parsing conditions and FIRST/FOLLOW sets
- Scoped Symbol Table implementation
- Quadruples vs Triples in TAC
- Constant Folding vs Constant Propagation vs CSE vs DCE
- Register allocation and target machine architecture
