"""
=============================================================================
Phase 1: Lexical Analysis (Lexer / Scanner)
=============================================================================
Project: Mini Compiler – Design and Implementation Using Python
Author: 2nd-year B.Tech AI & Data Science
Purpose:
  Reads the raw input source code character by character, groups them into
  meaningful lexemes, and assigns a token type and token value along with
  precise line and column positions. Handles lexical errors (invalid characters).
=============================================================================
"""

import re
from typing import List, Tuple, Optional, Dict, Any


class TokenType:
    # Keywords
    KEYWORD_INT = "KEYWORD_INT"
    KEYWORD_FLOAT = "KEYWORD_FLOAT"
    KEYWORD_IF = "KEYWORD_IF"
    KEYWORD_ELSE = "KEYWORD_ELSE"
    KEYWORD_WHILE = "KEYWORD_WHILE"
    KEYWORD_PRINT = "KEYWORD_PRINT"

    # Identifiers & Literals
    IDENTIFIER = "IDENTIFIER"
    INT_CONST = "INT_CONST"
    FLOAT_CONST = "FLOAT_CONST"

    # Operators
    OP_ASSIGN = "OP_ASSIGN"          # =
    OP_PLUS = "OP_PLUS"              # +
    OP_MINUS = "OP_MINUS"            # -
    OP_MUL = "OP_MUL"                # *
    OP_DIV = "OP_DIV"                # /
    OP_MOD = "OP_MOD"                # %
    OP_EQ = "OP_EQ"                  # ==
    OP_NE = "OP_NE"                  # !=
    OP_LT = "OP_LT"                  # <
    OP_LE = "OP_LE"                  # <=
    OP_GT = "OP_GT"                  # >
    OP_GE = "OP_GE"                  # >=

    # Separators / Delimiters
    SEMICOLON = "SEMICOLON"          # ;
    COMMA = "COMMA"                  # ,
    LPAREN = "LPAREN"                # (
    RPAREN = "RPAREN"                # )
    LBRACE = "LBRACE"                # {
    RBRACE = "RBRACE"                # }

    # Special
    EOF = "EOF"
    ERROR = "ERROR"


# Map keywords to their corresponding token types
KEYWORDS: Dict[str, str] = {
    "int": TokenType.KEYWORD_INT,
    "float": TokenType.KEYWORD_FLOAT,
    "if": TokenType.KEYWORD_IF,
    "else": TokenType.KEYWORD_ELSE,
    "while": TokenType.KEYWORD_WHILE,
    "print": TokenType.KEYWORD_PRINT,
}


class Token:
    """Represents a single lexical token."""

    def __init__(self, token_type: str, value: Any, line: int, column: int):
        self.type = token_type
        self.value = value
        self.line = line
        self.column = column

    def __repr__(self) -> str:
        return f"Token({self.type}, {repr(self.value)}, Line:{self.line}, Col:{self.column})"

    def to_dict(self) -> Dict[str, Any]:
        return {
            "type": self.type,
            "value": str(self.value),
            "line": self.line,
            "column": self.column,
        }


class LexicalError:
    """Represents a lexical error (e.g. unrecognized character)."""

    def __init__(self, message: str, line: int, column: int, char: str):
        self.message = message
        self.line = line
        self.column = column
        self.char = char

    def __str__(self) -> str:
        return f"[Lexical Error] Line {self.line}, Col {self.column}: {self.message} ('{self.char}')"

    def to_dict(self) -> Dict[str, Any]:
        return {
            "phase": "Lexical",
            "message": self.message,
            "line": self.line,
            "column": self.column,
            "char": self.char,
        }


class Lexer:
    """
    Lexer for Mini Compiler.
    Scans source code and generates a stream of Token objects.
    """

    def __init__(self, source_code: str):
        self.source = source_code
        self.pos = 0
        self.length = len(source_code)
        self.line = 1
        self.column = 1
        self.tokens: List[Token] = []
        self.errors: List[LexicalError] = []

    def current_char(self) -> Optional[str]:
        """Returns the character at the current position without advancing."""
        if self.pos >= self.length:
            return None
        return self.source[self.pos]

    def peek(self, offset: int = 1) -> Optional[str]:
        """Peeks ahead by offset characters."""
        peek_pos = self.pos + offset
        if peek_pos >= self.length:
            return None
        return self.source[peek_pos]

    def advance(self) -> Optional[str]:
        """Advances pointer by 1 character and updates line/column."""
        ch = self.current_char()
        if ch is not None:
            self.pos += 1
            if ch == '\n':
                self.line += 1
                self.column = 1
            else:
                self.column += 1
        return ch

    def skip_whitespace(self) -> None:
        """Skips whitespaces (spaces, tabs, newlines, carriage returns)."""
        while self.current_char() and self.current_char().isspace():
            self.advance()

    def skip_comments(self) -> bool:
        """
        Skips single-line (// or #) and multi-line (/* ... */) comments.
        Returns True if a comment was skipped, False otherwise.
        """
        ch = self.current_char()
        if ch == '#':
            # Single line comment style #
            while self.current_char() and self.current_char() != '\n':
                self.advance()
            return True
        elif ch == '/' and self.peek() == '/':
            # Single line comment style //
            self.advance()
            self.advance()
            while self.current_char() and self.current_char() != '\n':
                self.advance()
            return True
        elif ch == '/' and self.peek() == '*':
            # Multi-line comment style /* ... */
            start_line = self.line
            start_col = self.column
            self.advance()
            self.advance()
            while self.current_char():
                if self.current_char() == '*' and self.peek() == '/':
                    self.advance()
                    self.advance()
                    return True
                self.advance()
            self.errors.append(
                LexicalError("Unterminated multi-line comment", start_line, start_col, "/*")
            )
            return True
        return False

    def read_number(self) -> Token:
        """Reads integer or floating-point numerical constant."""
        start_col = self.column
        start_line = self.line
        num_str = ""
        is_float = False

        while self.current_char() and (self.current_char().isdigit() or self.current_char() == '.'):
            if self.current_char() == '.':
                if is_float:
                    # Multiple decimal points
                    break
                is_float = True
            num_str += self.current_char()
            self.advance()

        if is_float:
            return Token(TokenType.FLOAT_CONST, float(num_str), start_line, start_col)
        else:
            return Token(TokenType.INT_CONST, int(num_str), start_line, start_col)

    def read_identifier_or_keyword(self) -> Token:
        """Reads identifiers and matches keywords."""
        start_col = self.column
        start_line = self.line
        ident_str = ""

        while self.current_char() and (self.current_char().isalnum() or self.current_char() == '_'):
            ident_str += self.current_char()
            self.advance()

        # Check if ident_str is a keyword
        if ident_str in KEYWORDS:
            return Token(KEYWORDS[ident_str], ident_str, start_line, start_col)
        else:
            return Token(TokenType.IDENTIFIER, ident_str, start_line, start_col)

    def tokenize(self) -> Tuple[List[Token], List[LexicalError]]:
        """
        Tokenizes the entire source code.
        Returns a tuple of (tokens, errors).
        """
        while self.pos < self.length:
            self.skip_whitespace()
            if self.pos >= self.length:
                break

            # Check and skip comments
            if self.skip_comments():
                continue

            ch = self.current_char()
            if ch is None:
                break

            curr_line = self.line
            curr_col = self.column

            # Numbers (integers or floats)
            if ch.isdigit():
                self.tokens.append(self.read_number())
                continue

            # Identifiers or Keywords (letters or underscore)
            if ch.isalpha() or ch == '_':
                self.tokens.append(self.read_identifier_or_keyword())
                continue

            # Two-character operators or single-character operators
            if ch == '=':
                if self.peek() == '=':
                    self.advance()
                    self.advance()
                    self.tokens.append(Token(TokenType.OP_EQ, "==", curr_line, curr_col))
                else:
                    self.advance()
                    self.tokens.append(Token(TokenType.OP_ASSIGN, "=", curr_line, curr_col))
            elif ch == '!':
                if self.peek() == '=':
                    self.advance()
                    self.advance()
                    self.tokens.append(Token(TokenType.OP_NE, "!=", curr_line, curr_col))
                else:
                    self.advance()
                    self.errors.append(LexicalError("Unexpected character '!' (did you mean '!=')?", curr_line, curr_col, "!"))
            elif ch == '<':
                if self.peek() == '=':
                    self.advance()
                    self.advance()
                    self.tokens.append(Token(TokenType.OP_LE, "<=", curr_line, curr_col))
                else:
                    self.advance()
                    self.tokens.append(Token(TokenType.OP_LT, "<", curr_line, curr_col))
            elif ch == '>':
                if self.peek() == '=':
                    self.advance()
                    self.advance()
                    self.tokens.append(Token(TokenType.OP_GE, ">=", curr_line, curr_col))
                else:
                    self.advance()
                    self.tokens.append(Token(TokenType.OP_GT, ">", curr_line, curr_col))
            elif ch == '+':
                self.advance()
                self.tokens.append(Token(TokenType.OP_PLUS, "+", curr_line, curr_col))
            elif ch == '-':
                self.advance()
                self.tokens.append(Token(TokenType.OP_MINUS, "-", curr_line, curr_col))
            elif ch == '*':
                self.advance()
                self.tokens.append(Token(TokenType.OP_MUL, "*", curr_line, curr_col))
            elif ch == '/':
                self.advance()
                self.tokens.append(Token(TokenType.OP_DIV, "/", curr_line, curr_col))
            elif ch == '%':
                self.advance()
                self.tokens.append(Token(TokenType.OP_MOD, "%", curr_line, curr_col))
            elif ch == ';':
                self.advance()
                self.tokens.append(Token(TokenType.SEMICOLON, ";", curr_line, curr_col))
            elif ch == ',':
                self.advance()
                self.tokens.append(Token(TokenType.COMMA, ",", curr_line, curr_col))
            elif ch == '(':
                self.advance()
                self.tokens.append(Token(TokenType.LPAREN, "(", curr_line, curr_col))
            elif ch == ')':
                self.advance()
                self.tokens.append(Token(TokenType.RPAREN, ")", curr_line, curr_col))
            elif ch == '{':
                self.advance()
                self.tokens.append(Token(TokenType.LBRACE, "{", curr_line, curr_col))
            elif ch == '}':
                self.advance()
                self.tokens.append(Token(TokenType.RBRACE, "}", curr_line, curr_col))
            else:
                # Invalid character token
                self.advance()
                self.errors.append(
                    LexicalError(f"Invalid or unrecognized character '{ch}'", curr_line, curr_col, ch)
                )

        # Append End-Of-File token
        self.tokens.append(Token(TokenType.EOF, "EOF", self.line, self.column))
        return self.tokens, self.errors


def tokenize_code(source: str) -> Tuple[List[Token], List[LexicalError]]:
    """Helper function to tokenize source code."""
    lexer = Lexer(source)
    return lexer.tokenize()
