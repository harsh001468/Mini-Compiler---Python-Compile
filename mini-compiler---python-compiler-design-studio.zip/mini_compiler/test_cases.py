"""
=============================================================================
Compiler Test Suite (12 Comprehensive Test Cases)
=============================================================================
Project: Mini Compiler – Design and Implementation Using Python
Author: 2nd-year B.Tech AI & Data Science
Purpose:
  Executes and verifies at least 10 required test cases covering all compiler
  phases, positive execution paths, and negative error detections:
    1. Valid program (declarations, expressions, print)
    2. Invalid token (Lexical error)
    3. Missing semicolon (Syntax error)
    4. Undeclared variable (Semantic error)
    5. Duplicate variable declaration (Semantic error)
    6. Type mismatch (Semantic error)
    7. Complex arithmetic with parentheses and precedence
    8. If-Else conditional statement
    9. While loop statement
    10. Division by zero (Semantic compile-time detection)
    11. Constant folding & propagation optimization
    12. Common subexpression elimination (CSE)
=============================================================================
"""

import sys
import os

# Ensure package root is in sys.path whether executed from root or inside mini_compiler
CURRENT_DIR = os.path.dirname(os.path.abspath(__file__))
PARENT_DIR = os.path.abspath(os.path.join(CURRENT_DIR, ".."))
if CURRENT_DIR not in sys.path:
    sys.path.insert(0, CURRENT_DIR)
if PARENT_DIR not in sys.path:
    sys.path.insert(0, PARENT_DIR)

from typing import Dict, Any, List
try:
    from mini_compiler.main import compile_pipeline
except ImportError:
    from main import compile_pipeline


TEST_CASES = [
    {
        "id": 1,
        "name": "Valid Program (Basic Arithmetic & Print)",
        "category": "Positive",
        "code": """int a = 10;
int b = 20;
int c;
c = a + b * 2;
print(c);""",
        "expected_success": True,
        "expected_output": ["50"],
        "description": "Standard arithmetic with operator precedence (* before +)."
    },
    {
        "id": 2,
        "name": "Invalid Token (Lexical Error)",
        "category": "Negative - Lexical",
        "code": """int @invalid = 100;
print(@invalid);""",
        "expected_success": False,
        "expected_phase": "Lexical Analysis",
        "description": "Unrecognized symbol '@' detected during lexical scanning."
    },
    {
        "id": 3,
        "name": "Missing Semicolon (Syntax Error)",
        "category": "Negative - Syntax",
        "code": """int x = 10
int y = 20;
print(x + y);""",
        "expected_success": False,
        "expected_phase": "Syntax Analysis",
        "description": "Missing semicolon delimiter after declaration of variable 'x'."
    },
    {
        "id": 4,
        "name": "Undeclared Variable (Semantic Error)",
        "category": "Negative - Semantic",
        "code": """int a = 15;
b = a + 5;
print(b);""",
        "expected_success": False,
        "expected_phase": "Semantic Analysis",
        "description": "Assigning to undeclared variable 'b'."
    },
    {
        "id": 5,
        "name": "Duplicate Variable Declaration (Semantic Error)",
        "category": "Negative - Semantic",
        "code": """int score = 95;
int score = 100;
print(score);""",
        "expected_success": False,
        "expected_phase": "Semantic Analysis",
        "description": "Redeclaring variable 'score' in the same scope."
    },
    {
        "id": 6,
        "name": "Type Mismatch (Semantic Error)",
        "category": "Negative - Semantic",
        "code": """int counter;
counter = 3.14159;
print(counter);""",
        "expected_success": False,
        "expected_phase": "Semantic Analysis",
        "description": "Assigning a float constant into an integer variable without casting."
    },
    {
        "id": 7,
        "name": "Complex Arithmetic with Parentheses",
        "category": "Positive",
        "code": """int x = (10 + 5) * (20 - 4) / 2;
print(x);""",
        "expected_success": True,
        "expected_output": ["120"],
        "description": "Nested parenthesized arithmetic evaluated correctly: 15 * 16 / 2 = 120."
    },
    {
        "id": 8,
        "name": "If-Else Conditional Statement",
        "category": "Positive",
        "code": """int val = 25;
int flag;
if (val > 20) {
    flag = 1;
} else {
    flag = 0;
}
print(flag);""",
        "expected_success": True,
        "expected_output": ["1"],
        "description": "Relational branching via IF_REL_GOTO and assembly CMP/JGT."
    },
    {
        "id": 9,
        "name": "While Loop (Accumulation)",
        "category": "Positive",
        "code": """int i = 1;
int sum = 0;
while (i <= 5) {
    sum = sum + i;
    i = i + 1;
}
print(sum);""",
        "expected_success": True,
        "expected_output": ["15"],
        "description": "Iterative loop accumulating sum 1+2+3+4+5 = 15."
    },
    {
        "id": 10,
        "name": "Division by Zero (Semantic Detection)",
        "category": "Negative - Semantic",
        "code": """int a = 100;
int b = a / 0;
print(b);""",
        "expected_success": False,
        "expected_phase": "Semantic Analysis",
        "description": "Compile-time detection of division by zero literal."
    },
    {
        "id": 11,
        "name": "Constant Folding & Propagation (Optimizer)",
        "category": "Optimization",
        "code": """int a = 2 + 3 * 4;
int b = a + 5;
print(b);""",
        "expected_success": True,
        "expected_output": ["19"],
        "description": "Optimizer computes 2 + 3 * 4 = 14, propagates to b = 14 + 5 = 19."
    },
    {
        "id": 12,
        "name": "Common Subexpression Elimination (CSE)",
        "category": "Optimization",
        "code": """int a = 7;
int b = 3;
int x = a * b;
int y = a * b;
print(x + y);""",
        "expected_success": True,
        "expected_output": ["42"],
        "description": "Optimizer detects duplicate computation 'a * b' and reuses result."
    },
]


def run_all_tests() -> bool:
    """Runs all 12 test cases and prints a structured verification report."""
    print("=" * 80)
    print(f"{'MINI COMPILER AUTOMATED TEST SUITE':^80}")
    print("=" * 80)

    passed_count = 0
    failed_count = 0

    for test in TEST_CASES:
        t_id = test["id"]
        t_name = test["name"]
        t_cat = test["category"]
        expected_success = test["expected_success"]

        print(f"\n[Test Case {t_id:02d}] {t_name} ({t_cat})")
        print("-" * 80)

        res = compile_pipeline(test["code"])
        is_passed = False
        notes = ""

        if expected_success:
            if res["success"]:
                expected_out = test.get("expected_output")
                actual_out = res.get("execution_output", [])
                if expected_out is None or actual_out == expected_out:
                    is_passed = True
                    notes = f"Succeeded with expected output {actual_out}."
                else:
                    is_passed = False
                    notes = f"Output mismatch: expected {expected_out}, got {actual_out}."
            else:
                is_passed = False
                notes = f"Unexpected failure in {res.get('error_phase')}: {res['errors']}"
        else:
            # Expected to fail
            if not res["success"]:
                exp_phase = test.get("expected_phase")
                actual_phase = res.get("error_phase")
                if exp_phase is None or exp_phase == actual_phase:
                    is_passed = True
                    err_msg = res["errors"][0]["message"] if res["errors"] else ""
                    notes = f"Correctly caught error in {actual_phase}: {err_msg}"
                else:
                    is_passed = False
                    notes = f"Failed in wrong phase: expected {exp_phase}, failed in {actual_phase}."
            else:
                is_passed = False
                notes = "Test was expected to trigger compile error, but compilation succeeded."

        status_str = "✅ PASS" if is_passed else "❌ FAIL"
        if is_passed:
            passed_count += 1
        else:
            failed_count += 1

        print(f"Status: {status_str}")
        print(f"Notes:  {notes}")

    print("\n" + "=" * 80)
    print(f"SUMMARY: {passed_count}/{len(TEST_CASES)} Tests Passed. ({failed_count} Failed)")
    print("=" * 80)
    return failed_count == 0


if __name__ == "__main__":
    success = run_all_tests()
    sys.exit(0 if success else 1)
