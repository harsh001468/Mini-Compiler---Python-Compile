"""
=============================================================================
Phase 4: Intermediate Code Generation (Three-Address Code & Quadruples)
=============================================================================
Project: Mini Compiler – Design and Implementation Using Python
Author: 2nd-year B.Tech AI & Data Science
Purpose:
  Translates the Abstract Syntax Tree into linear Three-Address Code (TAC).
  In TAC, every instruction has at most one operator on the right-hand side,
  requiring the introduction of compiler-generated temporary variables (t0, t1, ...)
  and control-flow labels (L0, L1, ...).
  Also produces standard Quadruple records: (operator, arg1, arg2, result).
=============================================================================
"""

from typing import List, Tuple, Dict, Any, Optional
from mini_compiler.parser import (
    ASTNode, ProgramNode, VarDeclNode, AssignNode, PrintNode,
    BlockNode, IfNode, WhileNode, BinaryOpNode, UnaryOpNode,
    LiteralNode, VarNode
)


class Quadruple:
    """Represents a single Three-Address Code quadruple: (op, arg1, arg2, result)"""

    def __init__(self, op: str, arg1: Any = "", arg2: Any = "", result: Any = ""):
        self.op = str(op)
        self.arg1 = "" if arg1 is None else str(arg1)
        self.arg2 = "" if arg2 is None else str(arg2)
        self.result = "" if result is None else str(result)

    def __repr__(self) -> str:
        return f"Quad({self.op}, {self.arg1}, {self.arg2}, {self.result})"

    def to_tac_string(self) -> str:
        """Converts quadruple into human-readable Three Address Code instruction."""
        if self.op == "LABEL":
            return f"{self.result}:"
        elif self.op == "GOTO":
            return f"goto {self.result}"
        elif self.op == "IF_GOTO":
            return f"if {self.arg1} goto {self.result}"
        elif self.op == "IF_FALSE_GOTO":
            return f"if not {self.arg1} goto {self.result}"
        elif self.op == "IF_REL_GOTO":
            # arg1: expr1, arg2: "relop expr2", result: label
            return f"if {self.arg1} {self.arg2} goto {self.result}"
        elif self.op == "=":
            return f"{self.result} = {self.arg1}"
        elif self.op in ("+", "-", "*", "/", "%", "==", "!=", "<", "<=", ">", ">="):
            return f"{self.result} = {self.arg1} {self.op} {self.arg2}"
        elif self.op == "UNARY_MINUS":
            return f"{self.result} = -{self.arg1}"
        elif self.op == "UNARY_PLUS":
            return f"{self.result} = {self.arg1}"
        elif self.op == "PRINT":
            return f"print {self.arg1}"
        elif self.op == "VAR_DECL":
            return f"declare {self.arg1} {self.result}"
        else:
            return f"{self.result} = {self.op} {self.arg1} {self.arg2}".strip()

    def to_dict(self) -> Dict[str, str]:
        return {
            "op": self.op,
            "arg1": self.arg1,
            "arg2": self.arg2,
            "result": self.result,
            "tac": self.to_tac_string()
        }


class TACGenerator:
    """
    Traverses the AST and emits linear Three-Address Code quadruples.
    """

    def __init__(self):
        self.quadruples: List[Quadruple] = []
        self.temp_count = 0
        self.label_count = 0

    def new_temp(self) -> str:
        """Allocates a fresh temporary variable (e.g. t0, t1, t2)."""
        temp_name = f"t{self.temp_count}"
        self.temp_count += 1
        return temp_name

    def new_label(self) -> str:
        """Allocates a fresh jump label (e.g. L0, L1, L2)."""
        label_name = f"L{self.label_count}"
        self.label_count += 1
        return label_name

    def emit(self, op: str, arg1: Any = "", arg2: Any = "", result: Any = "") -> Quadruple:
        """Appends a new quadruple to the instruction list."""
        quad = Quadruple(op, arg1, arg2, result)
        self.quadruples.append(quad)
        return quad

    def generate(self, ast: ProgramNode) -> Tuple[List[Quadruple], str]:
        """Generates TAC from the Program AST node."""
        self.visit(ast)
        tac_text = "\n".join(f"{i:03d}:  {q.to_tac_string()}" for i, q in enumerate(self.quadruples))
        return self.quadruples, tac_text

    def visit(self, node: Optional[ASTNode]) -> str:
        """Visitor dispatcher that returns the variable name/temp holding the result."""
        if node is None:
            return ""

        method_name = f"visit_{node.__class__.__name__}"
        visitor = getattr(self, method_name, self.generic_visit)
        return visitor(node)

    def generic_visit(self, node: ASTNode) -> str:
        return ""

    def visit_ProgramNode(self, node: ProgramNode) -> str:
        for stmt in node.statements:
            self.visit(stmt)
        return ""

    def visit_VarDeclNode(self, node: VarDeclNode) -> str:
        self.emit("VAR_DECL", node.var_type, "", node.name)
        if node.init_expr is not None:
            expr_res = self.visit(node.init_expr)
            self.emit("=", expr_res, "", node.name)
        return node.name

    def visit_AssignNode(self, node: AssignNode) -> str:
        expr_res = self.visit(node.expr)
        self.emit("=", expr_res, "", node.name)
        return node.name

    def visit_PrintNode(self, node: PrintNode) -> str:
        expr_res = self.visit(node.expr)
        self.emit("PRINT", expr_res, "", "")
        return ""

    def visit_BlockNode(self, node: BlockNode) -> str:
        for stmt in node.statements:
            self.visit(stmt)
        return ""

    def visit_IfNode(self, node: IfNode) -> str:
        then_label = self.new_label()
        end_label = self.new_label()
        else_label = self.new_label() if node.else_branch else end_label

        # Handle condition
        if isinstance(node.condition, BinaryOpNode) and node.condition.op in ("==", "!=", "<", "<=", ">", ">="):
            left_res = self.visit(node.condition.left)
            right_res = self.visit(node.condition.right)
            self.emit("IF_REL_GOTO", left_res, f"{node.condition.op} {right_res}", then_label)
        else:
            cond_res = self.visit(node.condition)
            self.emit("IF_GOTO", cond_res, "", then_label)

        # False jump: go to else or end
        self.emit("GOTO", "", "", else_label)

        # Then branch
        self.emit("LABEL", "", "", then_label)
        self.visit(node.then_branch)

        if node.else_branch:
            self.emit("GOTO", "", "", end_label)
            self.emit("LABEL", "", "", else_label)
            self.visit(node.else_branch)

        self.emit("LABEL", "", "", end_label)
        return ""

    def visit_WhileNode(self, node: WhileNode) -> str:
        start_label = self.new_label()
        body_label = self.new_label()
        end_label = self.new_label()

        self.emit("LABEL", "", "", start_label)

        # Handle condition
        if isinstance(node.condition, BinaryOpNode) and node.condition.op in ("==", "!=", "<", "<=", ">", ">="):
            left_res = self.visit(node.condition.left)
            right_res = self.visit(node.condition.right)
            self.emit("IF_REL_GOTO", left_res, f"{node.condition.op} {right_res}", body_label)
        else:
            cond_res = self.visit(node.condition)
            self.emit("IF_GOTO", cond_res, "", body_label)

        self.emit("GOTO", "", "", end_label)

        # Body
        self.emit("LABEL", "", "", body_label)
        self.visit(node.body)
        self.emit("GOTO", "", "", start_label)

        # End
        self.emit("LABEL", "", "", end_label)
        return ""

    def visit_BinaryOpNode(self, node: BinaryOpNode) -> str:
        left_res = self.visit(node.left)
        right_res = self.visit(node.right)
        temp = self.new_temp()
        self.emit(node.op, left_res, right_res, temp)
        return temp

    def visit_UnaryOpNode(self, node: UnaryOpNode) -> str:
        expr_res = self.visit(node.expr)
        temp = self.new_temp()
        if node.op == "-":
            self.emit("UNARY_MINUS", expr_res, "", temp)
        else:
            self.emit("UNARY_PLUS", expr_res, "", temp)
        return temp

    def visit_LiteralNode(self, node: LiteralNode) -> str:
        return str(node.value)

    def visit_VarNode(self, node: VarNode) -> str:
        return node.name


def generate_intermediate_code(ast: ProgramNode) -> Tuple[List[Quadruple], str]:
    """Helper function to generate TAC quadruples from an AST."""
    generator = TACGenerator()
    return generator.generate(ast)
