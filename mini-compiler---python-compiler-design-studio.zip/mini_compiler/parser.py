"""
=============================================================================
Phase 2: Syntax Analysis (Recursive Descent Parser)
=============================================================================
Project: Mini Compiler – Design and Implementation Using Python
Author: 2nd-year B.Tech AI & Data Science
Purpose:
  Consumes the token stream from the Lexer and verifies syntax according to
  the formal context-free grammar rules using top-down Recursive Descent.
  Constructs an Abstract Syntax Tree (AST) and reports syntax errors with
  line numbers and clear diagnostic messages.
=============================================================================
Grammar Rules:
  Program        -> StatementList EOF
  StatementList  -> Statement*
  Statement      -> VarDeclStmt
                  | AssignStmt
                  | IfStmt
                  | WhileStmt
                  | PrintStmt
                  | BlockStmt
  VarDeclStmt    -> ('int' | 'float') IDENTIFIER ('=' Expression)? ';'
  AssignStmt     -> IDENTIFIER '=' Expression ';'
  IfStmt         -> 'if' '(' Condition ')' Statement ('else' Statement)?
  WhileStmt      -> 'while' '(' Condition ')' Statement
  PrintStmt      -> 'print' '(' Expression ')' ';'
  BlockStmt      -> '{' StatementList '}'
  Condition      -> Expression ('==' | '!=' | '<' | '<=' | '>' | '>=') Expression
  Expression     -> Term (('+' | '-') Term)*
  Term           -> Factor (('*' | '/' | '%') Factor)*
  Factor         -> ('+' | '-')? Primary
  Primary        -> INT_CONST | FLOAT_CONST | IDENTIFIER | '(' Expression ')'
=============================================================================
"""

from typing import List, Tuple, Optional, Any, Dict, Union
from mini_compiler.lexer import Token, TokenType


# ---------------------------------------------------------------------------
# AST Node Definitions
# ---------------------------------------------------------------------------

class ASTNode:
    """Base class for all Abstract Syntax Tree nodes."""
    def __init__(self, line: int = 1, column: int = 1):
        self.line = line
        self.column = column

    def to_dict(self) -> Dict[str, Any]:
        return {"node_type": self.__class__.__name__, "line": self.line, "column": self.column}

    def to_tree_str(self, indent: str = "", is_last: bool = True) -> str:
        marker = "└── " if is_last else "├── "
        return f"{indent}{marker}{self.__class__.__name__}\n"


class ProgramNode(ASTNode):
    """Root node representing the whole program."""
    def __init__(self, statements: List[ASTNode]):
        super().__init__(line=1, column=1)
        self.statements = statements

    def to_dict(self) -> Dict[str, Any]:
        return {
            "node_type": "Program",
            "statements": [s.to_dict() for s in self.statements],
        }

    def to_tree_str(self, indent: str = "", is_last: bool = True) -> str:
        res = "Program\n"
        count = len(self.statements)
        for i, stmt in enumerate(self.statements):
            last = (i == count - 1)
            res += stmt.to_tree_str(indent + "  ", last)
        return res


class VarDeclNode(ASTNode):
    """Variable declaration: type ident [= expr];"""
    def __init__(self, var_type: str, name: str, init_expr: Optional[ASTNode], line: int, column: int):
        super().__init__(line, column)
        self.var_type = var_type
        self.name = name
        self.init_expr = init_expr

    def to_dict(self) -> Dict[str, Any]:
        return {
            "node_type": "VarDecl",
            "var_type": self.var_type,
            "name": self.name,
            "init_expr": self.init_expr.to_dict() if self.init_expr else None,
            "line": self.line,
            "column": self.column,
        }

    def to_tree_str(self, indent: str = "", is_last: bool = True) -> str:
        marker = "└── " if is_last else "├── "
        res = f"{indent}{marker}VarDecl: {self.var_type} {self.name} (Line {self.line})\n"
        if self.init_expr:
            child_indent = indent + ("    " if is_last else "│   ")
            res += self.init_expr.to_tree_str(child_indent, True)
        return res


class AssignNode(ASTNode):
    """Assignment statement: ident = expr;"""
    def __init__(self, name: str, expr: ASTNode, line: int, column: int):
        super().__init__(line, column)
        self.name = name
        self.expr = expr

    def to_dict(self) -> Dict[str, Any]:
        return {
            "node_type": "Assign",
            "name": self.name,
            "expr": self.expr.to_dict(),
            "line": self.line,
            "column": self.column,
        }

    def to_tree_str(self, indent: str = "", is_last: bool = True) -> str:
        marker = "└── " if is_last else "├── "
        res = f"{indent}{marker}Assign: {self.name} = (Line {self.line})\n"
        child_indent = indent + ("    " if is_last else "│   ")
        res += self.expr.to_tree_str(child_indent, True)
        return res


class PrintNode(ASTNode):
    """Print statement: print(expr);"""
    def __init__(self, expr: ASTNode, line: int, column: int):
        super().__init__(line, column)
        self.expr = expr

    def to_dict(self) -> Dict[str, Any]:
        return {
            "node_type": "Print",
            "expr": self.expr.to_dict(),
            "line": self.line,
            "column": self.column,
        }

    def to_tree_str(self, indent: str = "", is_last: bool = True) -> str:
        marker = "└── " if is_last else "├── "
        res = f"{indent}{marker}Print (Line {self.line})\n"
        child_indent = indent + ("    " if is_last else "│   ")
        res += self.expr.to_tree_str(child_indent, True)
        return res


class BlockNode(ASTNode):
    """Block statement: { stmt1; stmt2; ... }"""
    def __init__(self, statements: List[ASTNode], line: int, column: int):
        super().__init__(line, column)
        self.statements = statements

    def to_dict(self) -> Dict[str, Any]:
        return {
            "node_type": "Block",
            "statements": [s.to_dict() for s in self.statements],
            "line": self.line,
            "column": self.column,
        }

    def to_tree_str(self, indent: str = "", is_last: bool = True) -> str:
        marker = "└── " if is_last else "├── "
        res = f"{indent}{marker}Block ({len(self.statements)} stmts, Line {self.line})\n"
        child_indent = indent + ("    " if is_last else "│   ")
        count = len(self.statements)
        for i, stmt in enumerate(self.statements):
            res += stmt.to_tree_str(child_indent, i == count - 1)
        return res


class IfNode(ASTNode):
    """If statement: if (condition) then_stmt [else else_stmt]"""
    def __init__(self, condition: ASTNode, then_branch: ASTNode, else_branch: Optional[ASTNode], line: int, column: int):
        super().__init__(line, column)
        self.condition = condition
        self.then_branch = then_branch
        self.else_branch = else_branch

    def to_dict(self) -> Dict[str, Any]:
        return {
            "node_type": "If",
            "condition": self.condition.to_dict(),
            "then_branch": self.then_branch.to_dict(),
            "else_branch": self.else_branch.to_dict() if self.else_branch else None,
            "line": self.line,
            "column": self.column,
        }

    def to_tree_str(self, indent: str = "", is_last: bool = True) -> str:
        marker = "└── " if is_last else "├── "
        res = f"{indent}{marker}If (Line {self.line})\n"
        child_indent = indent + ("    " if is_last else "│   ")
        res += f"{child_indent}├── Condition:\n"
        res += self.condition.to_tree_str(child_indent + "│   ", True)
        res += f"{child_indent}├── Then:\n"
        res += self.then_branch.to_tree_str(child_indent + "│   ", self.else_branch is None)
        if self.else_branch:
            res += f"{child_indent}└── Else:\n"
            res += self.else_branch.to_tree_str(child_indent + "    ", True)
        return res


class WhileNode(ASTNode):
    """While loop: while (condition) body"""
    def __init__(self, condition: ASTNode, body: ASTNode, line: int, column: int):
        super().__init__(line, column)
        self.condition = condition
        self.body = body

    def to_dict(self) -> Dict[str, Any]:
        return {
            "node_type": "While",
            "condition": self.condition.to_dict(),
            "body": self.body.to_dict(),
            "line": self.line,
            "column": self.column,
        }

    def to_tree_str(self, indent: str = "", is_last: bool = True) -> str:
        marker = "└── " if is_last else "├── "
        res = f"{indent}{marker}While (Line {self.line})\n"
        child_indent = indent + ("    " if is_last else "│   ")
        res += f"{child_indent}├── Condition:\n"
        res += self.condition.to_tree_str(child_indent + "│   ", False)
        res += f"{child_indent}└── Body:\n"
        res += self.body.to_tree_str(child_indent + "    ", True)
        return res


class BinaryOpNode(ASTNode):
    """Binary operation: left op right (arithmetic or relational)"""
    def __init__(self, left: ASTNode, op: str, right: ASTNode, line: int, column: int):
        super().__init__(line, column)
        self.left = left
        self.op = op
        self.right = right

    def to_dict(self) -> Dict[str, Any]:
        return {
            "node_type": "BinaryOp",
            "op": self.op,
            "left": self.left.to_dict(),
            "right": self.right.to_dict(),
            "line": self.line,
            "column": self.column,
        }

    def to_tree_str(self, indent: str = "", is_last: bool = True) -> str:
        marker = "└── " if is_last else "├── "
        res = f"{indent}{marker}BinaryOp ('{self.op}')\n"
        child_indent = indent + ("    " if is_last else "│   ")
        res += self.left.to_tree_str(child_indent, False)
        res += self.right.to_tree_str(child_indent, True)
        return res


class UnaryOpNode(ASTNode):
    """Unary operation: +expr or -expr"""
    def __init__(self, op: str, expr: ASTNode, line: int, column: int):
        super().__init__(line, column)
        self.op = op
        self.expr = expr

    def to_dict(self) -> Dict[str, Any]:
        return {
            "node_type": "UnaryOp",
            "op": self.op,
            "expr": self.expr.to_dict(),
            "line": self.line,
            "column": self.column,
        }

    def to_tree_str(self, indent: str = "", is_last: bool = True) -> str:
        marker = "└── " if is_last else "├── "
        res = f"{indent}{marker}UnaryOp ('{self.op}')\n"
        child_indent = indent + ("    " if is_last else "│   ")
        res += self.expr.to_tree_str(child_indent, True)
        return res


class LiteralNode(ASTNode):
    """Numeric constant: int or float"""
    def __init__(self, value: Union[int, float], val_type: str, line: int, column: int):
        super().__init__(line, column)
        self.value = value
        self.val_type = val_type

    def to_dict(self) -> Dict[str, Any]:
        return {
            "node_type": "Literal",
            "value": self.value,
            "val_type": self.val_type,
            "line": self.line,
            "column": self.column,
        }

    def to_tree_str(self, indent: str = "", is_last: bool = True) -> str:
        marker = "└── " if is_last else "├── "
        return f"{indent}{marker}Literal ({self.val_type}): {self.value}\n"


class VarNode(ASTNode):
    """Variable reference identifier"""
    def __init__(self, name: str, line: int, column: int):
        super().__init__(line, column)
        self.name = name

    def to_dict(self) -> Dict[str, Any]:
        return {
            "node_type": "Variable",
            "name": self.name,
            "line": self.line,
            "column": self.column,
        }

    def to_tree_str(self, indent: str = "", is_last: bool = True) -> str:
        marker = "└── " if is_last else "├── "
        return f"{indent}{marker}Variable: {self.name}\n"


# ---------------------------------------------------------------------------
# Syntax Error Definition
# ---------------------------------------------------------------------------

class SyntaxErrorItem:
    """Represents a syntax error encountered during parsing."""
    def __init__(self, message: str, line: int, column: int, found_token: Optional[Token] = None):
        self.message = message
        self.line = line
        self.column = column
        self.found_token = found_token

    def __str__(self) -> str:
        return f"[Syntax Error] Line {self.line}, Col {self.column}: {self.message}"

    def to_dict(self) -> Dict[str, Any]:
        return {
            "phase": "Syntax",
            "message": self.message,
            "line": self.line,
            "column": self.column,
            "token": self.found_token.value if self.found_token else None,
        }


# ---------------------------------------------------------------------------
# Recursive Descent Parser
# ---------------------------------------------------------------------------

class Parser:
    """
    LL(1) Recursive Descent Parser for Mini Compiler.
    Transforms list of tokens into an Abstract Syntax Tree (AST).
    """

    def __init__(self, tokens: List[Token]):
        self.tokens = tokens
        self.pos = 0
        self.errors: List[SyntaxErrorItem] = []

    def current_token(self) -> Token:
        if self.pos < len(self.tokens):
            return self.tokens[self.pos]
        return self.tokens[-1]  # Return EOF

    def peek_token(self, offset: int = 1) -> Token:
        peek_pos = self.pos + offset
        if peek_pos < len(self.tokens):
            return self.tokens[peek_pos]
        return self.tokens[-1]

    def match(self, *expected_types: str) -> bool:
        """Returns True if the current token matches any expected type."""
        return self.current_token().type in expected_types

    def advance(self) -> Token:
        """Consumes the current token and advances."""
        tok = self.current_token()
        if self.pos < len(self.tokens) - 1:
            self.pos += 1
        return tok

    def consume(self, expected_type: str, err_msg: str) -> Optional[Token]:
        """
        Consumes the expected token. If mismatched, logs a syntax error
        and attempts simple panic-mode recovery without crashing.
        """
        tok = self.current_token()
        if tok.type == expected_type:
            return self.advance()
        self.errors.append(SyntaxErrorItem(err_msg, tok.line, tok.column, tok))
        return None

    def synchronize(self) -> None:
        """Panic-mode recovery: advance until statement boundary (; or }) or EOF."""
        self.advance()
        while not self.match(TokenType.EOF):
            # Check previous token for semicolon
            if self.pos > 0 and self.tokens[self.pos - 1].type == TokenType.SEMICOLON:
                return
            if self.match(TokenType.KEYWORD_INT, TokenType.KEYWORD_FLOAT,
                          TokenType.KEYWORD_IF, TokenType.KEYWORD_WHILE,
                          TokenType.KEYWORD_PRINT, TokenType.RBRACE):
                return
            self.advance()

    # -----------------------------------------------------------------------
    # Grammar Production Methods
    # -----------------------------------------------------------------------

    def parse(self) -> Tuple[Optional[ProgramNode], List[SyntaxErrorItem]]:
        """Parses the entire token stream into a Program AST node."""
        statements: List[ASTNode] = []
        while not self.match(TokenType.EOF):
            try:
                stmt = self.statement()
                if stmt:
                    statements.append(stmt)
            except Exception as e:
                tok = self.current_token()
                self.errors.append(SyntaxErrorItem(f"Parser exception: {str(e)}", tok.line, tok.column, tok))
                self.synchronize()

        return ProgramNode(statements), self.errors

    def statement(self) -> Optional[ASTNode]:
        """
        Statement -> VarDeclStmt | AssignStmt | IfStmt | WhileStmt | PrintStmt | BlockStmt
        """
        tok = self.current_token()

        if tok.type in (TokenType.KEYWORD_INT, TokenType.KEYWORD_FLOAT):
            return self.var_decl_statement()
        elif tok.type == TokenType.IDENTIFIER:
            return self.assign_statement()
        elif tok.type == TokenType.KEYWORD_IF:
            return self.if_statement()
        elif tok.type == TokenType.KEYWORD_WHILE:
            return self.while_statement()
        elif tok.type == TokenType.KEYWORD_PRINT:
            return self.print_statement()
        elif tok.type == TokenType.LBRACE:
            return self.block_statement()
        elif tok.type == TokenType.SEMICOLON:
            # Empty statement
            self.advance()
            return None
        else:
            self.errors.append(
                SyntaxErrorItem(f"Unexpected token '{tok.value}' where a statement was expected",
                                tok.line, tok.column, tok)
            )
            self.synchronize()
            return None

    def var_decl_statement(self) -> Optional[VarDeclNode]:
        """VarDeclStmt -> ('int' | 'float') IDENTIFIER ('=' Expression)? ';'"""
        type_tok = self.advance()
        var_type = "int" if type_tok.type == TokenType.KEYWORD_INT else "float"

        name_tok = self.consume(TokenType.IDENTIFIER, "Expected variable name after type keyword")
        if not name_tok:
            self.synchronize()
            return None

        init_expr = None
        if self.match(TokenType.OP_ASSIGN):
            self.advance()  # consume '='
            init_expr = self.expression()

        semicolon = self.consume(TokenType.SEMICOLON, f"Missing ';' after variable declaration of '{name_tok.value}'")
        if not semicolon:
            # If missing semicolon, do not discard node if we have parsed declaration
            pass

        return VarDeclNode(var_type, name_tok.value, init_expr, type_tok.line, type_tok.column)

    def assign_statement(self) -> Optional[AssignNode]:
        """AssignStmt -> IDENTIFIER '=' Expression ';'"""
        name_tok = self.advance()  # IDENTIFIER
        assign_tok = self.consume(TokenType.OP_ASSIGN, f"Expected '=' after identifier '{name_tok.value}'")
        if not assign_tok:
            self.synchronize()
            return None

        expr = self.expression()
        semicolon = self.consume(TokenType.SEMICOLON, f"Missing ';' after assignment to '{name_tok.value}'")
        if not semicolon:
            pass

        return AssignNode(name_tok.value, expr, name_tok.line, name_tok.column)

    def print_statement(self) -> Optional[PrintNode]:
        """PrintStmt -> 'print' '(' Expression ')' ';'"""
        print_tok = self.advance()  # 'print'
        self.consume(TokenType.LPAREN, "Expected '(' after 'print'")
        expr = self.expression()
        self.consume(TokenType.RPAREN, "Expected ')' after print expression")
        self.consume(TokenType.SEMICOLON, "Missing ';' after print statement")
        return PrintNode(expr, print_tok.line, print_tok.column)

    def block_statement(self) -> BlockNode:
        """BlockStmt -> '{' StatementList '}'"""
        open_brace = self.advance()  # '{'
        statements: List[ASTNode] = []

        while not self.match(TokenType.RBRACE) and not self.match(TokenType.EOF):
            stmt = self.statement()
            if stmt:
                statements.append(stmt)

        self.consume(TokenType.RBRACE, "Missing '}' to close block statement")
        return BlockNode(statements, open_brace.line, open_brace.column)

    def if_statement(self) -> Optional[IfNode]:
        """IfStmt -> 'if' '(' Condition ')' Statement ('else' Statement)?"""
        if_tok = self.advance()  # 'if'
        self.consume(TokenType.LPAREN, "Expected '(' after 'if'")
        condition = self.condition()
        self.consume(TokenType.RPAREN, "Expected ')' after if condition")

        then_branch = self.statement()
        if not then_branch:
            then_branch = BlockNode([], if_tok.line, if_tok.column)

        else_branch = None
        if self.match(TokenType.KEYWORD_ELSE):
            self.advance()  # 'else'
            else_branch = self.statement()

        return IfNode(condition, then_branch, else_branch, if_tok.line, if_tok.column)

    def while_statement(self) -> Optional[WhileNode]:
        """WhileStmt -> 'while' '(' Condition ')' Statement"""
        while_tok = self.advance()  # 'while'
        self.consume(TokenType.LPAREN, "Expected '(' after 'while'")
        condition = self.condition()
        self.consume(TokenType.RPAREN, "Expected ')' after while condition")

        body = self.statement()
        if not body:
            body = BlockNode([], while_tok.line, while_tok.column)

        return WhileNode(condition, body, while_tok.line, while_tok.column)

    def condition(self) -> ASTNode:
        """
        Condition -> Expression (RelOp Expression)?
        RelOp: ==, !=, <, <=, >, >=
        """
        left = self.expression()
        rel_ops = (TokenType.OP_EQ, TokenType.OP_NE, TokenType.OP_LT,
                   TokenType.OP_LE, TokenType.OP_GT, TokenType.OP_GE)
        if self.match(*rel_ops):
            op_tok = self.advance()
            right = self.expression()
            return BinaryOpNode(left, op_tok.value, right, op_tok.line, op_tok.column)
        return left

    def expression(self) -> ASTNode:
        """Expression -> Term (('+' | '-') Term)*"""
        left = self.term()
        while self.match(TokenType.OP_PLUS, TokenType.OP_MINUS):
            op_tok = self.advance()
            right = self.term()
            left = BinaryOpNode(left, op_tok.value, right, op_tok.line, op_tok.column)
        return left

    def term(self) -> ASTNode:
        """Term -> Factor (('*' | '/' | '%') Factor)*"""
        left = self.factor()
        while self.match(TokenType.OP_MUL, TokenType.OP_DIV, TokenType.OP_MOD):
            op_tok = self.advance()
            right = self.factor()
            left = BinaryOpNode(left, op_tok.value, right, op_tok.line, op_tok.column)
        return left

    def factor(self) -> ASTNode:
        """Factor -> ('+' | '-')? Primary"""
        if self.match(TokenType.OP_PLUS, TokenType.OP_MINUS):
            op_tok = self.advance()
            primary = self.primary()
            return UnaryOpNode(op_tok.value, primary, op_tok.line, op_tok.column)
        return self.primary()

    def primary(self) -> ASTNode:
        """Primary -> INT_CONST | FLOAT_CONST | IDENTIFIER | '(' Expression ')'"""
        tok = self.current_token()

        if tok.type == TokenType.INT_CONST:
            self.advance()
            return LiteralNode(int(tok.value), "int", tok.line, tok.column)

        elif tok.type == TokenType.FLOAT_CONST:
            self.advance()
            return LiteralNode(float(tok.value), "float", tok.line, tok.column)

        elif tok.type == TokenType.IDENTIFIER:
            self.advance()
            return VarNode(tok.value, tok.line, tok.column)

        elif tok.type == TokenType.LPAREN:
            self.advance()
            expr = self.expression()
            self.consume(TokenType.RPAREN, "Expected ')' after parenthesized expression")
            return expr

        else:
            self.errors.append(
                SyntaxErrorItem(f"Expected expression but found '{tok.value}'", tok.line, tok.column, tok)
            )
            self.advance()
            # Return dummy literal to continue parsing
            return LiteralNode(0, "int", tok.line, tok.column)


def parse_code(tokens: List[Token]) -> Tuple[Optional[ProgramNode], List[SyntaxErrorItem]]:
    """Helper function to parse token stream."""
    parser = Parser(tokens)
    return parser.parse()
