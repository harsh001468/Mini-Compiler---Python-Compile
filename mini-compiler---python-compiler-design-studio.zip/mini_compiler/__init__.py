"""
Mini Compiler Package
=====================
Design and Implementation Using Python.
6-Phase Compiler: Lexer, Parser, Semantic Analyzer, TAC Generator, Optimizer, Target Code Generator.
"""
