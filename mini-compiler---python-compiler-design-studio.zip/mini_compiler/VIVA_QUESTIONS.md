# Compiler Design Viva Voce Questions & Answers
### B.Tech 2nd Year (AI&DS / CSE) Practical Examination Guide

---

### Q1: What is a Compiler and what are its major phases?
**Answer:**
A compiler is a language processor that translates a high-level source program into an equivalent low-level target machine code or assembly language. It operates in two main stages:
1. **Analysis Stage (Front-End)**:
   - **Lexical Analysis**: Converts character stream into tokens.
   - **Syntax Analysis**: Validates grammatical structure and generates AST.
   - **Semantic Analysis**: Checks type compatibility and symbol scope rules.
2. **Synthesis Stage (Back-End)**:
   - **Intermediate Code Generation**: Produces machine-independent Three-Address Code (TAC).
   - **Code Optimization**: Improves speed and reduces memory usage (Folding, CSE, DCE).
   - **Target Code Generation**: Maps TAC to real or virtual assembly/machine instructions.

---

### Q2: What is the difference between a Token, a Pattern, and a Lexeme?
**Answer:**
- **Token**: An abstract category assigned to an input unit (e.g., `KEYWORD_INT`, `IDENTIFIER`, `INT_CONST`).
- **Pattern**: The formal description or regular expression that matches a token (e.g., `[a-zA-Z_][a-zA-Z0-9_]*`).
- **Lexeme**: The actual sequence of characters in the source code matching the pattern (e.g., `int`, `counter`, `10`).

---

### Q3: What is a Recursive Descent Parser? Is it Top-Down or Bottom-Up?
**Answer:**
A Recursive Descent Parser is a **Top-Down** parsing technique that builds the parse tree starting from the start symbol down to the leaves. It consists of a set of mutually recursive procedures, where each procedure corresponds to one non-terminal in the grammar. It uses lookahead (e.g., LL(1)) to decide which production to expand without backtracking.

---

### Q4: What makes a grammar LL(1)?
**Answer:**
An LL(1) grammar satisfies three criteria:
1. First 'L': Scans input from Left to right.
2. Second 'L': Constructs a Leftmost derivation.
3. '(1)': Uses 1 lookahead token to decide each production.
A grammar is LL(1) if and only if for every non-terminal $A$ with productions $A \to \alpha \mid \beta$:
- $\text{FIRST}(\alpha) \cap \text{FIRST}(\beta) = \emptyset$
- If $\beta \Rightarrow^* \epsilon$, then $\text{FIRST}(\alpha) \cap \text{FOLLOW}(A) = \emptyset$.

---

### Q5: How does your parser eliminate left recursion?
**Answer:**
Immediate left recursion of the form:
$$E \to E + T \mid T$$
causes infinite recursion in top-down parsers. We transform it into an iterative loop or right-recursive grammar:
```python
def expression(self):
    left = self.term()
    while self.match(TokenType.OP_PLUS, TokenType.OP_MINUS):
        op = self.advance()
        right = self.term()
        left = BinaryOpNode(left, op.value, right)
    return left
```
This evaluates left-to-right correctly while avoiding infinite recursion.

---

### Q6: What is an Abstract Syntax Tree (AST) and how does it differ from a Parse Tree?
**Answer:**
- **Parse Tree (Concrete Syntax Tree)**: Retains every syntactic detail from grammar productions, including punctuation (parentheses, semicolons, redundant non-terminals).
- **AST (Abstract Syntax Tree)**: A condensed, semantic tree representation where interior nodes are operators and leaf nodes are operands. Superfluous delimiters are discarded.

---

### Q7: What is the Symbol Table and what information does it store?
**Answer:**
The Symbol Table is a central data structure used across compiler phases to store identifier metadata:
- Name / Lexeme
- Data type (`int`, `float`)
- Declaration location (Line and column)
- Scope level (0 for global, 1+ for nested blocks)
- Initialization status (initialized vs uninitialized)

---

### Q8: What is Three-Address Code (TAC)? Why is it called "Three-Address"?
**Answer:**
Three-Address Code is a linearized intermediate representation where each instruction has at most one operator on the right-hand side and at most **three memory addresses/variables**:
$$x = y \text{ op } z$$
Here, $x$ (result), $y$ (operand 1), and $z$ (operand 2) are the three addresses.
Example:
$a + b * c$ is decomposed into:
```text
t0 = b * c
t1 = a + t0
```

---

### Q9: What are Quadruples, Triples, and Indirect Triples?
**Answer:**
- **Quadruple**: Record with 4 fields: `(op, arg1, arg2, result)`. Explicitly stores destination.
- **Triple**: Record with 3 fields: `(op, arg1, arg2)`. The result is implicitly referenced by instruction index `(0)`, `(1)`.
- **Indirect Triple**: Stores an array of pointers to Triples, making instruction reordering during optimization easier.
*Our compiler uses the Quadruple representation.*

---

### Q10: Explain the 4 optimization techniques implemented in this project:
**Answer:**
1. **Constant Folding**: Evaluates expressions involving only compile-time constants:
   `t0 = 3 * 4` $\to$ `t0 = 12`.
2. **Constant Propagation**: If variable $x$ has known constant value $C$, replaces uses of $x$ with $C$:
   `a = 10; b = a + 5;` $\to$ `b = 10 + 5;` $\to$ `b = 15;`.
3. **Common Subexpression Elimination (CSE)**: If $x = a + b$ was computed and neither $a$ nor $b$ changed, replaces duplicate $y = a + b$ with $y = x$.
4. **Dead Code Elimination (DCE)**: Removes instructions computing values that are never used subsequently or unreachable instructions following unconditional jumps.

---

### Q11: How does your compiler perform Register Allocation?
**Answer:**
Our compiler implements a linear-scan round-robin register allocator targeting an 8-register machine (R0 through R7). When an operand is needed, if it is an immediate constant or memory variable, it is loaded into an available register. Intermediate temporary variables resident in registers are reused to avoid redundant memory roundtrips.

---

### Q12: How does the compiler handle control flow (if-else and while loops)?
**Answer:**
Control flow is translated using condition evaluations, conditional branch instructions (`IF_REL_GOTO`, `CMP`, `JEQ`, `JNE`, `JLT`, `JLE`, `JGT`, `JGE`), unconditional jumps (`GOTO`, `JMP`), and symbolic labels (`L0`, `L1`, `L2`).
- **If-Else**: Compares condition, jumps to `L_then` if true, otherwise jumps to `L_else` (or `L_end`), and adds an unconditional jump at the end of the `then` block over the `else` block.
- **While Loop**: Generates a loop-header label `L_start`, checks condition, jumps to `L_body` if true or `L_end` if false, executes body, and jumps back to `L_start`.
