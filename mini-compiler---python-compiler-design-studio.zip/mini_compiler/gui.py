"""
=============================================================================
GUI Design: Tkinter Modern Dark-Themed Desktop Interface
=============================================================================
Project: Mini Compiler – Design and Implementation Using Python
Author: 2nd-year B.Tech AI & Data Science
Purpose:
  Provides a student- and professor-ready GUI using Python's standard Tkinter.
  Features:
    - Professional dark theme with modern typography.
    - Line-numbered source code editor with synchronized scrolling.
    - Quick-load menu with 12 preset test cases & samples.
    - Action toolbar: Compile, Run, Clear, Run Test Suite.
    - 6 dedicated phase tabs:
        1. Lexical Analysis (Tokens Table)
        2. Syntax Analysis (AST Tree View)
        3. Semantic Analysis (Symbol Table & Scope Diagnostics)
        4. Intermediate Code (Three-Address Code & Quadruples)
        5. Optimized Code (Before/After TAC & Optimizations Audit Log)
        6. Target Code (Assembly Instructions & Register Machine ISA)
    - Real-time Output & Diagnostic Console with line-number error reporting.
=============================================================================
"""

import sys
import os

# Ensure package path is resolved
CURRENT_DIR = os.path.dirname(os.path.abspath(__file__))
PARENT_DIR = os.path.abspath(os.path.join(CURRENT_DIR, ".."))
if CURRENT_DIR not in sys.path:
    sys.path.insert(0, CURRENT_DIR)
if PARENT_DIR not in sys.path:
    sys.path.insert(0, PARENT_DIR)

try:
    import tkinter as tk
    from tkinter import ttk, messagebox, scrolledtext
    TKINTER_AVAILABLE = True
except ImportError:
    TKINTER_AVAILABLE = False

try:
    from mini_compiler.main import compile_pipeline
    from mini_compiler.test_cases import TEST_CASES
except ImportError:
    from main import compile_pipeline
    from test_cases import TEST_CASES


DEFAULT_CODE = """int a = 10;
int b = 20;
int c;
c = a + b * 2;
print(c);
"""

# Dark theme color palette (Catppuccin / Modern Charcoal inspired)
THEME = {
    "bg_main": "#1e1e2e",
    "bg_card": "#181825",
    "bg_input": "#11111b",
    "bg_gutter": "#181825",
    "text_main": "#cdd6f4",
    "text_muted": "#a6adc8",
    "accent_blue": "#89b4fa",
    "accent_green": "#a6e3a1",
    "accent_yellow": "#f9e2af",
    "accent_red": "#f38ba8",
    "accent_purple": "#cba6f7",
    "border": "#313244",
}


class LineNumbers(tk.Canvas):
    """Gutter canvas displaying line numbers synchronized with the Text widget."""
    def __init__(self, text_widget: tk.Text, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.text_widget = text_widget
        self.config(bg=THEME["bg_gutter"], highlightthickness=0, width=42)

    def redraw(self, *args):
        self.delete("all")
        i = self.text_widget.index("@0,0")
        while True:
            dline = self.text_widget.dlineinfo(i)
            if dline is None:
                break
            y = dline[1]
            linenum = str(i).split(".")[0]
            self.create_text(
                35, y,
                anchor="ne",
                text=linenum,
                font=("Consolas", 11),
                fill=THEME["text_muted"]
            )
            i = self.text_widget.index(f"{i}+1line")


class MiniCompilerGUI:
    """Tkinter Desktop Application for Mini Compiler."""

    def __init__(self, root: tk.Tk):
        self.root = root
        self.root.title("MINI COMPILER – Design and Implementation Using Python")
        self.root.geometry("1280x820")
        self.root.minsize(1000, 650)
        self.root.configure(bg=THEME["bg_main"])

        self.setup_styles()
        self.build_ui()
        self.load_sample(0)

    def setup_styles(self):
        style = ttk.Style()
        style.theme_use("clam")

        # Configure Notebook and Tabs
        style.configure("TNotebook", background=THEME["bg_main"], borderwidth=0)
        style.configure("TNotebook.Tab",
                        background=THEME["bg_card"],
                        foreground=THEME["text_muted"],
                        padding=[12, 6],
                        font=("Segoe UI", 10, "bold"),
                        borderwidth=0)
        style.map("TNotebook.Tab",
                  background=[("selected", THEME["border"]), ("active", THEME["bg_card"])],
                  foreground=[("selected", THEME["accent_blue"]), ("active", THEME["text_main"])])

        # Configure Treeviews for tables
        style.configure("Treeview",
                        background=THEME["bg_input"],
                        foreground=THEME["text_main"],
                        fieldbackground=THEME["bg_input"],
                        font=("Consolas", 10),
                        rowheight=24,
                        borderwidth=0)
        style.configure("Treeview.Heading",
                        background=THEME["bg_card"],
                        foreground=THEME["accent_blue"],
                        font=("Segoe UI", 10, "bold"),
                        relief="flat")
        style.map("Treeview",
                  background=[("selected", THEME["border"])],
                  foreground=[("selected", THEME["accent_green"])])

    def build_ui(self):
        # 1. Header Frame
        header = tk.Frame(self.root, bg=THEME["bg_card"], height=52)
        header.pack(fill="x", side="top", padx=0, pady=0)

        title_lbl = tk.Label(
            header,
            text="⚙️ MINI COMPILER",
            font=("Segoe UI", 15, "bold"),
            bg=THEME["bg_card"],
            fg=THEME["accent_blue"]
        )
        title_lbl.pack(side="left", padx=16, pady=8)

        subtitle_lbl = tk.Label(
            header,
            text="6-Phase Compiler Design & Implementation (Python / Tkinter)",
            font=("Segoe UI", 10),
            bg=THEME["bg_card"],
            fg=THEME["text_muted"]
        )
        subtitle_lbl.pack(side="left", padx=6, pady=8)

        # Preset Sample Selector
        sample_frame = tk.Frame(header, bg=THEME["bg_card"])
        sample_frame.pack(side="right", padx=16)

        tk.Label(sample_frame, text="Load Preset:", font=("Segoe UI", 9, "bold"),
                 bg=THEME["bg_card"], fg=THEME["text_muted"]).pack(side="left", padx=4)

        self.sample_var = tk.StringVar()
        sample_titles = [f"{t['id']}. {t['name']}" for t in TEST_CASES]
        self.sample_dropdown = ttk.Combobox(
            sample_frame,
            textvariable=self.sample_var,
            values=sample_titles,
            state="readonly",
            width=36
        )
        self.sample_dropdown.pack(side="left", padx=4)
        self.sample_dropdown.current(0)
        self.sample_dropdown.bind("<<ComboboxSelected>>", self.on_sample_changed)

        # 2. Action Toolbar Frame
        toolbar = tk.Frame(self.root, bg=THEME["bg_main"], height=44)
        toolbar.pack(fill="x", side="top", padx=14, pady=8)

        btn_compile = tk.Button(
            toolbar, text="▶ Compile Pipeline",
            command=self.compile_code,
            font=("Segoe UI", 10, "bold"),
            bg="#2563eb", fg="#ffffff",
            activebackground="#1d4ed8", activeforeground="#ffffff",
            padx=16, pady=4, relief="flat", cursor="hand2"
        )
        btn_compile.pack(side="left", padx=4)

        btn_run = tk.Button(
            toolbar, text="⚡ Run (VM)",
            command=self.run_code,
            font=("Segoe UI", 10, "bold"),
            bg="#16a34a", fg="#ffffff",
            activebackground="#15803d", activeforeground="#ffffff",
            padx=14, pady=4, relief="flat", cursor="hand2"
        )
        btn_run.pack(side="left", padx=4)

        btn_clear = tk.Button(
            toolbar, text="🗑 Clear",
            command=self.clear_all,
            font=("Segoe UI", 10),
            bg=THEME["bg_card"], fg=THEME["text_main"],
            activebackground=THEME["border"], activeforeground=THEME["text_main"],
            padx=12, pady=4, relief="flat", cursor="hand2"
        )
        btn_clear.pack(side="left", padx=4)

        btn_tests = tk.Button(
            toolbar, text="🧪 Run All 12 Tests",
            command=self.run_test_suite_gui,
            font=("Segoe UI", 10),
            bg=THEME["bg_card"], fg=THEME["accent_purple"],
            activebackground=THEME["border"], activeforeground=THEME["text_main"],
            padx=12, pady=4, relief="flat", cursor="hand2"
        )
        btn_tests.pack(side="left", padx=4)

        self.status_badge = tk.Label(
            toolbar, text="Ready", font=("Segoe UI", 9, "bold"),
            bg=THEME["border"], fg=THEME["text_muted"], padx=10, pady=4
        )
        self.status_badge.pack(side="right", padx=6)

        # 3. Main Split Area: Left (Editor) and Right (Notebook of 6 Tabs)
        main_split = tk.PanedWindow(self.root, orient="horizontal", bg=THEME["bg_main"], sashwidth=4)
        main_split.pack(fill="both", expand=True, padx=14, pady=(0, 6))

        # --- LEFT: Source Code Editor with Line Numbers ---
        editor_panel = tk.Frame(main_split, bg=THEME["bg_card"], padx=1, pady=1)
        main_split.add(editor_panel, minsize=380, width=440)

        editor_header = tk.Frame(editor_panel, bg=THEME["bg_card"])
        editor_header.pack(fill="x", side="top", padx=8, pady=4)
        tk.Label(editor_header, text="SOURCE CODE EDITOR", font=("Segoe UI", 9, "bold"),
                 bg=THEME["bg_card"], fg=THEME["accent_blue"]).pack(side="left")

        editor_body = tk.Frame(editor_panel, bg=THEME["bg_input"])
        editor_body.pack(fill="both", expand=True, padx=4, pady=4)

        # Scrollbar
        editor_scroll = tk.Scrollbar(editor_body)
        editor_scroll.pack(side="right", fill="y")

        # Code text
        self.code_editor = tk.Text(
            editor_body,
            bg=THEME["bg_input"],
            fg=THEME["text_main"],
            insertbackground=THEME["accent_blue"],
            selectbackground=THEME["border"],
            selectforeground="#ffffff",
            font=("Consolas", 11),
            undo=True,
            wrap="none",
            yscrollcommand=editor_scroll.set
        )
        self.code_editor.pack(side="right", fill="both", expand=True)

        # Line numbers canvas
        self.line_numbers = LineNumbers(self.code_editor, editor_body)
        self.line_numbers.pack(side="left", fill="y")

        editor_scroll.config(command=self.sync_scroll)
        self.code_editor.bind("<KeyRelease>", self.on_editor_modified)
        self.code_editor.bind("<MouseWheel>", self.on_editor_modified)

        # --- RIGHT: 6 Phase Tabs Notebook ---
        notebook_panel = tk.Frame(main_split, bg=THEME["bg_main"])
        main_split.add(notebook_panel, minsize=520)

        self.notebook = ttk.Notebook(notebook_panel)
        self.notebook.pack(fill="both", expand=True)

        # Tab 1: Lexical Analysis
        self.tab_lex = tk.Frame(self.notebook, bg=THEME["bg_card"])
        self.notebook.add(self.tab_lex, text="1. Lexical")
        self.build_lexical_tab()

        # Tab 2: Syntax Analysis
        self.tab_syn = tk.Frame(self.notebook, bg=THEME["bg_card"])
        self.notebook.add(self.tab_syn, text="2. Syntax (AST)")
        self.build_syntax_tab()

        # Tab 3: Semantic Analysis
        self.tab_sem = tk.Frame(self.notebook, bg=THEME["bg_card"])
        self.notebook.add(self.tab_sem, text="3. Semantic")
        self.build_semantic_tab()

        # Tab 4: Intermediate Code
        self.tab_tac = tk.Frame(self.notebook, bg=THEME["bg_card"])
        self.notebook.add(self.tab_tac, text="4. Intermediate (TAC)")
        self.build_tac_tab()

        # Tab 5: Code Optimization
        self.tab_opt = tk.Frame(self.notebook, bg=THEME["bg_card"])
        self.notebook.add(self.tab_opt, text="5. Optimizer")
        self.build_optimizer_tab()

        # Tab 6: Target Code
        self.tab_tgt = tk.Frame(self.notebook, bg=THEME["bg_card"])
        self.notebook.add(self.tab_tgt, text="6. Target Code")
        self.build_target_tab()

        # 4. Bottom Output Console Frame
        bottom_frame = tk.Frame(self.root, bg=THEME["bg_card"], height=160)
        bottom_frame.pack(fill="x", side="bottom", padx=14, pady=(0, 10))

        bottom_header = tk.Frame(bottom_frame, bg=THEME["bg_card"])
        bottom_header.pack(fill="x", side="top", padx=10, pady=(6, 2))

        tk.Label(bottom_header, text="OUTPUT & DIAGNOSTICS CONSOLE", font=("Segoe UI", 9, "bold"),
                 bg=THEME["bg_card"], fg=THEME["accent_green"]).pack(side="left")

        self.console_text = scrolledtext.ScrolledText(
            bottom_frame,
            height=6,
            bg=THEME["bg_input"],
            fg=THEME["text_main"],
            font=("Consolas", 10),
            relief="flat",
            wrap="word"
        )
        self.console_text.pack(fill="both", expand=True, padx=8, pady=(2, 6))

    # -----------------------------------------------------------------------
    # Tab Builders
    # -----------------------------------------------------------------------

    def build_lexical_tab(self):
        """Tab 1: Table of generated tokens (Token #, Type, Value, Line, Column)."""
        frame = tk.Frame(self.tab_lex, bg=THEME["bg_card"])
        frame.pack(fill="both", expand=True, padx=8, pady=8)

        cols = ("idx", "type", "value", "line", "col")
        self.lex_tree = ttk.Treeview(frame, columns=cols, show="headings")
        self.lex_tree.heading("idx", text="#")
        self.lex_tree.heading("type", text="Token Type")
        self.lex_tree.heading("value", text="Lexeme / Value")
        self.lex_tree.heading("line", text="Line")
        self.lex_tree.heading("col", text="Column")

        self.lex_tree.column("idx", width=40, anchor="center")
        self.lex_tree.column("type", width=160, anchor="w")
        self.lex_tree.column("value", width=140, anchor="w")
        self.lex_tree.column("line", width=60, anchor="center")
        self.lex_tree.column("col", width=60, anchor="center")

        scroll = ttk.Scrollbar(frame, orient="vertical", command=self.lex_tree.yview)
        self.lex_tree.configure(yscrollcommand=scroll.set)

        self.lex_tree.pack(side="left", fill="both", expand=True)
        scroll.pack(side="right", fill="y")

    def build_syntax_tab(self):
        """Tab 2: Abstract Syntax Tree text representation."""
        frame = tk.Frame(self.tab_syn, bg=THEME["bg_card"])
        frame.pack(fill="both", expand=True, padx=8, pady=8)

        self.syn_text = scrolledtext.ScrolledText(
            frame,
            bg=THEME["bg_input"],
            fg=THEME["text_main"],
            font=("Consolas", 10),
            relief="flat",
            wrap="none"
        )
        self.syn_text.pack(fill="both", expand=True)

    def build_semantic_tab(self):
        """Tab 3: Symbol Table & Semantic Diagnostics."""
        frame = tk.Frame(self.tab_sem, bg=THEME["bg_card"])
        frame.pack(fill="both", expand=True, padx=8, pady=8)

        tk.Label(frame, text="SYMBOL TABLE", font=("Segoe UI", 9, "bold"),
                 bg=THEME["bg_card"], fg=THEME["accent_blue"]).pack(anchor="w", pady=(0, 4))

        cols = ("name", "type", "line", "scope", "initialized")
        self.sem_tree = ttk.Treeview(frame, columns=cols, show="headings", height=8)
        self.sem_tree.heading("name", text="Identifier")
        self.sem_tree.heading("type", text="Data Type")
        self.sem_tree.heading("line", text="Declared Line")
        self.sem_tree.heading("scope", text="Scope Level")
        self.sem_tree.heading("initialized", text="Initialized?")

        self.sem_tree.column("name", width=120, anchor="w")
        self.sem_tree.column("type", width=90, anchor="center")
        self.sem_tree.column("line", width=100, anchor="center")
        self.sem_tree.column("scope", width=90, anchor="center")
        self.sem_tree.column("initialized", width=100, anchor="center")

        self.sem_tree.pack(fill="x", pady=(0, 8))

        tk.Label(frame, text="SEMANTIC DIAGNOSTICS & CHECKS", font=("Segoe UI", 9, "bold"),
                 bg=THEME["bg_card"], fg=THEME["accent_yellow"]).pack(anchor="w", pady=(4, 4))

        self.sem_diag_text = scrolledtext.ScrolledText(
            frame,
            height=6,
            bg=THEME["bg_input"],
            fg=THEME["text_main"],
            font=("Consolas", 10),
            relief="flat"
        )
        self.sem_diag_text.pack(fill="both", expand=True)

    def build_tac_tab(self):
        """Tab 4: Three-Address Code listing and Quadruples."""
        frame = tk.Frame(self.tab_tac, bg=THEME["bg_card"])
        frame.pack(fill="both", expand=True, padx=8, pady=8)

        self.tac_text = scrolledtext.ScrolledText(
            frame,
            bg=THEME["bg_input"],
            fg=THEME["text_main"],
            font=("Consolas", 10),
            relief="flat",
            wrap="none"
        )
        self.tac_text.pack(fill="both", expand=True)

    def build_optimizer_tab(self):
        """Tab 5: Original vs Optimized TAC and Transformations Audit Log."""
        frame = tk.Frame(self.tab_opt, bg=THEME["bg_card"])
        frame.pack(fill="both", expand=True, padx=8, pady=8)

        # Split into Optimized TAC (top) and Audit log (bottom)
        paned = tk.PanedWindow(frame, orient="vertical", bg=THEME["bg_card"], sashwidth=4)
        paned.pack(fill="both", expand=True)

        top_f = tk.Frame(paned, bg=THEME["bg_card"])
        paned.add(top_f, minsize=140, height=180)
        tk.Label(top_f, text="OPTIMIZED THREE-ADDRESS CODE", font=("Segoe UI", 9, "bold"),
                 bg=THEME["bg_card"], fg=THEME["accent_green"]).pack(anchor="w", pady=(0, 4))

        self.opt_tac_text = scrolledtext.ScrolledText(
            top_f, bg=THEME["bg_input"], fg=THEME["text_main"], font=("Consolas", 10), relief="flat"
        )
        self.opt_tac_text.pack(fill="both", expand=True)

        bot_f = tk.Frame(paned, bg=THEME["bg_card"])
        paned.add(bot_f, minsize=120)
        tk.Label(bot_f, text="OPTIMIZATIONS AUDIT LOG (Folding, Propagation, CSE, DCE)", font=("Segoe UI", 9, "bold"),
                 bg=THEME["bg_card"], fg=THEME["accent_yellow"]).pack(anchor="w", pady=(4, 4))

        self.opt_log_text = scrolledtext.ScrolledText(
            bot_f, bg=THEME["bg_input"], fg=THEME["text_main"], font=("Consolas", 10), relief="flat"
        )
        self.opt_log_text.pack(fill="both", expand=True)

    def build_target_tab(self):
        """Tab 6: Target Assembly code."""
        frame = tk.Frame(self.tab_tgt, bg=THEME["bg_card"])
        frame.pack(fill="both", expand=True, padx=8, pady=8)

        self.tgt_text = scrolledtext.ScrolledText(
            frame,
            bg=THEME["bg_input"],
            fg=THEME["text_main"],
            font=("Consolas", 10),
            relief="flat",
            wrap="none"
        )
        self.tgt_text.pack(fill="both", expand=True)

    # -----------------------------------------------------------------------
    # Event Handlers & Actions
    # -----------------------------------------------------------------------

    def sync_scroll(self, *args):
        self.code_editor.yview(*args)
        self.line_numbers.redraw()

    def on_editor_modified(self, event=None):
        self.line_numbers.redraw()

    def on_sample_changed(self, event=None):
        idx = self.sample_dropdown.current()
        if 0 <= idx < len(TEST_CASES):
            self.load_sample(idx)

    def load_sample(self, idx: int):
        test = TEST_CASES[idx]
        self.code_editor.delete("1.0", tk.END)
        self.code_editor.insert("1.0", test["code"].strip())
        self.line_numbers.redraw()
        self.log_console(f"Loaded Sample {test['id']}: {test['name']} ({test['description']})")

    def log_console(self, msg: str, tag: Optional[str] = None):
        self.console_text.insert(tk.END, msg + "\n")
        self.console_text.see(tk.END)

    def clear_all(self):
        self.code_editor.delete("1.0", tk.END)
        self.line_numbers.redraw()
        self.console_text.delete("1.0", tk.END)
        for item in self.lex_tree.get_children():
            self.lex_tree.delete(item)
        for item in self.sem_tree.get_children():
            self.sem_tree.delete(item)
        self.syn_text.delete("1.0", tk.END)
        self.sem_diag_text.delete("1.0", tk.END)
        self.tac_text.delete("1.0", tk.END)
        self.opt_tac_text.delete("1.0", tk.END)
        self.opt_log_text.delete("1.0", tk.END)
        self.tgt_text.delete("1.0", tk.END)
        self.set_status("Cleared", THEME["text_muted"], THEME["border"])

    def set_status(self, text: str, fg: str, bg: str):
        self.status_badge.config(text=text, fg=fg, bg=bg)

    def compile_code(self) -> Optional[dict]:
        code = self.code_editor.get("1.0", tk.END).strip()
        if not code:
            messagebox.showwarning("Empty Code", "Please enter or load some source code before compiling.")
            return None

        self.console_text.delete("1.0", tk.END)
        self.log_console("⚙️ Starting compilation pipeline...")

        res = compile_pipeline(code, run_vm=False)

        # Clear existing tabs data
        for item in self.lex_tree.get_children():
            self.lex_tree.delete(item)
        for item in self.sem_tree.get_children():
            self.sem_tree.delete(item)
        self.syn_text.delete("1.0", tk.END)
        self.sem_diag_text.delete("1.0", tk.END)
        self.tac_text.delete("1.0", tk.END)
        self.opt_tac_text.delete("1.0", tk.END)
        self.opt_log_text.delete("1.0", tk.END)
        self.tgt_text.delete("1.0", tk.END)

        # Populate Phase 1: Lexical
        if "lexical" in res["phases"]:
            tokens = res["phases"]["lexical"]["tokens"]
            for i, t in enumerate(tokens):
                self.lex_tree.insert("", "end", values=(i, t["type"], t["value"], t["line"], t["column"]))

        # Check errors
        if not res["success"]:
            err_phase = res.get("error_phase", "Compilation")
            self.set_status(f"Error in {err_phase}", THEME["accent_red"], "#450a0a")
            self.log_console(f"❌ COMPILATION FAILED during {err_phase}:")
            for err in res["errors"]:
                line = err.get("line", "?")
                col = err.get("column", "?")
                msg = err.get("message", "Error")
                self.log_console(f"  • Line {line}, Col {col}: {msg}")
            return res

        # Populate Phase 2: Syntax
        if "syntax" in res["phases"]:
            ast_tree = res["phases"]["syntax"]["ast_tree"]
            self.syn_text.insert("1.0", ast_tree)

        # Populate Phase 3: Semantic
        if "semantic" in res["phases"]:
            symbols = res["phases"]["semantic"]["symbol_table"]
            for s in symbols:
                init_str = "Yes" if s["initialized"] else "No"
                self.sem_tree.insert("", "end", values=(s["name"], s["type"], s["line"], s["scope"], init_str))

            diag_lines = ["All variable declarations and type constraints passed validation."]
            for w in res.get("warnings", []):
                diag_lines.append(f"⚠️  Warning Line {w.get('line')}: {w.get('message')}")
            self.sem_diag_text.insert("1.0", "\n".join(diag_lines))

        # Populate Phase 4: Intermediate Code
        if "intermediate" in res["phases"]:
            self.tac_text.insert("1.0", res["phases"]["intermediate"]["tac_text"])

        # Populate Phase 5: Optimizer
        if "optimizer" in res["phases"]:
            opt = res["phases"]["optimizer"]
            self.opt_tac_text.insert("1.0", opt["tac_text"])
            log_entries = [
                f"Pass statistics: {opt['original_count']} quadruples reduced to {opt['optimized_count']} ({opt['reduction_percent']}% reduction)\n"
            ]
            if opt["records"]:
                for r in opt["records"]:
                    log_entries.append(f"[{r['type']}] {r['details']}\n   {r['before']}  ->  {r['after']}")
            else:
                log_entries.append("No further optimizations applicable (already in minimal normal form).")
            self.opt_log_text.insert("1.0", "\n".join(log_entries))

        # Populate Phase 6: Target Code
        if "target_code" in res["phases"]:
            self.tgt_text.insert("1.0", res["phases"]["target_code"]["assembly_text"])

        self.set_status("Compilation Successful", THEME["accent_green"], "#052e16")
        self.log_console("✅ Compilation completed successfully across all 6 phases!")
        return res

    def run_code(self):
        res = self.compile_code()
        if not res or not res["success"]:
            return

        self.log_console("\n⚡ Executing target assembly in Virtual Machine Simulator...")
        # Re-run with VM
        code = self.code_editor.get("1.0", tk.END).strip()
        vm_res = compile_pipeline(code, run_vm=True)

        outputs = vm_res.get("execution_output", [])
        if outputs:
            self.log_console("----------------------------------------")
            self.log_console("PROGRAM OUTPUT:")
            for o in outputs:
                self.log_console(f" > {o}")
            self.log_console("----------------------------------------")
        else:
            self.log_console("(Program executed with no console output)")

        mem = vm_res.get("execution_memory", {})
        cycles = vm_res.get("execution_cycles", 0)
        self.log_console(f"Final Memory State: {mem}")
        self.log_console(f"Simulated Execution Cycles: {cycles}")
        self.set_status("Run Complete", THEME["accent_green"], "#052e16")

    def run_test_suite_gui(self):
        self.console_text.delete("1.0", tk.END)
        self.log_console("🧪 Running full automated test suite (12 test cases)...\n")
        passed = 0
        for test in TEST_CASES:
            res = compile_pipeline(test["code"])
            ok = False
            if test["expected_success"]:
                ok = res["success"] and (test.get("expected_output") is None or res.get("execution_output") == test.get("expected_output"))
            else:
                ok = not res["success"]
            if ok:
                passed += 1
                self.log_console(f"✅ Test {test['id']:02d}: {test['name']} - PASSED")
            else:
                self.log_console(f"❌ Test {test['id']:02d}: {test['name']} - FAILED")

        self.log_console(f"\nResult: {passed}/{len(TEST_CASES)} Tests Passed.")
        messagebox.showinfo("Test Suite Result", f"{passed}/{len(TEST_CASES)} automated tests passed successfully!")


def launch_gui():
    """Entry point to launch the Tkinter GUI."""
    if not TKINTER_AVAILABLE:
        print("Error: Tkinter module is not installed in this Python environment.")
        print("On Ubuntu/Debian, install with: sudo apt install python3-tk")
        print("On Windows/macOS, Tkinter is included automatically with official Python.")
        return
    root = tk.Tk()
    app = MiniCompilerGUI(root)
    root.mainloop()


if __name__ == "__main__":
    launch_gui()
