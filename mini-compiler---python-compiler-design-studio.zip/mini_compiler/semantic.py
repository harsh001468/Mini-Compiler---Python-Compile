"""
=============================================================================
Phase 3: Semantic Analysis (Type Checking & Symbol Table Management)
=============================================================================
Project: Mini Compiler – Design and Implementation Using Python
Author: 2nd-year B.Tech AI & Data Science
Purpose:
  Traverses the Abstract Syntax Tree (AST) produced by the parser.
  Maintains a scoped Symbol Table to enforce semantic rules:
    1. Variable declaration before use (detects undeclared variables).
    2. Prevention of duplicate variable declarations in the same scope.
    3. Static type checking & type consistency (int, float, implicit promotion).
    4. Compile-time division by zero detection.
    5. Tracking variable initialization status.
=============================================================================
"""

from typing import Dict, List, Optional, Tuple, Any, Set
from mini_compiler.parser import (
    ASTNode, ProgramNode, VarDeclNode, AssignNode, PrintNode,
    BlockNode, IfNode, WhileNode, BinaryOpNode, UnaryOpNode,
    LiteralNode, VarNode
)


class Symbol:
    """Represents an entry in the compiler's Symbol Table."""

    def __init__(self, name: str, data_type: str, line_declared: int, scope_level: int, initialized: bool = False):
        self.name = name
        self.data_type = data_type          # 'int' or 'float'
        self.line_declared = line_declared
        self.scope_level = scope_level
        self.initialized = initialized
        self.current_value: Optional[Any] = None

    def __repr__(self) -> str:
        return f"Symbol({self.name}: {self.data_type}, Scope:{self.scope_level}, Init:{self.initialized})"

    def to_dict(self) -> Dict[str, Any]:
        return {
            "name": self.name,
            "type": self.data_type,
            "line": self.line_declared,
            "scope": self.scope_level,
            "initialized": self.initialized,
            "value": self.current_value,
        }


class Scope:
    """Represents a lexical scope containing local symbols."""

    def __init__(self, level: int, parent: Optional["Scope"] = None):
        self.level = level
        self.parent = parent
        self.symbols: Dict[str, Symbol] = {}

    def define(self, symbol: Symbol) -> bool:
        """Defines a symbol in the current scope. Returns False if already declared."""
        if symbol.name in self.symbols:
            return False
        self.symbols[symbol.name] = symbol
        return True

    def lookup(self, name: str) -> Optional[Symbol]:
        """Looks up a symbol in this scope or parent scopes (lexical scoping)."""
        if name in self.symbols:
            return self.symbols[name]
        if self.parent:
            return self.parent.lookup(name)
        return None

    def lookup_current(self, name: str) -> Optional[Symbol]:
        """Looks up a symbol strictly within the current scope."""
        return self.symbols.get(name)


class SemanticError:
    """Represents a compile-time semantic violation."""

    def __init__(self, message: str, line: int, column: int, severity: str = "ERROR"):
        self.message = message
        self.line = line
        self.column = column
        self.severity = severity  # "ERROR" or "WARNING"

    def __str__(self) -> str:
        return f"[{self.severity}] Line {self.line}, Col {self.column}: {self.message}"

    def to_dict(self) -> Dict[str, Any]:
        return {
            "phase": "Semantic",
            "message": self.message,
            "line": self.line,
            "column": self.column,
            "severity": self.severity,
        }


class SemanticAnalyzer:
    """
    Performs semantic analysis and type checking over the AST.
    """

    def __init__(self):
        self.global_scope = Scope(level=0)
        self.current_scope = self.global_scope
        self.errors: List[SemanticError] = []
        self.warnings: List[SemanticError] = []
        self.all_symbols: List[Symbol] = []

    def enter_scope(self) -> None:
        """Enters a new nested lexical block scope."""
        self.current_scope = Scope(level=self.current_scope.level + 1, parent=self.current_scope)

    def exit_scope(self) -> None:
        """Exits current lexical block scope and returns to parent."""
        if self.current_scope.parent:
            self.current_scope = self.current_scope.parent

    def analyze(self, ast: ProgramNode) -> Tuple[List[Dict[str, Any]], List[SemanticError], List[SemanticError]]:
        """
        Analyzes the full AST.
        Returns: (all_symbols_dict, errors, warnings)
        """
        self.visit(ast)
        symbols_table = [sym.to_dict() for sym in self.all_symbols]
        return symbols_table, self.errors, self.warnings

    def visit(self, node: Optional[ASTNode]) -> Optional[str]:
        """
        Generic visitor dispatcher.
        Returns the deduced type of the node ('int', 'float', or None).
        """
        if node is None:
            return None

        method_name = f"visit_{node.__class__.__name__}"
        visitor = getattr(self, method_name, self.generic_visit)
        return visitor(node)

    def generic_visit(self, node: ASTNode) -> Optional[str]:
        return None

    # -----------------------------------------------------------------------
    # Visitor Implementations
    # -----------------------------------------------------------------------

    def visit_ProgramNode(self, node: ProgramNode) -> None:
        for stmt in node.statements:
            self.visit(stmt)

    def visit_VarDeclNode(self, node: VarDeclNode) -> None:
        # Check duplicate declaration in current scope
        existing = self.current_scope.lookup_current(node.name)
        if existing:
            self.errors.append(
                SemanticError(
                    f"Duplicate variable declaration '{node.name}'. "
                    f"Already declared at line {existing.line_declared}.",
                    node.line, node.column
                )
            )
            return

        is_init = False
        val = None

        if node.init_expr is not None:
            expr_type = self.visit(node.init_expr)
            is_init = True

            # Type checking: int <- float warning/error
            if node.var_type == "int" and expr_type == "float":
                self.errors.append(
                    SemanticError(
                        f"Type mismatch: cannot assign float expression to integer variable '{node.name}' "
                        f"without explicit conversion.",
                        node.line, node.column
                    )
                )

        symbol = Symbol(
            name=node.name,
            data_type=node.var_type,
            line_declared=node.line,
            scope_level=self.current_scope.level,
            initialized=is_init
        )
        self.current_scope.define(symbol)
        self.all_symbols.append(symbol)

    def visit_AssignNode(self, node: AssignNode) -> None:
        symbol = self.current_scope.lookup(node.name)
        if not symbol:
            self.errors.append(
                SemanticError(
                    f"Undeclared variable '{node.name}'. Variables must be declared before assignment.",
                    node.line, node.column
                )
            )
            # Evaluate expression anyway to detect errors inside the right hand side
            self.visit(node.expr)
            return

        expr_type = self.visit(node.expr)

        # Type checking
        if symbol.data_type == "int" and expr_type == "float":
            self.errors.append(
                SemanticError(
                    f"Type mismatch: cannot assign float expression to integer variable '{node.name}'.",
                    node.line, node.column
                )
            )

        symbol.initialized = True

    def visit_PrintNode(self, node: PrintNode) -> None:
        self.visit(node.expr)

    def visit_BlockNode(self, node: BlockNode) -> None:
        self.enter_scope()
        for stmt in node.statements:
            self.visit(stmt)
        self.exit_scope()

    def visit_IfNode(self, node: IfNode) -> None:
        self.visit(node.condition)
        self.visit(node.then_branch)
        if node.else_branch:
            self.visit(node.else_branch)

    def visit_WhileNode(self, node: WhileNode) -> None:
        self.visit(node.condition)
        self.visit(node.body)

    def visit_BinaryOpNode(self, node: BinaryOpNode) -> Optional[str]:
        left_type = self.visit(node.left)
        right_type = self.visit(node.right)

        # Check compile-time division by zero
        if node.op == "/":
            if isinstance(node.right, LiteralNode) and (node.right.value == 0 or node.right.value == 0.0):
                self.errors.append(
                    SemanticError(
                        "Division by zero detected at compile time.",
                        node.line, node.column
                    )
                )

        # Relational operators produce int boolean (0 or 1)
        if node.op in ("==", "!=", "<", "<=", ">", ">="):
            return "int"

        # Arithmetic operators: widening float promotion
        if left_type == "float" or right_type == "float":
            return "float"
        return "int"

    def visit_UnaryOpNode(self, node: UnaryOpNode) -> Optional[str]:
        return self.visit(node.expr)

    def visit_LiteralNode(self, node: LiteralNode) -> str:
        return node.val_type

    def visit_VarNode(self, node: VarNode) -> Optional[str]:
        symbol = self.current_scope.lookup(node.name)
        if not symbol:
            self.errors.append(
                SemanticError(
                    f"Undeclared variable '{node.name}'. Must be declared before use.",
                    node.line, node.column
                )
            )
            return None

        if not symbol.initialized:
            self.warnings.append(
                SemanticError(
                    f"Variable '{node.name}' may be used uninitialized.",
                    node.line, node.column, severity="WARNING"
                )
            )

        return symbol.data_type


def analyze_semantics(ast: ProgramNode) -> Tuple[List[Dict[str, Any]], List[SemanticError], List[SemanticError]]:
    """Helper function to run semantic analysis on an AST."""
    analyzer = SemanticAnalyzer()
    return analyzer.analyze(ast)
