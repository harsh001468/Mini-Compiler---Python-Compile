"""
=============================================================================
Main Driver & Pipeline Coordinator
=============================================================================
Project: Mini Compiler – Design and Implementation Using Python
Author: 2nd-year B.Tech AI & Data Science
Purpose:
  Connects all six compiler phases into a unified pipeline:
    1. Lexical Analysis (lexer.py)
    2. Syntax Analysis (parser.py)
    3. Semantic Analysis (semantic.py)
    4. Intermediate Code Generation (intermediate_code.py)
    5. Code Optimization (optimizer.py)
    6. Target Code Generation (code_generator.py)
  Supports execution via Tkinter GUI, CLI arguments, and JSON output mode.
=============================================================================
"""

import sys
import os
import json
import argparse
from typing import Dict, Any

# Ensure package root is in sys.path whether executed from root or inside mini_compiler
CURRENT_DIR = os.path.dirname(os.path.abspath(__file__))
PARENT_DIR = os.path.abspath(os.path.join(CURRENT_DIR, ".."))
if CURRENT_DIR not in sys.path:
    sys.path.insert(0, CURRENT_DIR)
if PARENT_DIR not in sys.path:
    sys.path.insert(0, PARENT_DIR)

try:
    from mini_compiler.lexer import tokenize_code
    from mini_compiler.parser import parse_code
    from mini_compiler.semantic import analyze_semantics
    from mini_compiler.intermediate_code import generate_intermediate_code
    from mini_compiler.optimizer import optimize_code
    from mini_compiler.code_generator import generate_target_code, run_assembly
except ImportError:
    from lexer import tokenize_code
    from parser import parse_code
    from semantic import analyze_semantics
    from intermediate_code import generate_intermediate_code
    from optimizer import optimize_code
    from code_generator import generate_target_code, run_assembly


def compile_pipeline(source_code: str, run_vm: bool = True) -> Dict[str, Any]:
    """
    Executes the entire 6-phase compilation pipeline.
    Returns a comprehensive dictionary with results and diagnostics from each phase.
    """
    result: Dict[str, Any] = {
        "success": False,
        "phases": {},
        "errors": [],
        "warnings": [],
        "execution_output": [],
        "execution_memory": {},
        "execution_cycles": 0,
    }

    # -------------------------------------------------------------------------
    # Phase 1: Lexical Analysis
    # -------------------------------------------------------------------------
    tokens, lex_errors = tokenize_code(source_code)
    token_dicts = [t.to_dict() for t in tokens]
    result["phases"]["lexical"] = {
        "tokens": token_dicts,
        "token_count": len(tokens),
        "errors": [e.to_dict() for e in lex_errors],
    }
    for e in lex_errors:
        result["errors"].append(e.to_dict())

    # Stop if lexical errors occurred
    if lex_errors:
        result["error_phase"] = "Lexical Analysis"
        return result

    # -------------------------------------------------------------------------
    # Phase 2: Syntax Analysis
    # -------------------------------------------------------------------------
    ast, parse_errors = parse_code(tokens)
    result["phases"]["syntax"] = {
        "ast_dict": ast.to_dict() if ast else None,
        "ast_tree": ast.to_tree_str() if ast else "",
        "errors": [e.to_dict() for e in parse_errors],
    }
    for e in parse_errors:
        result["errors"].append(e.to_dict())

    # Stop if syntax errors occurred or AST could not be constructed
    if parse_errors or not ast:
        result["error_phase"] = "Syntax Analysis"
        return result

    # -------------------------------------------------------------------------
    # Phase 3: Semantic Analysis
    # -------------------------------------------------------------------------
    symbols, sem_errors, sem_warnings = analyze_semantics(ast)
    result["phases"]["semantic"] = {
        "symbol_table": symbols,
        "errors": [e.to_dict() for e in sem_errors],
        "warnings": [w.to_dict() for w in sem_warnings],
    }
    for e in sem_errors:
        result["errors"].append(e.to_dict())
    for w in sem_warnings:
        result["warnings"].append(w.to_dict())

    # Stop if semantic errors occurred
    if sem_errors:
        result["error_phase"] = "Semantic Analysis"
        return result

    # -------------------------------------------------------------------------
    # Phase 4: Intermediate Code Generation (Three-Address Code)
    # -------------------------------------------------------------------------
    quads, tac_text = generate_intermediate_code(ast)
    result["phases"]["intermediate"] = {
        "quadruples": [q.to_dict() for q in quads],
        "tac_text": tac_text,
        "quad_count": len(quads),
    }

    # -------------------------------------------------------------------------
    # Phase 5: Code Optimization
    # -------------------------------------------------------------------------
    opt_quads, opt_tac_text, opt_records = optimize_code(quads)
    result["phases"]["optimizer"] = {
        "quadruples": [q.to_dict() for q in opt_quads],
        "tac_text": opt_tac_text,
        "records": [r.to_dict() for r in opt_records],
        "original_count": len(quads),
        "optimized_count": len(opt_quads),
        "reduction_percent": round((1 - len(opt_quads) / max(1, len(quads))) * 100, 1),
    }

    # -------------------------------------------------------------------------
    # Phase 6: Target Code Generation & VM Execution
    # -------------------------------------------------------------------------
    instructions, asm_text, data_vars = generate_target_code(opt_quads)
    result["phases"]["target_code"] = {
        "instructions": [i.to_dict() for i in instructions],
        "assembly_text": asm_text,
        "data_variables": data_vars,
    }

    # Execute in VM Simulator if requested
    if run_vm:
        vm_output, vm_memory, cycles = run_assembly(data_vars, instructions)
        result["execution_output"] = vm_output
        result["execution_memory"] = vm_memory
        result["execution_cycles"] = cycles

    result["success"] = True
    return result


def print_cli_summary(res: Dict[str, Any]) -> None:
    """Pretty prints compilation results to stdout in the terminal."""
    print("=" * 70)
    print(" MINI COMPILER – DESIGN AND IMPLEMENTATION USING PYTHON")
    print("=" * 70)

    if not res["success"]:
        print(f"\n❌ Compilation FAILED during {res.get('error_phase', 'processing')}:")
        for err in res["errors"]:
            print(f"  • Line {err.get('line')}, Col {err.get('column')}: {err.get('message')}")
        return

    print("\n✅ Compilation SUCCEEDED across all 6 phases!\n")

    # Phase 1 Summary
    tokens = res["phases"]["lexical"]["tokens"]
    print(f"1. Lexical Analysis:      {len(tokens)} tokens generated successfully.")

    # Phase 2 Summary
    print(f"2. Syntax Analysis:       AST generated without syntax errors.")

    # Phase 3 Summary
    symbols = res["phases"]["semantic"]["symbol_table"]
    print(f"3. Semantic Analysis:     {len(symbols)} identifiers validated in Symbol Table.")
    if res["warnings"]:
        for w in res["warnings"]:
            print(f"   ⚠️  Warning: Line {w.get('line')}: {w.get('message')}")

    # Phase 4 Summary
    tac_quads = res["phases"]["intermediate"]["quadruples"]
    print(f"4. Intermediate Code:     {len(tac_quads)} TAC quadruples emitted.")

    # Phase 5 Summary
    opt = res["phases"]["optimizer"]
    print(f"5. Code Optimization:     {len(opt['records'])} optimization transformations applied.")
    print(f"                          Instructions reduced: {opt['original_count']} -> {opt['optimized_count']} ({opt['reduction_percent']}% reduction).")

    # Phase 6 Summary
    asm = res["phases"]["target_code"]
    print(f"6. Target Code:           {len(asm['instructions'])} Assembly instructions generated.")

    # Execution Output
    print("\n" + "-" * 70)
    print(" VIRTUAL MACHINE EXECUTION OUTPUT:")
    print("-" * 70)
    if res["execution_output"]:
        for line in res["execution_output"]:
            print(f" >> {line}")
    else:
        print(" (Program produced no output)")
    print(f" Final Memory State: {res['execution_memory']}")
    print(f" Simulated Cycles:   {res['execution_cycles']}")
    print("=" * 70)


def main():
    parser = argparse.ArgumentParser(description="Mini Compiler – Design and Implementation Using Python")
    parser.add_argument("file", nargs="?", help="Source code file (.mc or .txt) to compile")
    parser.add_argument("--code", type=str, help="Direct source code string to compile")
    parser.add_argument("--json", action="store_true", help="Output results as JSON for GUI / web consumption")
    parser.add_argument("--test", action="store_true", help="Run the test suite (test_cases.py)")
    parser.add_argument("--gui", action="store_true", help="Launch Tkinter desktop GUI")

    args = parser.parse_args()

    # If --test requested, run test suite
    if args.test:
        from mini_compiler.test_cases import run_all_tests
        run_all_tests()
        return

    # If --code provided
    if args.code:
        source_code = args.code
        res = compile_pipeline(source_code)
        if args.json:
            print(json.dumps(res, indent=2))
        else:
            print_cli_summary(res)
        return

    # If file provided
    if args.file:
        if not os.path.exists(args.file):
            print(f"Error: File '{args.file}' not found.", file=sys.stderr)
            sys.exit(1)
        with open(args.file, "r") as f:
            source_code = f.read()
        res = compile_pipeline(source_code)
        if args.json:
            print(json.dumps(res, indent=2))
        else:
            print_cli_summary(res)
        return

    # Default without args: launch GUI if Tkinter is available
    try:
        import tkinter
        from mini_compiler.gui import launch_gui
        print("Launching Mini Compiler Desktop GUI...")
        launch_gui()
    except (ImportError, Exception) as e:
        # Fallback to demonstration CLI if Tkinter / X11 not present
        sample_code = """int a = 10;
int b = 20;
int c;
c = a + b * 2;
print(c);"""
        print(f"Note: Desktop Tkinter GUI is ready for VS Code/desktop (Tkinter display: {e}).")
        print("Running demonstration CLI on standard sample program:\n")
        print("Input Code:\n" + sample_code + "\n")
        res = compile_pipeline(sample_code)
        print_cli_summary(res)
        print("\nTip: Run 'python -m mini_compiler.test_cases' or 'python mini_compiler/test_cases.py' for full test cases.")


if __name__ == "__main__":
    main()
