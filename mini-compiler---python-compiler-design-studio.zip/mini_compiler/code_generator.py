"""
=============================================================================
Phase 6: Target Code Generation & Virtual Machine Simulator
=============================================================================
Project: Mini Compiler – Design and Implementation Using Python
Author: 2nd-year B.Tech AI & Data Science
Purpose:
  Translates optimized Three-Address Code into a clean, register-based
  assembly-like target architecture (.data and .text segments).
  Includes a built-in Target Machine Virtual Simulator (VM) so students and
  evaluators can execute the target code and view the actual output.
=============================================================================
Instruction Set Architecture (ISA):
  LOAD  Rd, [var]        ; Load variable value from memory into Rd
  LOADI Rd, imm          ; Load immediate numeric literal into Rd
  STORE [var], Rs        ; Store value from Rs into variable memory
  ADD   Rd, Rs1, Rs2     ; Rd = Rs1 + Rs2
  SUB   Rd, Rs1, Rs2     ; Rd = Rs1 - Rs2
  MUL   Rd, Rs1, Rs2     ; Rd = Rs1 * Rs2
  DIV   Rd, Rs1, Rs2     ; Rd = Rs1 / Rs2
  MOD   Rd, Rs1, Rs2     ; Rd = Rs1 % Rs2
  NEG   Rd, Rs           ; Rd = -Rs
  MOV   Rd, Rs           ; Rd = Rs
  CMP   Rs1, Rs2         ; Compare Rs1 with Rs2
  JMP   label            ; Unconditional jump to label
  JEQ   label            ; Jump if equal
  JNE   label            ; Jump if not equal
  JLT   label            ; Jump if less than
  JLE   label            ; Jump if less than or equal
  JGT   label            ; Jump if greater than
  JGE   label            ; Jump if greater than or equal
  PRINT Rs               ; Output value of register Rs to console
  HALT                   ; Stop execution
=============================================================================
"""

from typing import List, Dict, Any, Tuple, Optional, Set
from mini_compiler.intermediate_code import Quadruple
from mini_compiler.optimizer import is_number, parse_num


class AssemblyInstruction:
    """Represents a single assembly instruction."""

    def __init__(self, op: str, args: Optional[List[str]] = None, label: Optional[str] = None, comment: str = ""):
        self.label = label
        self.op = op
        self.args = args or []
        self.comment = comment

    def __str__(self) -> str:
        if self.label:
            return f"{self.label}:"
        args_str = ", ".join(self.args)
        line = f"    {self.op:<8} {args_str}"
        if self.comment:
            line = f"{line:<36} ; {self.comment}"
        return line

    def to_dict(self) -> Dict[str, Any]:
        return {
            "label": self.label,
            "op": self.op,
            "args": self.args,
            "comment": self.comment,
            "text": str(self),
        }


class RegisterAllocator:
    """Simple linear-scan register allocator with round-robin reuse."""

    def __init__(self, num_registers: int = 8):
        self.registers = [f"R{i}" for i in range(num_registers)]
        self.var_to_reg: Dict[str, str] = {}
        self.reg_to_var: Dict[str, str] = {}
        self.next_reg_idx = 0

    def get_reg_for(self, var_name: str) -> str:
        """Returns or assigns a register for variable/temp name."""
        if var_name in self.var_to_reg:
            return self.var_to_reg[var_name]

        reg = self.registers[self.next_reg_idx]
        self.next_reg_idx = (self.next_reg_idx + 1) % len(self.registers)

        # Evict prior owner if any
        if reg in self.reg_to_var:
            old_var = self.reg_to_var[reg]
            if old_var in self.var_to_reg:
                del self.var_to_reg[old_var]

        self.var_to_reg[var_name] = reg
        self.reg_to_var[reg] = var_name
        return reg


class CodeGenerator:
    """
    Translates Three-Address Code quadruples into assembly-like instructions.
    """

    def __init__(self, quadruples: List[Quadruple]):
        self.quads = quadruples
        self.instructions: List[AssemblyInstruction] = []
        self.data_vars: Dict[str, str] = {}  # var_name -> initial_value
        self.reg_alloc = RegisterAllocator()

    def generate(self) -> Tuple[List[AssemblyInstruction], str]:
        """
        Emits data segment and text segment instructions.
        Returns: (instruction_objects, formatted_assembly_text)
        """
        # Step 1: Scan for variable declarations
        for q in self.quads:
            if q.op == "VAR_DECL":
                init_val = "0.0" if q.arg1 == "float" else "0"
                self.data_vars[q.result] = init_val
            elif q.result and not q.result.startswith("t") and not q.result.startswith("L") and q.op not in ("LABEL", "GOTO", "IF_GOTO", "IF_REL_GOTO", "PRINT"):
                if q.result not in self.data_vars:
                    self.data_vars[q.result] = "0"

        # Step 2: Translate instructions
        for q in self.quads:
            self.translate_quad(q)

        # Append HALT at the end of text segment
        self.instructions.append(AssemblyInstruction("HALT", comment="End of program"))

        # Build full formatted assembly string
        lines = [
            "; ========================================================",
            "; Target Assembly Code generated by Mini Compiler",
            "; Architecture: 32-bit Register Machine (R0-R7)",
            "; ========================================================",
            "",
            "SECTION .data",
        ]
        if self.data_vars:
            for var, val in sorted(self.data_vars.items()):
                lines.append(f"    {var:<12} .word {val}")
        else:
            lines.append("    ; (no global variables declared)")

        lines.extend([
            "",
            "SECTION .text",
            "    GLOBAL _start",
            "_start:",
        ])

        for inst in self.instructions:
            lines.append(str(inst))

        full_asm = "\n".join(lines)
        return self.instructions, full_asm

    def load_operand(self, operand: str) -> str:
        """Loads variable or numeric constant into an available register."""
        if is_number(operand):
            r = self.reg_alloc.get_reg_for(f"__imm_{operand}__")
            self.instructions.append(AssemblyInstruction("LOADI", [r, operand], comment=f"Load immediate {operand}"))
            return r
        elif operand.startswith("t") and operand in self.reg_alloc.var_to_reg:
            # Temporary is already resident in an allocated register
            return self.reg_alloc.var_to_reg[operand]
        else:
            # Memory variable
            r = self.reg_alloc.get_reg_for(operand)
            self.instructions.append(AssemblyInstruction("LOAD", [r, f"[{operand}]"], comment=f"Load var {operand}"))
            return r

    def translate_quad(self, q: Quadruple) -> None:
        if q.op == "VAR_DECL":
            # Already handled in data section
            return

        elif q.op == "LABEL":
            self.instructions.append(AssemblyInstruction("", label=q.result))

        elif q.op == "GOTO":
            self.instructions.append(AssemblyInstruction("JMP", [q.result]))

        elif q.op == "IF_GOTO":
            r_cond = self.load_operand(q.arg1)
            r_zero = self.reg_alloc.get_reg_for("__imm_0__")
            self.instructions.append(AssemblyInstruction("LOADI", [r_zero, "0"]))
            self.instructions.append(AssemblyInstruction("CMP", [r_cond, r_zero]))
            self.instructions.append(AssemblyInstruction("JNE", [q.result], comment=f"Jump to {q.result} if true"))

        elif q.op == "IF_REL_GOTO":
            # q.arg1: left_var, q.arg2: "relop right_var", q.result: label
            parts = q.arg2.split(maxsplit=1)
            relop = parts[0]
            right_operand = parts[1] if len(parts) > 1 else "0"

            r_left = self.load_operand(q.arg1)
            r_right = self.load_operand(right_operand)

            self.instructions.append(AssemblyInstruction("CMP", [r_left, r_right]))

            jump_map = {
                "==": "JEQ",
                "!=": "JNE",
                "<": "JLT",
                "<=": "JLE",
                ">": "JGT",
                ">=": "JGE",
            }
            jump_inst = jump_map.get(relop, "JNE")
            self.instructions.append(AssemblyInstruction(jump_inst, [q.result], comment=f"if {q.arg1} {relop} {right_operand}"))

        elif q.op == "=":
            r_src = self.load_operand(q.arg1)
            if not q.result.startswith("t"):
                # Store into named memory variable
                self.instructions.append(AssemblyInstruction("STORE", [f"[{q.result}]", r_src], comment=f"Store result to {q.result}"))
            else:
                # Keep in register for temporary
                r_dest = self.reg_alloc.get_reg_for(q.result)
                if r_dest != r_src:
                    self.instructions.append(AssemblyInstruction("MOV", [r_dest, r_src], comment=f"{q.result} = {q.arg1}"))

        elif q.op in ("+", "-", "*", "/", "%"):
            r1 = self.load_operand(q.arg1)
            r2 = self.load_operand(q.arg2)
            r_dest = self.reg_alloc.get_reg_for(q.result)

            op_map = {
                "+": "ADD",
                "-": "SUB",
                "*": "MUL",
                "/": "DIV",
                "%": "MOD",
            }
            inst_name = op_map[q.op]
            self.instructions.append(AssemblyInstruction(inst_name, [r_dest, r1, r2]))

            if not q.result.startswith("t"):
                self.instructions.append(AssemblyInstruction("STORE", [f"[{q.result}]", r_dest]))

        elif q.op == "UNARY_MINUS":
            r_src = self.load_operand(q.arg1)
            r_dest = self.reg_alloc.get_reg_for(q.result)
            self.instructions.append(AssemblyInstruction("NEG", [r_dest, r_src]))
            if not q.result.startswith("t"):
                self.instructions.append(AssemblyInstruction("STORE", [f"[{q.result}]", r_dest]))

        elif q.op == "PRINT":
            r_val = self.load_operand(q.arg1)
            self.instructions.append(AssemblyInstruction("PRINT", [r_val], comment=f"Print {q.arg1}"))


class VirtualMachine:
    """
    Simulates execution of the generated target assembly instructions.
    Useful for testing, educational demonstrations, and B.Tech viva evaluations.
    """

    def __init__(self, data_vars: Dict[str, str], instructions: List[AssemblyInstruction]):
        self.memory: Dict[str, Any] = {k: parse_num(v) for k, v in data_vars.items()}
        self.registers: Dict[str, Any] = {f"R{i}": 0 for i in range(8)}
        self.instructions = instructions
        self.pc = 0
        self.cmp_flag = 0  # -1 if less, 0 if equal, 1 if greater
        self.output: List[str] = []
        self.labels: Dict[str, int] = {}

        # Resolve labels to instruction indices
        for idx, inst in enumerate(self.instructions):
            if inst.label:
                self.labels[inst.label] = idx

    def run(self, max_cycles: int = 10000) -> Tuple[List[str], Dict[str, Any], int]:
        """
        Executes instructions until HALT or max_cycles.
        Returns: (output_lines, final_memory, cycles_executed)
        """
        cycles = 0

        while 0 <= self.pc < len(self.instructions) and cycles < max_cycles:
            inst = self.instructions[self.pc]
            cycles += 1

            if inst.label:
                self.pc += 1
                continue

            op = inst.op
            args = inst.args

            if op == "HALT":
                break

            elif op == "LOADI":
                rd, imm = args[0], parse_num(args[1])
                self.registers[rd] = imm
                self.pc += 1

            elif op == "LOAD":
                rd, var = args[0], args[1].strip("[]")
                self.registers[rd] = self.memory.get(var, 0)
                self.pc += 1

            elif op == "STORE":
                var, rs = args[0].strip("[]"), args[1]
                self.memory[var] = self.registers.get(rs, 0)
                self.pc += 1

            elif op == "MOV":
                rd, rs = args[0], args[1]
                self.registers[rd] = self.registers.get(rs, 0)
                self.pc += 1

            elif op == "ADD":
                rd, r1, r2 = args[0], args[1], args[2]
                self.registers[rd] = self.registers[r1] + self.registers[r2]
                self.pc += 1

            elif op == "SUB":
                rd, r1, r2 = args[0], args[1], args[2]
                self.registers[rd] = self.registers[r1] - self.registers[r2]
                self.pc += 1

            elif op == "MUL":
                rd, r1, r2 = args[0], args[1], args[2]
                self.registers[rd] = self.registers[r1] * self.registers[r2]
                self.pc += 1

            elif op == "DIV":
                rd, r1, r2 = args[0], args[1], args[2]
                denom = self.registers[r2]
                if denom == 0:
                    self.output.append("[Runtime Error] Division by zero!")
                    break
                if isinstance(self.registers[r1], float) or isinstance(denom, float):
                    self.registers[rd] = self.registers[r1] / denom
                else:
                    self.registers[rd] = self.registers[r1] // denom
                self.pc += 1

            elif op == "MOD":
                rd, r1, r2 = args[0], args[1], args[2]
                denom = self.registers[r2]
                if denom == 0:
                    self.output.append("[Runtime Error] Modulo by zero!")
                    break
                self.registers[rd] = self.registers[r1] % denom
                self.pc += 1

            elif op == "NEG":
                rd, rs = args[0], args[1]
                self.registers[rd] = -self.registers[rs]
                self.pc += 1

            elif op == "CMP":
                r1, r2 = args[0], args[1]
                v1 = self.registers[r1]
                v2 = self.registers[r2]
                if v1 < v2:
                    self.cmp_flag = -1
                elif v1 > v2:
                    self.cmp_flag = 1
                else:
                    self.cmp_flag = 0
                self.pc += 1

            elif op == "JMP":
                target = args[0]
                self.pc = self.labels.get(target, len(self.instructions))

            elif op == "JEQ":
                target = args[0]
                if self.cmp_flag == 0:
                    self.pc = self.labels.get(target, len(self.instructions))
                else:
                    self.pc += 1

            elif op == "JNE":
                target = args[0]
                if self.cmp_flag != 0:
                    self.pc = self.labels.get(target, len(self.instructions))
                else:
                    self.pc += 1

            elif op == "JLT":
                target = args[0]
                if self.cmp_flag < 0:
                    self.pc = self.labels.get(target, len(self.instructions))
                else:
                    self.pc += 1

            elif op == "JLE":
                target = args[0]
                if self.cmp_flag <= 0:
                    self.pc = self.labels.get(target, len(self.instructions))
                else:
                    self.pc += 1

            elif op == "JGT":
                target = args[0]
                if self.cmp_flag > 0:
                    self.pc = self.labels.get(target, len(self.instructions))
                else:
                    self.pc += 1

            elif op == "JGE":
                target = args[0]
                if self.cmp_flag >= 0:
                    self.pc = self.labels.get(target, len(self.instructions))
                else:
                    self.pc += 1

            elif op == "PRINT":
                rs = args[0]
                val = self.registers.get(rs, 0)
                self.output.append(str(val))
                self.pc += 1

            else:
                self.pc += 1

        return self.output, self.memory, cycles


def generate_target_code(quadruples: List[Quadruple]) -> Tuple[List[AssemblyInstruction], str, Dict[str, str]]:
    """Helper function to generate target code from TAC."""
    cg = CodeGenerator(quadruples)
    instructions, asm_text = cg.generate()
    return instructions, asm_text, cg.data_vars


def run_assembly(data_vars: Dict[str, str], instructions: List[AssemblyInstruction]) -> Tuple[List[str], Dict[str, Any], int]:
    """Helper function to execute target assembly code in VM simulator."""
    vm = VirtualMachine(data_vars, instructions)
    return vm.run()
