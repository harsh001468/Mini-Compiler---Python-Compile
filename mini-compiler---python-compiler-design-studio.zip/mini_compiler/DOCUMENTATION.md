# Mini Compiler System Architecture & Phase Documentation
### B.Tech 2nd Year (AI&DS / CSE) Compiler Design Project

---

## 1. Architectural Pipeline Diagram

```
                 +-----------------------+
                 |  Source Code (.mc)    |
                 +-----------------------+
                             |
                             v
                 +-----------------------+
                 |   Phase 1: LEXER      |  <-- Tracks line & column, handles invalid tokens
                 +-----------------------+
                             |  Token Stream (Token Objects)
                             v
                 +-----------------------+
                 |   Phase 2: PARSER     |  <-- Recursive Descent (LL(1)), AST construction
                 +-----------------------+
                             |  Abstract Syntax Tree (AST)
                             v
                 +-----------------------+
                 |  Phase 3: SEMANTIC    |  <-- Scoped Symbol Table, Types, Div-by-Zero
                 +-----------------------+
                             |  Validated AST + Symbol Table
                             v
                 +-----------------------+
                 |   Phase 4: TAC GEN    |  <-- Three-Address Code Quadruples (op, a1, a2, r)
                 +-----------------------+
                             |  Raw Quadruple Stream
                             v
                 +-----------------------+
                 |   Phase 5: OPTIMIZER  |  <-- Constant Folding, Propagation, CSE, DCE
                 +-----------------------+
                             |  Optimized Quadruple Stream
                             v
                 +-----------------------+
                 | Phase 6: CODE GEN/VM  |  <-- 32-bit Assembly ISA + Virtual Simulator
                 +-----------------------+
                             |
                             v
                 +-----------------------+
                 | Execution Output / VM |
                 +-----------------------+
```

---

## 2. Module Specifications

### `lexer.py`
- **Class `TokenType`**: Enums for keywords, identifiers, constants, operators, and delimiters.
- **Class `Token`**: Encapsulates `(type, value, line, column)`.
- **Class `Lexer`**:
  - `current_char()`, `advance()`, `peek()`
  - `skip_whitespace()`, `skip_comments()` (supports `//`, `#`, and `/* ... */`)
  - `read_number()`: Distinguishes between `int` and `float` literals.
  - `read_identifier_or_keyword()`: Matches against reserved keyword table.
  - `tokenize()`: Returns `(tokens, lexical_errors)`.

### `parser.py`
- **AST Nodes**:
  - `ProgramNode(statements)`
  - `VarDeclNode(var_type, name, init_expr, line, column)`
  - `AssignNode(name, expr, line, column)`
  - `IfNode(condition, then_branch, else_branch, line, column)`
  - `WhileNode(condition, body, line, column)`
  - `PrintNode(expr, line, column)`
  - `BlockNode(statements, line, column)`
  - `BinaryOpNode(left, op, right, line, column)`
  - `UnaryOpNode(op, expr, line, column)`
  - `LiteralNode(value, val_type, line, column)`
  - `VarNode(name, line, column)`
- **Class `Parser`**:
  - `statement()` dispatcher
  - `expression()`, `term()`, `factor()`, `primary()` operator precedence cascade
  - Panic-mode error recovery via `synchronize()`.

### `semantic.py`
- **Class `Symbol`**: `(name, data_type, line_declared, scope_level, initialized)`.
- **Class `Scope`**: Dictionary with lexical parent pointer.
- **Class `SemanticAnalyzer`**:
  - Type checking & promotion rules (`int + float -> float`).
  - Detection of duplicate identifiers in same scope.
  - Detection of undeclared variables.
  - Compile-time division by zero detection.

### `intermediate_code.py`
- **Class `Quadruple`**: `(op, arg1, arg2, result)` with `.to_tac_string()`.
- **Class `TACGenerator`**:
  - `new_temp()`: Allocates `t0, t1, t2, ...`
  - `new_label()`: Allocates `L0, L1, L2, ...`
  - Emits linear jumps for `if-else` and `while` loop conditions.

### `optimizer.py`
- **Class `Optimizer`**:
  - `pass_constant_propagation_and_folding()`: Replaces variables with static values and evaluates constant arithmetic.
  - `pass_common_subexpression_elimination()`: Hashes `(op, arg1, arg2)` to reuse existing computations.
  - `pass_dead_code_elimination()`: Eliminates dead temporaries, redundant `x = x` assignments, and unreachable code after unconditional jumps.

### `code_generator.py`
- **Class `RegisterAllocator`**: Linear register manager for `R0` through `R7`.
- **Class `CodeGenerator`**: Generates `.data` and `.text` assembly listings.
- **Class `VirtualMachine`**: Executes simulated assembly instructions and simulates registers, memory, program counter, and standard I/O.
