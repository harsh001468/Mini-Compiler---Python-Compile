"""
=============================================================================
Phase 5: Code Optimization (Machine-Independent Optimizer)
=============================================================================
Project: Mini Compiler – Design and Implementation Using Python
Author: 2nd-year B.Tech AI & Data Science
Purpose:
  Applies classical compiler optimizations on the Three-Address Code:
    1. Constant Folding: Evaluates constant expressions at compile-time.
    2. Constant Propagation: Propagates known constants to subsequent uses.
    3. Common Subexpression Elimination (CSE): Reuses previously computed values.
    4. Dead Code Elimination (DCE): Removes unused temporaries and dead jumps.
  Maintains an audit trail of every optimization applied for academic review.
=============================================================================
"""

from typing import List, Tuple, Dict, Any, Optional, Set
from mini_compiler.intermediate_code import Quadruple


class OptimizationRecord:
    """Records an optimization event for educational inspection."""
    def __init__(self, opt_type: str, details: str, before: str, after: str):
        self.opt_type = opt_type
        self.details = details
        self.before = before
        self.after = after

    def __repr__(self) -> str:
        return f"[{self.opt_type}] {self.details}: '{self.before}' -> '{self.after}'"

    def to_dict(self) -> Dict[str, str]:
        return {
            "type": self.opt_type,
            "details": self.details,
            "before": self.before,
            "after": self.after,
        }


def is_number(val: str) -> bool:
    """Returns True if string represents an integer or floating-point constant."""
    if not val:
        return False
    try:
        float(val)
        return True
    except ValueError:
        return False


def parse_num(val: str):
    """Parses a numerical constant into int or float."""
    try:
        if "." in val:
            return float(val)
        return int(val)
    except ValueError:
        return val


class Optimizer:
    """
    Performs multi-pass machine-independent optimization over TAC quadruples.
    """

    def __init__(self, quadruples: List[Quadruple]):
        # Deep copy quadruples so original remains untouched
        self.quads: List[Quadruple] = [
            Quadruple(q.op, q.arg1, q.arg2, q.result) for q in quadruples
        ]
        self.records: List[OptimizationRecord] = []

    def optimize(self) -> Tuple[List[Quadruple], str, List[OptimizationRecord]]:
        """
        Runs iterative optimization passes until fixed point is reached.
        Returns: (optimized_quads, optimized_tac_text, optimization_records)
        """
        changed = True
        max_passes = 10
        current_pass = 0

        while changed and current_pass < max_passes:
            changed = False
            current_pass += 1

            # Pass 1: Constant Propagation & Folding within basic blocks
            p1_changed = self.pass_constant_propagation_and_folding()
            # Pass 2: Common Subexpression Elimination (CSE)
            p2_changed = self.pass_common_subexpression_elimination()
            # Pass 3: Dead Code Elimination (DCE)
            p3_changed = self.pass_dead_code_elimination()

            if p1_changed or p2_changed or p3_changed:
                changed = True

        opt_tac_text = "\n".join(f"{i:03d}:  {q.to_tac_string()}" for i, q in enumerate(self.quads))
        return self.quads, opt_tac_text, self.records

    def pass_constant_propagation_and_folding(self) -> bool:
        """
        Scans instructions and applies:
          1. Constant propagation: substitute known constant values.
          2. Constant folding: compute arithmetic on constants.
        """
        changed = False
        const_map: Dict[str, str] = {}  # var_name -> constant_string

        for q in self.quads:
            old_str = q.to_tac_string()

            # Invalidate constants across labels or jumps (simple basic block boundary)
            if q.op in ("LABEL", "GOTO", "IF_GOTO", "IF_REL_GOTO"):
                const_map.clear()
                continue

            # Constant Propagation on arg1
            if q.arg1 in const_map and q.op != "VAR_DECL":
                orig_arg1 = q.arg1
                q.arg1 = const_map[orig_arg1]
                self.records.append(
                    OptimizationRecord("Constant Propagation", f"Replaced '{orig_arg1}' with constant '{q.arg1}'",
                                       old_str, q.to_tac_string())
                )
                changed = True
                old_str = q.to_tac_string()

            # Constant Propagation on arg2
            if q.arg2 in const_map:
                orig_arg2 = q.arg2
                q.arg2 = const_map[orig_arg2]
                self.records.append(
                    OptimizationRecord("Constant Propagation", f"Replaced '{orig_arg2}' with constant '{q.arg2}'",
                                       old_str, q.to_tac_string())
                )
                changed = True
                old_str = q.to_tac_string()

            # Constant Folding on Binary Arithmetic operations
            if q.op in ("+", "-", "*", "/", "%") and is_number(q.arg1) and is_number(q.arg2):
                v1 = parse_num(q.arg1)
                v2 = parse_num(q.arg2)
                res_val = None

                try:
                    if q.op == "+":
                        res_val = v1 + v2
                    elif q.op == "-":
                        res_val = v1 - v2
                    elif q.op == "*":
                        res_val = v1 * v2
                    elif q.op == "/":
                        if v2 != 0:
                            res_val = v1 / v2 if (isinstance(v1, float) or isinstance(v2, float)) else (v1 // v2)
                    elif q.op == "%":
                        if v2 != 0:
                            res_val = v1 % v2

                    if res_val is not None:
                        # Convert float to int if integer literal
                        if isinstance(res_val, float) and res_val.is_integer() and isinstance(v1, int) and isinstance(v2, int):
                            res_val = int(res_val)

                        orig_op = q.op
                        q.op = "="
                        q.arg1 = str(res_val)
                        q.arg2 = ""
                        self.records.append(
                            OptimizationRecord("Constant Folding", f"Computed {v1} {orig_op} {v2} = {res_val}",
                                               old_str, q.to_tac_string())
                        )
                        changed = True
                        old_str = q.to_tac_string()
                except Exception:
                    pass

            # Update constant map if this is an assignment of a constant
            if q.op == "=" and is_number(q.arg1) and q.result:
                const_map[q.result] = q.arg1
            elif q.result in const_map:
                # Variable was modified by non-constant
                del const_map[q.result]

        return changed

    def pass_common_subexpression_elimination(self) -> bool:
        """
        Detects duplicate computations (arg1 op arg2) in the same basic block
        and replaces the subsequent computation with the previously computed variable.
        """
        changed = False
        expr_map: Dict[Tuple[str, str, str], str] = {}  # (op, arg1, arg2) -> result_var

        for q in self.quads:
            old_str = q.to_tac_string()

            # Control flow boundaries invalidate CSE cache
            if q.op in ("LABEL", "GOTO", "IF_GOTO", "IF_REL_GOTO"):
                expr_map.clear()
                continue

            # Check if this instruction computes a binary subexpression
            if q.op in ("+", "-", "*", "/", "%", "==", "!=", "<", "<=", ">", ">="):
                key = (q.op, q.arg1, q.arg2)
                # Commutative operators can match reversed args (+ and *)
                comm_key = (q.op, q.arg2, q.arg1) if q.op in ("+", "*") else None

                matched_prev = expr_map.get(key)
                if not matched_prev and comm_key:
                    matched_prev = expr_map.get(comm_key)

                if matched_prev and matched_prev != q.result:
                    # Common subexpression found!
                    q.op = "="
                    q.arg1 = matched_prev
                    q.arg2 = ""
                    self.records.append(
                        OptimizationRecord(
                            "Common Subexpression Elimination",
                            f"Reused previous computation from '{matched_prev}'",
                            old_str, q.to_tac_string()
                        )
                    )
                    changed = True
                else:
                    expr_map[key] = q.result

            # If an operand variable is redefined, remove expressions containing it
            if q.result:
                keys_to_remove = [k for k in expr_map if k[1] == q.result or k[2] == q.result]
                for k in keys_to_remove:
                    del expr_map[k]

        return changed

    def pass_dead_code_elimination(self) -> bool:
        """
        Removes:
          1. Dead temporary assignments: 'tX = ...' where tX is never read later.
          2. Unreachable code after unconditional jumps.
          3. Redundant self-assignments: 'x = x'.
        """
        changed = False

        # Step 1: Collect all used variables
        used_vars: Set[str] = set()
        for q in self.quads:
            if q.op != "VAR_DECL":
                if q.arg1 and not is_number(q.arg1):
                    used_vars.add(q.arg1)
                if q.arg2 and not is_number(q.arg2):
                    # Check for "relop val" in IF_REL_GOTO
                    parts = q.arg2.split()
                    for p in parts:
                        if not is_number(p) and p not in ("==", "!=", "<", "<=", ">", ">="):
                            used_vars.add(p)

        new_quads: List[Quadruple] = []
        is_unreachable = False

        for q in self.quads:
            # Check for label (re-enables reachability)
            if q.op == "LABEL":
                is_unreachable = False
                new_quads.append(q)
                continue

            if is_unreachable:
                self.records.append(
                    OptimizationRecord("Dead Code Elimination", "Removed unreachable instruction after unconditional jump",
                                       q.to_tac_string(), "(removed)")
                )
                changed = True
                continue

            # Remove redundant self-assignment: x = x
            if q.op == "=" and q.arg1 == q.result:
                self.records.append(
                    OptimizationRecord("Dead Code Elimination", f"Removed redundant self-assignment '{q.result} = {q.result}'",
                                       q.to_tac_string(), "(removed)")
                )
                changed = True
                continue

            # Check if temporary variable is dead (never read anywhere)
            if q.result and q.result.startswith("t") and q.result not in used_vars and q.op != "PRINT":
                self.records.append(
                    OptimizationRecord("Dead Code Elimination", f"Removed dead temporary assignment '{q.result}'",
                                       q.to_tac_string(), "(removed)")
                )
                changed = True
                continue

            new_quads.append(q)

            # Unconditional jump makes subsequent instructions unreachable until next label
            if q.op == "GOTO":
                is_unreachable = True

        self.quads = new_quads
        return changed


def optimize_code(quadruples: List[Quadruple]) -> Tuple[List[Quadruple], str, List[OptimizationRecord]]:
    """Helper function to optimize TAC quadruples."""
    optimizer = Optimizer(quadruples)
    return optimizer.optimize()
