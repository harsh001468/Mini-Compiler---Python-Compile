import { PresetProgram, VivaQuestion } from '../types';

export const PRESET_PROGRAMS: PresetProgram[] = [
  {
    id: 1,
    name: 'Valid Arithmetic & Expression Precedence',
    category: 'Basic Language',
    description: 'Demonstrates declarations, operator precedence (* before +), and console output.',
    code: `int a = 10;
int b = 20;
int c;
c = a + b * 2;
print(c);`,
    expectedOutput: ['50'],
  },
  {
    id: 2,
    name: 'Invalid Token Detection (Lexical Error)',
    category: 'Negative Testing',
    description: 'Demonstrates lexical phase error reporting with unrecognized character @.',
    code: `int @invalidVar = 50;
print(@invalidVar);`,
  },
  {
    id: 3,
    name: 'Missing Semicolon (Syntax Error)',
    category: 'Negative Testing',
    description: 'Demonstrates parser error detection when a statement delimiter is omitted.',
    code: `int x = 10
int y = 20;
print(x + y);`,
  },
  {
    id: 4,
    name: 'Undeclared Variable (Semantic Error)',
    category: 'Negative Testing',
    description: 'Demonstrates symbol table lookup error when variable is used before declaration.',
    code: `int a = 15;
b = a + 5;
print(b);`,
  },
  {
    id: 5,
    name: 'Duplicate Variable Declaration (Semantic Error)',
    category: 'Negative Testing',
    description: 'Demonstrates scope conflict when declaring same identifier twice.',
    code: `int score = 95;
int score = 100;
print(score);`,
  },
  {
    id: 6,
    name: 'Type Mismatch (Semantic Error)',
    category: 'Negative Testing',
    description: 'Demonstrates static type checking when assigning float to integer variable.',
    code: `int counter;
counter = 3.14159;
print(counter);`,
  },
  {
    id: 7,
    name: 'Complex Parentheses & Precedence',
    category: 'Arithmetic',
    description: 'Nested parenthesized expression: (10 + 5) * (20 - 4) / 2 = 120.',
    code: `int x = (10 + 5) * (20 - 4) / 2;
print(x);`,
    expectedOutput: ['120'],
  },
  {
    id: 8,
    name: 'If-Else Conditional Branching',
    category: 'Control Flow',
    description: 'Relational comparison (val > 20) with then and else branches and jumps.',
    code: `int val = 25;
int flag;
if (val > 20) {
    flag = 1;
} else {
    flag = 0;
}
print(flag);`,
    expectedOutput: ['1'],
  },
  {
    id: 9,
    name: 'While Loop Iteration & Summation',
    category: 'Control Flow',
    description: 'Iterative while loop accumulating 1 + 2 + 3 + 4 + 5 = 15.',
    code: `int i = 1;
int sum = 0;
while (i <= 5) {
    sum = sum + i;
    i = i + 1;
}
print(sum);`,
    expectedOutput: ['15'],
  },
  {
    id: 10,
    name: 'Division by Zero (Semantic Detection)',
    category: 'Negative Testing',
    description: 'Compile-time detection and error flagging of division by literal zero.',
    code: `int a = 100;
int b = a / 0;
print(b);`,
  },
  {
    id: 11,
    name: 'Constant Folding & Propagation',
    category: 'Optimization',
    description: 'Optimizer computes 2 + 3 * 4 = 14, propagates to b = 14 + 5 = 19, dead code eliminated.',
    code: `int a = 2 + 3 * 4;
int b = a + 5;
print(b);`,
    expectedOutput: ['19'],
  },
  {
    id: 12,
    name: 'Common Subexpression Elimination (CSE)',
    category: 'Optimization',
    description: 'Optimizer detects duplicate computation a * b and reuses temporary result.',
    code: `int a = 7;
int b = 3;
int x = a * b;
int y = a * b;
print(x + y);`,
    expectedOutput: ['42'],
  },
];

export const VIVA_QUESTIONS: VivaQuestion[] = [
  {
    id: 1,
    category: 'Phases of Compiler',
    question: 'What is a Compiler and what are its front-end vs back-end phases?',
    answer: 'A compiler translates high-level code to target assembly/machine code. Front-end comprises Lexical Analysis (tokenizing), Syntax Analysis (parsing/AST), and Semantic Analysis (type & scope validation). Back-end comprises Intermediate Code Generation (Three-Address Code), Machine-Independent Optimization (Constant folding, CSE, DCE), and Target Code Generation (register allocation and assembly instructions).',
  },
  {
    id: 2,
    category: 'Lexical Analysis',
    question: 'What is the distinction between a Lexeme, a Pattern, and a Token?',
    answer: 'A Token is an abstract category (e.g. IDENTIFIER, INT_CONST, KEYWORD_INT). A Pattern is the formal rule or regular expression defining valid characters for that token (e.g. [a-zA-Z_][a-zA-Z0-9_]*). A Lexeme is the actual character sequence extracted from the source code matching the pattern (e.g. count, 42, int).',
  },
  {
    id: 3,
    category: 'Syntax Analysis',
    question: 'What is a Recursive Descent Parser? Is it Top-Down or Bottom-Up?',
    answer: 'Recursive Descent is a Top-Down parsing method that builds the parse tree from the start symbol down to the leaves using a set of mutually recursive functions, each corresponding to a non-terminal grammar rule. It uses lookahead tokens (LL(1)) to decide transitions without backtracking.',
  },
  {
    id: 4,
    category: 'Syntax Analysis',
    question: 'How did you eliminate Left Recursion in your arithmetic expressions?',
    answer: 'Immediate left recursion (E -> E + T | T) causes infinite recursion in top-down parsers. We transform it into an iterative loop or right recursion: E -> T E\' where E\' -> (+ | -) T E\' | ε. In our Python implementation, expression() parses a term() then loops while seeing + or - tokens, creating left-associative BinaryOpNode trees without recursive stack overflow.',
  },
  {
    id: 5,
    category: 'Data Structures',
    question: 'What is an Abstract Syntax Tree (AST) vs a Concrete Parse Tree?',
    answer: 'A Concrete Parse Tree mirrors the full grammar derivations including punctuation, semicolons, and parentheses. An Abstract Syntax Tree (AST) is a condensed, semantic representation where interior nodes represent operators and leaf nodes represent operands, discarding syntactic sugar that does not affect execution semantics.',
  },
  {
    id: 6,
    category: 'Semantic Analysis',
    question: 'How is the Symbol Table implemented and what checks does it perform?',
    answer: 'Our Symbol Table is implemented as a hierarchy of Scope objects (lexical scopes) with parent pointers. It tracks identifier name, data type (int/float), declared line number, scope level, and initialization status. It enforces: 1) variable declaration before use, 2) prevention of duplicate declarations in the same scope, 3) static type compatibility, and 4) compile-time division by zero detection.',
  },
  {
    id: 7,
    category: 'Intermediate Code',
    question: 'What is Three-Address Code (TAC) and why is it called Three-Address?',
    answer: 'Three-Address Code is a linearized intermediate representation where each instruction has at most one operator on the right-hand side and references at most three addresses (two operands and one result): x = y op z. Complex expressions are decomposed into sequences of quadruples with compiler-generated temporary variables (t0, t1, t2).',
  },
  {
    id: 8,
    category: 'Intermediate Code',
    question: 'What is the difference between Quadruples and Triples in TAC?',
    answer: 'A Quadruple has 4 explicit fields: (op, arg1, arg2, result), where the destination variable is explicitly named. A Triple has 3 fields: (op, arg1, arg2), and the result is implicitly referenced by the instruction index (0), (1). Quadruples are easier to optimize because instructions can be reordered without invalidating numerical index references.',
  },
  {
    id: 9,
    category: 'Code Optimization',
    question: 'Explain the difference between Constant Folding and Constant Propagation.',
    answer: 'Constant Folding evaluates operations whose operands are all static constants at compile time (e.g. t0 = 3 * 4 becomes t0 = 12). Constant Propagation tracks variables assigned to constants and replaces subsequent usages of those variables with their literal constant values across the basic block (e.g. a = 10; b = a + 5 becomes b = 10 + 5, which then folds into b = 15).',
  },
  {
    id: 10,
    category: 'Code Optimization',
    question: 'What is Common Subexpression Elimination (CSE) and Dead Code Elimination (DCE)?',
    answer: 'CSE detects duplicate expressions computed within a basic block (e.g. t0 = a + b and later t2 = a + b when neither a nor b has changed) and reuses the previously computed result (t2 = t0). Dead Code Elimination identifies instructions that compute values never subsequently read (such as unused temporaries) or instructions unreachable after unconditional jumps, removing them to save cycles and memory.',
  },
  {
    id: 11,
    category: 'Target Code Generation',
    question: 'How does your compiler allocate registers in Phase 6?',
    answer: 'Our compiler uses a linear-scan round-robin Register Allocator targeting an 8-register virtual machine (R0 to R7). When translating a quadruple, constants are loaded with LOADI, variables with LOAD [var], and temporaries are kept in registers as long as possible to minimize memory traffic, before storing results back into named memory with STORE [var].',
  },
  {
    id: 12,
    category: 'Virtual Machine',
    question: 'How does the Target Code Virtual Machine execute assembly code?',
    answer: 'The Virtual Machine maintains an instruction pointer (Program Counter pc), a register file (R0-R7), a comparison flag (cmp_flag for <, ==, >), and a memory map for global variables. It loops through instructions, executing ALU operations, handling conditional and unconditional jumps to resolved labels, and simulating PRINT syscalls to standard output.',
  },
];
