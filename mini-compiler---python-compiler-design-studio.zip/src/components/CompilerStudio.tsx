import React, { useState, useEffect } from 'react';
import {
  Play,
  RotateCcw,
  Sparkles,
  Terminal,
  CheckCircle2,
  AlertTriangle,
  XCircle,
  FileCode,
  Copy,
  Check,
  Cpu,
  Layers,
  ArrowRight,
  TrendingDown,
  Info
} from 'lucide-react';
import { PRESET_PROGRAMS } from '../constants/presets';
import { CompileApiResponse, PresetProgram } from '../types';

interface CompilerStudioProps {
  compileResult: CompileApiResponse | null;
  loading: boolean;
  onCompile: (code: string, runVm: boolean) => Promise<void>;
  sourceCode: string;
  setSourceCode: (code: string) => void;
}

export const CompilerStudio: React.FC<CompilerStudioProps> = ({
  compileResult,
  loading,
  onCompile,
  sourceCode,
  setSourceCode,
}) => {
  const [selectedPresetId, setSelectedPresetId] = useState<number>(1);
  const [activePhaseTab, setActivePhaseTab] = useState<number>(1);
  const [copiedCode, setCopiedCode] = useState(false);
  const [tokenFilter, setTokenFilter] = useState<string>('ALL');
  const [showJsonAst, setShowJsonAst] = useState<boolean>(false);

  // Auto-compile when first loaded if no result yet
  useEffect(() => {
    if (!compileResult && sourceCode) {
      onCompile(sourceCode, true);
    }
  }, []);

  const handleSelectPreset = (preset: PresetProgram) => {
    setSelectedPresetId(preset.id);
    setSourceCode(preset.code);
    onCompile(preset.code, true);
  };

  const handleCopyCode = () => {
    navigator.clipboard.writeText(sourceCode);
    setCopiedCode(true);
    setTimeout(() => setCopiedCode(false), 2000);
  };

  const lineCount = sourceCode.split('\n').length;
  const lineNumbers = Array.from({ length: lineCount }, (_, i) => i + 1);

  const phaseNames = [
    { id: 1, name: '1. Lexical', badge: compileResult?.phases?.lexical?.tokens?.length ? `${compileResult.phases.lexical.tokens.length} tok` : null },
    { id: 2, name: '2. Syntax (AST)', badge: compileResult?.phases?.syntax?.ast_dict ? 'AST Valid' : null },
    { id: 3, name: '3. Semantic', badge: compileResult?.phases?.semantic?.symbol_table?.length ? `${compileResult.phases.semantic.symbol_table.length} sym` : null },
    { id: 4, name: '4. TAC', badge: compileResult?.phases?.intermediate?.quadruples?.length ? `${compileResult.phases.intermediate.quadruples.length} quad` : null },
    { id: 5, name: '5. Optimizer', badge: compileResult?.phases?.optimizer?.reduction_percent !== undefined ? `-${compileResult.phases.optimizer.reduction_percent}%` : null },
    { id: 6, name: '6. Target Code', badge: compileResult?.phases?.target_code?.instructions?.length ? `${compileResult.phases.target_code.instructions.length} inst` : null },
  ];

  const filteredTokens = compileResult?.phases?.lexical?.tokens?.filter(t => {
    if (tokenFilter === 'ALL') return true;
    if (tokenFilter === 'KEYWORD') return t.type.startsWith('KEYWORD');
    if (tokenFilter === 'IDENTIFIER') return t.type === 'IDENTIFIER';
    if (tokenFilter === 'LITERAL') return t.type.includes('CONST');
    if (tokenFilter === 'OPERATOR') return t.type.startsWith('OP_');
    if (tokenFilter === 'DELIMITER') return ['SEMICOLON', 'COMMA', 'LPAREN', 'RPAREN', 'LBRACE', 'RBRACE'].includes(t.type);
    return true;
  }) || [];

  return (
    <div className="space-y-4">
      {/* Preset Selector Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 flex flex-col md:flex-row md:items-center justify-between gap-3 shadow-md">
        <div className="flex items-center gap-3">
          <div className="p-2 rounded-xl bg-blue-500/10 text-blue-400 border border-blue-500/20">
            <Sparkles className="w-5 h-5" />
          </div>
          <div>
            <span className="text-xs font-semibold uppercase tracking-wider text-slate-400">
              Quick Test Presets (10+ Required Cases)
            </span>
            <div className="flex items-center gap-2 mt-0.5">
              <select
                aria-label="Preset Program Selector"
                value={selectedPresetId}
                onChange={e => {
                  const p = PRESET_PROGRAMS.find(x => x.id === Number(e.target.value));
                  if (p) handleSelectPreset(p);
                }}
                className="bg-slate-950 border border-slate-700 text-slate-100 text-xs sm:text-sm font-medium rounded-lg px-3 py-1.5 focus:outline-none focus:border-blue-500 cursor-pointer"
              >
                {PRESET_PROGRAMS.map(preset => (
                  <option key={preset.id} value={preset.id}>
                    {preset.id}. {preset.name} [{preset.category}]
                  </option>
                ))}
              </select>
            </div>
          </div>
        </div>

        <div className="text-xs text-slate-400 max-w-md hidden lg:block italic">
          {PRESET_PROGRAMS.find(p => p.id === selectedPresetId)?.description}
        </div>

        {/* Toolbar Action Buttons */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => onCompile(sourceCode, false)}
            disabled={loading}
            className="flex items-center gap-1.5 bg-blue-600 hover:bg-blue-500 text-white px-4 py-2 rounded-xl text-xs font-bold shadow-md shadow-blue-600/30 active:scale-95 transition-all cursor-pointer disabled:opacity-50"
          >
            <Layers className="w-3.5 h-3.5" />
            <span>Compile Pipeline</span>
          </button>

          <button
            onClick={() => onCompile(sourceCode, true)}
            disabled={loading}
            className="flex items-center gap-1.5 bg-emerald-600 hover:bg-emerald-500 text-white px-4 py-2 rounded-xl text-xs font-bold shadow-md shadow-emerald-600/30 active:scale-95 transition-all cursor-pointer disabled:opacity-50"
          >
            <Play className="w-3.5 h-3.5" />
            <span>Run (VM)</span>
          </button>

          <button
            onClick={() => {
              setSourceCode('');
            }}
            className="flex items-center gap-1 bg-slate-800 hover:bg-slate-700 text-slate-300 px-3 py-2 rounded-xl text-xs font-medium transition-all cursor-pointer"
            title="Clear Editor"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Clear</span>
          </button>
        </div>
      </div>

      {/* Main Split: Left Editor vs Right Phase Explorer */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 items-start">
        {/* --- LEFT COLUMN: Source Code Editor --- */}
        <div className="lg:col-span-5 bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-lg flex flex-col h-[580px]">
          {/* Editor Header */}
          <div className="bg-slate-950 px-4 py-2.5 border-b border-slate-800 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <FileCode className="w-4 h-4 text-blue-400" />
              <span className="text-xs font-bold uppercase tracking-wider text-slate-200">
                Source Code Editor
              </span>
              <span className="text-[10px] text-slate-400 font-mono">
                ({lineCount} lines)
              </span>
            </div>
            <button
              onClick={handleCopyCode}
              className="text-slate-400 hover:text-white p-1 rounded transition-colors text-xs flex items-center gap-1"
              title="Copy code"
            >
              {copiedCode ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              <span className="text-[11px]">{copiedCode ? 'Copied' : 'Copy'}</span>
            </button>
          </div>

          {/* Code Editor Body with Line Numbers */}
          <div className="flex-1 flex overflow-hidden bg-slate-950/80 font-mono text-xs sm:text-sm">
            {/* Gutter */}
            <div className="w-10 bg-slate-950 text-slate-600 select-none py-3 pr-2 text-right border-r border-slate-800/80 font-mono text-xs">
              {lineNumbers.map(n => (
                <div key={n} className="leading-6">
                  {n}
                </div>
              ))}
            </div>

            {/* Editable Text Area */}
            <textarea
              value={sourceCode}
              onChange={e => setSourceCode(e.target.value)}
              placeholder="// Write your Mini Compiler source code here..."
              className="flex-1 p-3 bg-transparent text-slate-100 placeholder-slate-600 focus:outline-none resize-none leading-6 font-mono selection:bg-blue-600/30 overflow-auto whitespace-pre"
              spellCheck={false}
            />
          </div>

          {/* Grammar quick-hints footer */}
          <div className="bg-slate-950/90 px-4 py-2 border-t border-slate-800 text-[11px] text-slate-400 flex items-center justify-between">
            <span className="truncate">Syntax: <code className="text-blue-400">int</code>, <code className="text-blue-400">float</code>, <code className="text-purple-400">if-else</code>, <code className="text-purple-400">while</code>, <code className="text-emerald-400">print()</code></span>
            <span className="text-slate-500 shrink-0 ml-2">Delim: <code className="text-amber-400">;</code></span>
          </div>
        </div>

        {/* --- RIGHT COLUMN: 6 Compiler Phase Tabs --- */}
        <div className="lg:col-span-7 bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-lg flex flex-col h-[580px]">
          {/* Phase Tabs Bar */}
          <div className="bg-slate-950 px-2 pt-2 border-b border-slate-800 flex overflow-x-auto gap-1 scrollbar-none">
            {phaseNames.map(phase => (
              <button
                key={phase.id}
                onClick={() => setActivePhaseTab(phase.id)}
                className={`flex items-center gap-1.5 px-3 py-2 rounded-t-xl text-xs font-semibold whitespace-nowrap transition-all border-b-2 ${
                  activePhaseTab === phase.id
                    ? 'bg-slate-900 text-blue-400 border-blue-500 shadow-sm'
                    : 'text-slate-400 hover:text-slate-200 border-transparent hover:bg-slate-900/40'
                }`}
              >
                <span>{phase.name}</span>
                {phase.badge && (
                  <span className="text-[10px] px-1.5 py-0.2 rounded-full bg-slate-800 text-slate-300 font-mono">
                    {phase.badge}
                  </span>
                )}
              </button>
            ))}
          </div>

          {/* Active Phase Tab Content */}
          <div className="flex-1 overflow-auto p-4 bg-slate-900/60">
            {/* ============================================================= */}
            {/* Phase 1: Lexical Analysis */}
            {/* ============================================================= */}
            {activePhaseTab === 1 && (
              <div className="space-y-3">
                <div className="flex flex-wrap items-center justify-between gap-2 pb-2 border-b border-slate-800">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-bold uppercase text-slate-300">
                      Tokens Stream ({filteredTokens.length} tokens)
                    </span>
                  </div>
                  {/* Token Type Filter Pills */}
                  <div className="flex items-center gap-1 text-[11px]">
                    {['ALL', 'KEYWORD', 'IDENTIFIER', 'LITERAL', 'OPERATOR', 'DELIMITER'].map(cat => (
                      <button
                        key={cat}
                        onClick={() => setTokenFilter(cat)}
                        className={`px-2 py-0.5 rounded text-[10px] font-semibold transition-all ${
                          tokenFilter === cat
                            ? 'bg-blue-600 text-white'
                            : 'bg-slate-800 text-slate-400 hover:text-slate-200'
                        }`}
                      >
                        {cat}
                      </button>
                    ))}
                  </div>
                </div>

                {filteredTokens.length === 0 ? (
                  <div className="text-center py-16 text-slate-500 text-xs">
                    No tokens found. Click "Compile Pipeline" to analyze source code.
                  </div>
                ) : (
                  <div className="overflow-x-auto border border-slate-800 rounded-xl">
                    <table className="w-full text-left text-xs font-mono">
                      <thead className="bg-slate-950 text-slate-400 text-[11px] uppercase tracking-wider border-b border-slate-800">
                        <tr>
                          <th className="py-2 px-3 w-12 text-center">#</th>
                          <th className="py-2 px-3">Token Type</th>
                          <th className="py-2 px-3">Lexeme / Value</th>
                          <th className="py-2 px-3 w-16 text-center">Line</th>
                          <th className="py-2 px-3 w-16 text-center">Col</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-800/60">
                        {filteredTokens.map((tok, idx) => (
                          <tr key={idx} className="hover:bg-slate-800/40 transition-colors">
                            <td className="py-1.5 px-3 text-center text-slate-500">{idx}</td>
                            <td className="py-1.5 px-3">
                              <span
                                className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                                  tok.type.startsWith('KEYWORD')
                                    ? 'bg-blue-500/20 text-blue-400 border border-blue-500/30'
                                    : tok.type === 'IDENTIFIER'
                                    ? 'bg-purple-500/20 text-purple-400 border border-purple-500/30'
                                    : tok.type.includes('CONST')
                                    ? 'bg-amber-500/20 text-amber-400 border border-amber-500/30'
                                    : tok.type.startsWith('OP_')
                                    ? 'bg-rose-500/20 text-rose-400 border border-rose-500/30'
                                    : 'bg-slate-700/40 text-slate-400'
                                }`}
                              >
                                {tok.type}
                              </span>
                            </td>
                            <td className="py-1.5 px-3 font-semibold text-slate-200">
                              <code>{tok.value}</code>
                            </td>
                            <td className="py-1.5 px-3 text-center text-slate-400">{tok.line}</td>
                            <td className="py-1.5 px-3 text-center text-slate-400">{tok.column}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </div>
            )}

            {/* ============================================================= */}
            {/* Phase 2: Syntax Analysis */}
            {/* ============================================================= */}
            {activePhaseTab === 2 && (
              <div className="space-y-3">
                <div className="flex items-center justify-between pb-2 border-b border-slate-800">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-bold uppercase text-slate-300">
                      Abstract Syntax Tree (Recursive Descent LL(1))
                    </span>
                  </div>
                  <button
                    onClick={() => setShowJsonAst(!showJsonAst)}
                    className="text-[11px] text-blue-400 hover:text-blue-300 bg-blue-500/10 px-2.5 py-1 rounded-lg border border-blue-500/20 cursor-pointer"
                  >
                    {showJsonAst ? 'Show Tree View' : 'Show JSON View'}
                  </button>
                </div>

                {compileResult?.phases?.syntax?.ast_tree ? (
                  showJsonAst ? (
                    <pre className="bg-slate-950 p-4 rounded-xl border border-slate-800 text-xs font-mono text-emerald-400 overflow-auto max-h-[440px]">
                      {JSON.stringify(compileResult.phases.syntax.ast_dict, null, 2)}
                    </pre>
                  ) : (
                    <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 overflow-auto max-h-[440px]">
                      <pre className="text-xs font-mono text-blue-300 leading-relaxed">
                        {compileResult.phases.syntax.ast_tree}
                      </pre>
                    </div>
                  )
                ) : (
                  <div className="text-center py-16 text-slate-500 text-xs">
                    {compileResult?.error_phase === 'Syntax Analysis'
                      ? 'Syntax errors prevented AST construction. Check the console below.'
                      : 'Compile to view the Abstract Syntax Tree.'}
                  </div>
                )}
              </div>
            )}

            {/* ============================================================= */}
            {/* Phase 3: Semantic Analysis */}
            {/* ============================================================= */}
            {activePhaseTab === 3 && (
              <div className="space-y-4">
                <div>
                  <h4 className="text-xs font-bold uppercase text-slate-300 mb-2 flex items-center gap-2">
                    <span>Scoped Symbol Table</span>
                    <span className="text-[10px] text-slate-500 font-normal">
                      (Tracks declaration line, scope level, data types)
                    </span>
                  </h4>
                  {compileResult?.phases?.semantic?.symbol_table?.length ? (
                    <div className="overflow-x-auto border border-slate-800 rounded-xl">
                      <table className="w-full text-left text-xs font-mono">
                        <thead className="bg-slate-950 text-slate-400 text-[11px] uppercase tracking-wider border-b border-slate-800">
                          <tr>
                            <th className="py-2 px-3">Identifier</th>
                            <th className="py-2 px-3 text-center">Type</th>
                            <th className="py-2 px-3 text-center">Line Declared</th>
                            <th className="py-2 px-3 text-center">Scope Level</th>
                            <th className="py-2 px-3 text-center">Initialized</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-800/60">
                          {compileResult.phases.semantic.symbol_table.map((sym, idx) => (
                            <tr key={idx} className="hover:bg-slate-800/40">
                              <td className="py-2 px-3 font-bold text-slate-100">{sym.name}</td>
                              <td className="py-2 px-3 text-center">
                                <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-blue-500/20 text-blue-400 border border-blue-500/30">
                                  {sym.type}
                                </span>
                              </td>
                              <td className="py-2 px-3 text-center text-slate-400">{sym.line}</td>
                              <td className="py-2 px-3 text-center text-slate-400">
                                {sym.scope === 0 ? '0 (Global)' : `${sym.scope} (Block)`}
                              </td>
                              <td className="py-2 px-3 text-center">
                                <span
                                  className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                                    sym.initialized
                                      ? 'bg-emerald-500/20 text-emerald-400'
                                      : 'bg-amber-500/20 text-amber-400'
                                  }`}
                                >
                                  {sym.initialized ? 'Yes' : 'No'}
                                </span>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  ) : (
                    <div className="text-center py-8 text-slate-500 text-xs">
                      No symbols declared.
                    </div>
                  )}
                </div>

                {/* Semantic Diagnostics Check */}
                <div className="bg-slate-950 p-3.5 rounded-xl border border-slate-800">
                  <span className="text-xs font-bold uppercase text-slate-300 block mb-2">
                    Semantic Validation Checks
                  </span>
                  <div className="space-y-1.5 text-xs">
                    <div className="flex items-center gap-2 text-slate-300">
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                      <span>Undeclared variable detection: Active</span>
                    </div>
                    <div className="flex items-center gap-2 text-slate-300">
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                      <span>Duplicate scope declaration prevention: Active</span>
                    </div>
                    <div className="flex items-center gap-2 text-slate-300">
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                      <span>Type safety & implicit widening checks: Active</span>
                    </div>
                    <div className="flex items-center gap-2 text-slate-300">
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                      <span>Compile-time division by zero detection: Active</span>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* ============================================================= */}
            {/* Phase 4: Intermediate Code Generation */}
            {/* ============================================================= */}
            {activePhaseTab === 4 && (
              <div className="space-y-3">
                <div className="flex items-center justify-between pb-2 border-b border-slate-800">
                  <span className="text-xs font-bold uppercase text-slate-300">
                    Linear Three-Address Code (TAC) & Quadruples
                  </span>
                  <span className="text-[11px] text-slate-400 font-mono">
                    {compileResult?.phases?.intermediate?.quad_count || 0} quadruples
                  </span>
                </div>

                {compileResult?.phases?.intermediate?.quadruples?.length ? (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    {/* Formatted TAC */}
                    <div className="bg-slate-950 p-3 rounded-xl border border-slate-800">
                      <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block mb-2">
                        TAC Instructions
                      </span>
                      <pre className="text-xs font-mono text-emerald-400 whitespace-pre overflow-auto max-h-[380px] leading-relaxed">
                        {compileResult.phases.intermediate.tac_text}
                      </pre>
                    </div>

                    {/* Quadruples Table */}
                    <div className="overflow-x-auto border border-slate-800 rounded-xl bg-slate-950/40 max-h-[420px]">
                      <table className="w-full text-left text-xs font-mono">
                        <thead className="bg-slate-950 text-slate-400 text-[10px] uppercase border-b border-slate-800 sticky top-0">
                          <tr>
                            <th className="py-2 px-2.5 text-center">#</th>
                            <th className="py-2 px-2.5">Op</th>
                            <th className="py-2 px-2.5">Arg1</th>
                            <th className="py-2 px-2.5">Arg2</th>
                            <th className="py-2 px-2.5">Result</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-800/60">
                          {compileResult.phases.intermediate.quadruples.map((q, idx) => (
                            <tr key={idx} className="hover:bg-slate-800/40">
                              <td className="py-1 px-2.5 text-center text-slate-500">{idx}</td>
                              <td className="py-1 px-2.5 font-bold text-amber-400">{q.op}</td>
                              <td className="py-1 px-2.5 text-slate-300">{q.arg1 || '-'}</td>
                              <td className="py-1 px-2.5 text-slate-300">{q.arg2 || '-'}</td>
                              <td className="py-1 px-2.5 font-semibold text-blue-400">{q.result || '-'}</td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                ) : (
                  <div className="text-center py-16 text-slate-500 text-xs">
                    Compile code to generate intermediate Three-Address Code.
                  </div>
                )}
              </div>
            )}

            {/* ============================================================= */}
            {/* Phase 5: Code Optimization */}
            {/* ============================================================= */}
            {activePhaseTab === 5 && (
              <div className="space-y-4">
                {/* Metrics header */}
                <div className="bg-gradient-to-r from-blue-950/40 to-emerald-950/40 border border-slate-800 p-3.5 rounded-xl flex items-center justify-between">
                  <div>
                    <span className="text-xs font-bold uppercase text-slate-300 block">
                      Multi-Pass Optimization Summary
                    </span>
                    <span className="text-xs text-slate-400">
                      Constant Folding • Constant Propagation • Common Subexpression Elimination (CSE) • Dead Code Elimination (DCE)
                    </span>
                  </div>
                  {compileResult?.phases?.optimizer && (
                    <div className="flex items-center gap-3 font-mono">
                      <div className="text-right">
                        <span className="text-xs text-slate-400">Instructions</span>
                        <div className="text-sm font-bold text-slate-200">
                          {compileResult.phases.optimizer.original_count} → {compileResult.phases.optimizer.optimized_count}
                        </div>
                      </div>
                      <div className="px-2.5 py-1 rounded-lg bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 text-xs font-bold flex items-center gap-1">
                        <TrendingDown className="w-3.5 h-3.5" />
                        <span>{compileResult.phases.optimizer.reduction_percent}% reduction</span>
                      </div>
                    </div>
                  )}
                </div>

                {/* Side-by-Side TAC Comparison */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  <div className="bg-slate-950 p-3 rounded-xl border border-slate-800">
                    <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block mb-2">
                      Original TAC (Phase 4)
                    </span>
                    <pre className="text-xs font-mono text-slate-400 whitespace-pre overflow-auto max-h-[180px] leading-relaxed">
                      {compileResult?.phases?.intermediate?.tac_text || '// No intermediate code'}
                    </pre>
                  </div>

                  <div className="bg-slate-950 p-3 rounded-xl border border-emerald-800/40">
                    <span className="text-[11px] font-bold text-emerald-400 uppercase tracking-wider block mb-2">
                      Optimized TAC (Phase 5)
                    </span>
                    <pre className="text-xs font-mono text-emerald-400 whitespace-pre overflow-auto max-h-[180px] leading-relaxed">
                      {compileResult?.phases?.optimizer?.tac_text || '// No optimized code'}
                    </pre>
                  </div>
                </div>

                {/* Optimization Audit Records */}
                <div>
                  <h4 className="text-xs font-bold uppercase text-slate-300 mb-2">
                    Optimization Transformations Log ({compileResult?.phases?.optimizer?.records?.length || 0} applied)
                  </h4>
                  {compileResult?.phases?.optimizer?.records?.length ? (
                    <div className="space-y-1.5 max-h-[180px] overflow-auto pr-1">
                      {compileResult.phases.optimizer.records.map((rec, idx) => (
                        <div key={idx} className="bg-slate-950 p-2.5 rounded-lg border border-slate-800/80 text-xs font-mono flex items-center justify-between gap-3">
                          <div className="flex items-center gap-2 truncate">
                            <span
                              className={`px-2 py-0.5 rounded text-[10px] font-bold shrink-0 ${
                                rec.type === 'Constant Folding'
                                  ? 'bg-amber-500/20 text-amber-400 border border-amber-500/30'
                                  : rec.type === 'Constant Propagation'
                                  ? 'bg-blue-500/20 text-blue-400 border border-blue-500/30'
                                  : rec.type.includes('Subexpression')
                                  ? 'bg-purple-500/20 text-purple-400 border border-purple-500/30'
                                  : 'bg-rose-500/20 text-rose-400 border border-rose-500/30'
                              }`}
                            >
                              {rec.type}
                            </span>
                            <span className="text-slate-300 truncate">{rec.details}</span>
                          </div>
                          <div className="text-slate-400 shrink-0 text-[11px] flex items-center gap-1">
                            <code className="text-slate-500">{rec.before}</code>
                            <ArrowRight className="w-3 h-3 text-slate-600" />
                            <code className="text-emerald-400">{rec.after}</code>
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="text-xs text-slate-500 italic bg-slate-950 p-3 rounded-lg border border-slate-800">
                      No further optimizations applicable (already in minimal normal form).
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* ============================================================= */}
            {/* Phase 6: Target Code Generation */}
            {/* ============================================================= */}
            {activePhaseTab === 6 && (
              <div className="space-y-3">
                <div className="flex items-center justify-between pb-2 border-b border-slate-800">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-bold uppercase text-slate-300">
                      Target Assembly Code (32-bit Register Architecture)
                    </span>
                  </div>
                  <span className="text-[11px] text-slate-400 font-mono">
                    Registers R0–R7 • .data & .text segments
                  </span>
                </div>

                {compileResult?.phases?.target_code?.assembly_text ? (
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                    {/* Assembly text (2 cols) */}
                    <div className="md:col-span-2 bg-slate-950 p-3 rounded-xl border border-slate-800">
                      <pre className="text-xs font-mono text-cyan-300 whitespace-pre overflow-auto max-h-[420px] leading-relaxed">
                        {compileResult.phases.target_code.assembly_text}
                      </pre>
                    </div>

                    {/* Machine Architecture Notes & VM State */}
                    <div className="space-y-3">
                      <div className="bg-slate-950 p-3 rounded-xl border border-slate-800">
                        <span className="text-xs font-bold uppercase text-slate-300 block mb-2 flex items-center gap-1.5">
                          <Cpu className="w-3.5 h-3.5 text-blue-400" />
                          Virtual Machine State
                        </span>
                        <div className="space-y-2 text-xs font-mono">
                          <div>
                            <span className="text-slate-500 text-[10px] block">SIMULATED CYCLES</span>
                            <span className="text-slate-200 font-bold">
                              {compileResult.execution_cycles} instructions
                            </span>
                          </div>
                          <div>
                            <span className="text-slate-500 text-[10px] block">DATA MEMORY VALUES</span>
                            <div className="bg-slate-900 p-2 rounded border border-slate-800 mt-1 max-h-[140px] overflow-auto">
                              {Object.entries(compileResult.execution_memory || {}).map(([k, v]) => (
                                <div key={k} className="flex justify-between py-0.5">
                                  <span className="text-slate-400">{k}:</span>
                                  <span className="text-emerald-400 font-bold">{String(v)}</span>
                                </div>
                              ))}
                            </div>
                          </div>
                        </div>
                      </div>

                      <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 text-[11px] text-slate-400 space-y-1">
                        <span className="font-bold text-slate-300 uppercase tracking-wider block text-[10px]">
                          ISA Instruction Reference
                        </span>
                        <div><code className="text-cyan-400">LOAD Rd, [var]</code>: Memory to register</div>
                        <div><code className="text-cyan-400">LOADI Rd, imm</code>: Immediate to register</div>
                        <div><code className="text-cyan-400">STORE [var], Rs</code>: Register to memory</div>
                        <div><code className="text-cyan-400">ADD/SUB/MUL/DIV</code>: ALU arithmetic</div>
                        <div><code className="text-cyan-400">CMP / JMP / JEQ</code>: Branching</div>
                        <div><code className="text-cyan-400">PRINT Rs</code>: I/O system call</div>
                      </div>
                    </div>
                  </div>
                ) : (
                  <div className="text-center py-16 text-slate-500 text-xs">
                    Compile code to generate target assembly code.
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* --- BOTTOM ROW: Diagnostics & Output Console --- */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-lg">
        {/* Console Header */}
        <div className="bg-slate-950 px-4 py-2 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Terminal className="w-4 h-4 text-emerald-400" />
            <span className="text-xs font-bold uppercase tracking-wider text-slate-200">
              Compilation & Virtual Machine Console
            </span>
          </div>

          {/* Status Badge */}
          {compileResult && (
            <div className="flex items-center gap-2">
              {compileResult.success ? (
                <span className="flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[11px] font-semibold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>Compilation & Execution Succeeded</span>
                </span>
              ) : (
                <span className="flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[11px] font-semibold bg-rose-500/10 text-rose-400 border border-rose-500/20">
                  <XCircle className="w-3.5 h-3.5" />
                  <span>Failed in {compileResult.error_phase || 'Pipeline'}</span>
                </span>
              )}
            </div>
          )}
        </div>

        {/* Console Output Body */}
        <div className="p-4 bg-slate-950 font-mono text-xs space-y-2 max-h-48 overflow-auto">
          {/* Errors list */}
          {compileResult?.errors && compileResult.errors.length > 0 && (
            <div className="space-y-1">
              {compileResult.errors.map((err, i) => (
                <div key={i} className="flex items-start gap-2 text-rose-400 bg-rose-950/30 p-2 rounded-lg border border-rose-900/40">
                  <XCircle className="w-4 h-4 shrink-0 mt-0.5" />
                  <div>
                    <span className="font-bold underline">
                      Line {err.line}, Col {err.column}:
                    </span>{' '}
                    <span>{err.message}</span>
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* Warnings list */}
          {compileResult?.warnings && compileResult.warnings.length > 0 && (
            <div className="space-y-1">
              {compileResult.warnings.map((w, i) => (
                <div key={i} className="flex items-start gap-2 text-amber-400 bg-amber-950/30 p-2 rounded-lg border border-amber-900/40">
                  <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5" />
                  <div>
                    <span className="font-bold">Line {w.line}:</span> {w.message}
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* VM Execution Output */}
          {compileResult?.success && (
            <div className="text-slate-300 space-y-1">
              <div className="text-slate-500 text-[11px]">--- Program Standard Output (VM) ---</div>
              {compileResult.execution_output?.length ? (
                compileResult.execution_output.map((line, idx) => (
                  <div key={idx} className="flex items-center gap-2 text-emerald-400 font-bold text-sm">
                    <span className="text-slate-600 select-none">&gt;&gt;</span>
                    <span>{line}</span>
                  </div>
                ))
              ) : (
                <div className="text-slate-500 italic">(Program produced no print output)</div>
              )}
              <div className="text-[11px] text-slate-500 pt-1">
                Completed in {compileResult.execution_cycles} cycles • Exit Code 0.
              </div>
            </div>
          )}

          {!compileResult && (
            <div className="text-slate-500 italic">
              Ready. Click "Compile Pipeline" or "Run (VM)" to compile and execute.
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
