import React, { useState } from 'react';
import { Laptop, Terminal, Copy, Check, CheckCircle2, AlertCircle, FileCode } from 'lucide-react';

export const VSCodeGuide: React.FC = () => {
  const [copiedCmd, setCopiedCmd] = useState<string | null>(null);

  const copyCommand = (cmd: string) => {
    navigator.clipboard.writeText(cmd);
    setCopiedCmd(cmd);
    setTimeout(() => setCopiedCmd(null), 2000);
  };

  return (
    <div className="space-y-4 max-w-5xl mx-auto">
      {/* Header */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-md">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-xl bg-blue-500/10 text-blue-400 border border-blue-500/20">
            <Laptop className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-base font-bold text-white">
              VS Code Setup & Local Execution Guide
            </h2>
            <p className="text-xs text-slate-400 mt-0.5">
              How to execute the 100% Python Mini Compiler and launch the Tkinter GUI on your local desktop.
            </p>
          </div>
        </div>
      </div>

      {/* Step by step guide */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Step 1: Open in VS Code */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 shadow-sm space-y-3">
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 rounded-full bg-blue-600 text-white font-bold text-xs flex items-center justify-center">
              1
            </div>
            <h3 className="text-sm font-bold text-slate-200">
              Download & Open in VS Code
            </h3>
          </div>
          <p className="text-xs text-slate-400 leading-relaxed">
            Click the <strong className="text-emerald-400">"Download mini_compiler.zip"</strong> button in the top navigation bar. Extract the zip file, launch Visual Studio Code, and open the extracted folder:
          </p>
          <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 text-xs font-mono text-slate-300">
            <div>1. Open VS Code</div>
            <div>2. Go to <strong>File &gt; Open Folder...</strong></div>
            <div>3. Select the <strong>mini_compiler</strong> directory</div>
          </div>
        </div>

        {/* Step 2: Verify Python & Tkinter */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 shadow-sm space-y-3">
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 rounded-full bg-blue-600 text-white font-bold text-xs flex items-center justify-center">
              2
            </div>
            <h3 className="text-sm font-bold text-slate-200">
              Verify Python & Tkinter
            </h3>
          </div>
          <p className="text-xs text-slate-400 leading-relaxed">
            Open the integrated terminal in VS Code (press <kbd className="bg-slate-800 px-1.5 py-0.5 rounded text-[10px] font-mono">Ctrl + `</kbd>) and test Tkinter:
          </p>
          <div className="bg-slate-950 p-2.5 rounded-xl border border-slate-800 flex items-center justify-between font-mono text-xs">
            <code className="text-emerald-400">python -m tkinter</code>
            <button
              onClick={() => copyCommand('python -m tkinter')}
              className="text-slate-400 hover:text-white p-1"
            >
              {copiedCmd === 'python -m tkinter' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
            </button>
          </div>
          <p className="text-[11px] text-slate-500">
            * Windows and macOS include Tkinter by default with Python. On Ubuntu/Debian Linux, install via: <code className="text-blue-400">sudo apt install python3-tk</code>.
          </p>
        </div>

        {/* Step 3: Launch Tkinter Desktop GUI */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 shadow-sm space-y-3">
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 rounded-full bg-blue-600 text-white font-bold text-xs flex items-center justify-center">
              3
            </div>
            <h3 className="text-sm font-bold text-slate-200">
              Launch the Tkinter Desktop GUI
            </h3>
          </div>
          <p className="text-xs text-slate-400 leading-relaxed">
            Run the GUI entry point in your VS Code terminal. The dark-themed desktop compiler window with all 6 phase tabs will open:
          </p>
          <div className="bg-slate-950 p-2.5 rounded-xl border border-slate-800 flex items-center justify-between font-mono text-xs">
            <code className="text-blue-400">python gui.py</code>
            <button
              onClick={() => copyCommand('python gui.py')}
              className="text-slate-400 hover:text-white p-1"
            >
              {copiedCmd === 'python gui.py' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
            </button>
          </div>
        </div>

        {/* Step 4: Run Automated Test Cases */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 shadow-sm space-y-3">
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 rounded-full bg-blue-600 text-white font-bold text-xs flex items-center justify-center">
              4
            </div>
            <h3 className="text-sm font-bold text-slate-200">
              Run All 12 Automated Tests
            </h3>
          </div>
          <p className="text-xs text-slate-400 leading-relaxed">
            To demonstrate 100% test pass rate to your teacher/examiner, execute the test suite:
          </p>
          <div className="bg-slate-950 p-2.5 rounded-xl border border-slate-800 flex items-center justify-between font-mono text-xs">
            <code className="text-amber-400">python test_cases.py</code>
            <button
              onClick={() => copyCommand('python test_cases.py')}
              className="text-slate-400 hover:text-white p-1"
            >
              {copiedCmd === 'python test_cases.py' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
            </button>
          </div>
        </div>
      </div>

      {/* CLI Commands Reference Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 shadow-sm space-y-3">
        <h3 className="text-xs font-bold uppercase tracking-wider text-slate-300 flex items-center gap-2">
          <Terminal className="w-4 h-4 text-emerald-400" />
          <span>Complete CLI Command Reference</span>
        </h3>
        <div className="overflow-x-auto border border-slate-800 rounded-xl">
          <table className="w-full text-left text-xs font-mono">
            <thead className="bg-slate-950 text-slate-400 text-[11px] uppercase border-b border-slate-800">
              <tr>
                <th className="py-2.5 px-3">Command</th>
                <th className="py-2.5 px-3">Description</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 text-slate-300">
              <tr>
                <td className="py-2 px-3 text-blue-400">python gui.py</td>
                <td className="py-2 px-3">Launches full Tkinter desktop GUI with 6 tabs & line editor</td>
              </tr>
              <tr>
                <td className="py-2 px-3 text-blue-400">python main.py</td>
                <td className="py-2 px-3">Runs main pipeline on default sample program and prints summary</td>
              </tr>
              <tr>
                <td className="py-2 px-3 text-blue-400">python test_cases.py</td>
                <td className="py-2 px-3">Runs 12 automated test cases with PASS/FAIL verification</td>
              </tr>
              <tr>
                <td className="py-2 px-3 text-blue-400">python main.py file.mc</td>
                <td className="py-2 px-3">Compiles and runs a custom source code file through all 6 phases</td>
              </tr>
              <tr>
                <td className="py-2 px-3 text-blue-400">python main.py --code "..."</td>
                <td className="py-2 px-3">Compiles inline source code directly from terminal argument</td>
              </tr>
              <tr>
                <td className="py-2 px-3 text-blue-400">python main.py --code "..." --json</td>
                <td className="py-2 px-3">Emits structured JSON output with all phases for integration</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
