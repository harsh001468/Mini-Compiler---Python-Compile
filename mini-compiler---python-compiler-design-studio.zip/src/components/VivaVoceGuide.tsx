import React, { useState } from 'react';
import { BookOpen, Search, Eye, EyeOff, Sparkles, HelpCircle } from 'lucide-react';
import { VIVA_QUESTIONS } from '../constants/presets';

export const VivaVoceGuide: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState<string>('');
  const [selectedCategory, setSelectedCategory] = useState<string>('ALL');
  const [revealedIds, setRevealedIds] = useState<Record<number, boolean>>({});

  const categories = ['ALL', ...Array.from(new Set(VIVA_QUESTIONS.map(q => q.category)))];

  const filteredQuestions = VIVA_QUESTIONS.filter(q => {
    const matchesCat = selectedCategory === 'ALL' || q.category === selectedCategory;
    const matchesSearch =
      q.question.toLowerCase().includes(searchTerm.toLowerCase()) ||
      q.answer.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesCat && matchesSearch;
  });

  const toggleReveal = (id: number) => {
    setRevealedIds(prev => ({ ...prev, [id]: !prev[id] }));
  };

  const revealAll = () => {
    const all: Record<number, boolean> = {};
    VIVA_QUESTIONS.forEach(q => (all[q.id] = true));
    setRevealedIds(all);
  };

  const hideAll = () => {
    setRevealedIds({});
  };

  return (
    <div className="space-y-4">
      {/* Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 flex flex-col md:flex-row items-start md:items-center justify-between gap-3 shadow-md">
        <div>
          <h2 className="text-sm font-bold text-slate-100 flex items-center gap-2">
            <BookOpen className="w-4 h-4 text-purple-400" />
            <span>Compiler Design Viva Voce Trainer (B.Tech Practical Exam)</span>
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Key theoretical and architectural questions asked by external examiners, with concise technical answers.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={revealAll}
            className="text-xs bg-slate-800 hover:bg-slate-700 text-slate-200 px-3 py-1.5 rounded-lg font-medium transition-colors cursor-pointer"
          >
            Reveal All Answers
          </button>
          <button
            onClick={hideAll}
            className="text-xs bg-slate-800 hover:bg-slate-700 text-slate-200 px-3 py-1.5 rounded-lg font-medium transition-colors cursor-pointer"
          >
            Hide All (Quiz Mode)
          </button>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-3 bg-slate-950 p-3 rounded-xl border border-slate-800">
        <div className="flex items-center gap-2 w-full sm:w-auto">
          <Search className="w-4 h-4 text-slate-500" />
          <input
            type="text"
            placeholder="Search questions or keywords (e.g. LL(1), TAC, CSE)..."
            value={searchTerm}
            onChange={e => setSearchTerm(e.target.value)}
            className="bg-transparent text-xs text-slate-200 placeholder-slate-500 focus:outline-none w-full sm:w-80"
          />
        </div>

        <div className="flex items-center gap-1 overflow-x-auto w-full sm:w-auto scrollbar-none">
          {categories.map(cat => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-2.5 py-1 rounded-lg text-[11px] font-semibold whitespace-nowrap transition-all ${
                selectedCategory === cat
                  ? 'bg-purple-600 text-white'
                  : 'bg-slate-900 text-slate-400 hover:text-slate-200 hover:bg-slate-800'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* Questions Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
        {filteredQuestions.map(item => {
          const isRevealed = revealedIds[item.id];
          return (
            <div
              key={item.id}
              className="bg-slate-900 border border-slate-800 rounded-2xl p-4 shadow-sm hover:border-slate-700 transition-all flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center justify-between gap-2 mb-2">
                  <span className="text-[10px] font-mono font-bold text-slate-500">
                    Q{String(item.id).padStart(2, '0')}
                  </span>
                  <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-purple-500/10 text-purple-400 border border-purple-500/20">
                    {item.category}
                  </span>
                </div>

                <h3 className="text-xs sm:text-sm font-bold text-slate-100 mb-3 leading-snug">
                  {item.question}
                </h3>

                {isRevealed ? (
                  <div className="bg-slate-950 p-3 rounded-xl border border-purple-950 text-xs text-slate-300 leading-relaxed font-sans mt-2 animate-fadeIn">
                    <p>{item.answer}</p>
                  </div>
                ) : (
                  <div className="bg-slate-950/60 p-3 rounded-xl border border-dashed border-slate-800 text-center text-xs text-slate-500 italic">
                    Answer hidden for self-testing. Click "Reveal Answer" below.
                  </div>
                )}
              </div>

              <div className="pt-3 mt-3 border-t border-slate-800/80 flex items-center justify-end">
                <button
                  onClick={() => toggleReveal(item.id)}
                  className="flex items-center gap-1.5 text-xs text-purple-400 hover:text-purple-300 font-semibold cursor-pointer"
                >
                  {isRevealed ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                  <span>{isRevealed ? 'Hide Answer' : 'Reveal Answer'}</span>
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
