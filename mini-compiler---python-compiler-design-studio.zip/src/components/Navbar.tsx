import React, { useState } from 'react';
import { Download, Terminal, BookOpen, Code2, CheckCircle2, Laptop, Layers } from 'lucide-react';
import JSZip from 'jszip';

interface NavbarProps {
  activeTab: 'studio' | 'files' | 'tests' | 'viva' | 'vscode';
  setActiveTab: (tab: 'studio' | 'files' | 'tests' | 'viva' | 'vscode') => void;
  pythonFiles: Array<{ name: string; path: string; content: string }>;
}

export const Navbar: React.FC<NavbarProps> = ({ activeTab, setActiveTab, pythonFiles }) => {
  const [downloading, setDownloading] = useState(false);

  const handleDownloadZip = async () => {
    try {
      setDownloading(true);
      const zip = new JSZip();
      const folder = zip.folder('mini_compiler');

      if (pythonFiles.length > 0 && folder) {
        pythonFiles.forEach(file => {
          folder.file(file.name, file.content);
        });
      } else if (folder) {
        // Fallback fetch if pythonFiles array not loaded yet
        const res = await fetch('/api/python-files');
        const data = await res.json();
        data.files?.forEach((f: any) => {
          folder.file(f.name, f.content);
        });
      }

      const blob = await zip.generateAsync({ type: 'blob' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = 'mini_compiler_project.zip';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
    } catch (err) {
      console.error('Failed to download zip:', err);
    } finally {
      setDownloading(false);
    }
  };

  return (
    <header className="bg-slate-900 border-b border-slate-800 text-slate-100 sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 flex items-center justify-between h-16">
        {/* Brand & Course Title */}
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-blue-600 via-indigo-600 to-cyan-400 flex items-center justify-center shadow-lg shadow-blue-500/20 text-white font-mono font-bold text-lg">
            MC
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-extrabold tracking-tight text-white text-base sm:text-lg">
                MINI COMPILER
              </span>
              <span className="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded-full bg-blue-500/10 text-blue-400 border border-blue-500/20">
                Python 100%
              </span>
            </div>
            <p className="text-xs text-slate-400 hidden sm:block">
              B.Tech 2nd Year (AI & DS / CSE) • 6-Phase Compiler Design & Tkinter GUI
            </p>
          </div>
        </div>

        {/* Tab Navigation */}
        <nav className="flex items-center gap-1 bg-slate-950/60 p-1 rounded-xl border border-slate-800/80">
          <button
            onClick={() => setActiveTab('studio')}
            className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
              activeTab === 'studio'
                ? 'bg-blue-600 text-white shadow-md shadow-blue-600/30'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
            }`}
          >
            <Layers className="w-3.5 h-3.5" />
            <span>Interactive Studio</span>
          </button>

          <button
            onClick={() => setActiveTab('files')}
            className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
              activeTab === 'files'
                ? 'bg-blue-600 text-white shadow-md shadow-blue-600/30'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
            }`}
          >
            <Code2 className="w-3.5 h-3.5" />
            <span>Python Files</span>
          </button>

          <button
            onClick={() => setActiveTab('tests')}
            className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
              activeTab === 'tests'
                ? 'bg-blue-600 text-white shadow-md shadow-blue-600/30'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
            }`}
          >
            <CheckCircle2 className="w-3.5 h-3.5" />
            <span>12 Tests</span>
          </button>

          <button
            onClick={() => setActiveTab('viva')}
            className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
              activeTab === 'viva'
                ? 'bg-blue-600 text-white shadow-md shadow-blue-600/30'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
            }`}
          >
            <BookOpen className="w-3.5 h-3.5" />
            <span>Viva Voce</span>
          </button>

          <button
            onClick={() => setActiveTab('vscode')}
            className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
              activeTab === 'vscode'
                ? 'bg-blue-600 text-white shadow-md shadow-blue-600/30'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
            }`}
          >
            <Laptop className="w-3.5 h-3.5" />
            <span>VS Code Guide</span>
          </button>
        </nav>

        {/* Action: Download ZIP */}
        <div className="flex items-center gap-2">
          <button
            onClick={handleDownloadZip}
            disabled={downloading}
            className="flex items-center gap-2 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white px-3.5 py-1.5 rounded-lg text-xs font-semibold shadow-md shadow-emerald-700/20 active:scale-95 transition-all cursor-pointer disabled:opacity-50"
            title="Download complete mini_compiler project as a zip file for VS Code"
          >
            <Download className="w-3.5 h-3.5" />
            <span className="hidden md:inline">Download mini_compiler.zip</span>
            <span className="md:hidden">ZIP</span>
          </button>
        </div>
      </div>
    </header>
  );
};
