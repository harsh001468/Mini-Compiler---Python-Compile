import React, { useState } from 'react';
import { CheckCircle2, XCircle, Play, RefreshCw, Terminal, AlertCircle } from 'lucide-react';
import { PRESET_PROGRAMS } from '../constants/presets';

export const TestSuiteRunner: React.FC = () => {
  const [running, setRunning] = useState<boolean>(false);
  const [rawOutput, setRawOutput] = useState<string>('');
  const [testResults, setTestResults] = useState<Record<number, boolean>>({});
  const [hasRun, setHasRun] = useState<boolean>(false);

  const handleRunTests = async () => {
    try {
      setRunning(true);
      const res = await fetch('/api/run-tests', { method: 'POST' });
      const data = await res.json();
      setRawOutput(data.output || '');
      setHasRun(true);

      // Parse output for test results
      const results: Record<number, boolean> = {};
      PRESET_PROGRAMS.forEach(test => {
        // Look for [Test Case 01] ... Status: ✅ PASS
        const passPattern = new RegExp(`\\[Test Case ${String(test.id).padStart(2, '0')}\\].*?Status: ✅ PASS`, 's');
        results[test.id] = passPattern.test(data.output || '');
      });
      setTestResults(results);
    } catch (err) {
      console.error('Failed to run test suite:', err);
    } finally {
      setRunning(false);
    }
  };

  const passCount = Object.values(testResults).filter(Boolean).length;

  return (
    <div className="space-y-4">
      {/* Top Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 shadow-md">
        <div>
          <h2 className="text-sm font-bold text-slate-100 flex items-center gap-2">
            <span>Automated Verification Test Suite</span>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
              12 Required Test Cases
            </span>
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Validates all positive compilation paths, control flow loops, optimization passes, and negative syntax/semantic error catches.
          </p>
        </div>

        <button
          onClick={handleRunTests}
          disabled={running}
          className="flex items-center gap-2 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white px-4 py-2 rounded-xl text-xs font-bold shadow-md shadow-blue-600/30 active:scale-95 transition-all cursor-pointer disabled:opacity-50"
        >
          {running ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <Play className="w-3.5 h-3.5" />}
          <span>{running ? 'Executing Tests...' : 'Run All 12 Tests'}</span>
        </button>
      </div>

      {/* Tests Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
        {PRESET_PROGRAMS.map(test => {
          const passed = testResults[test.id];
          const isNegative = test.category.includes('Negative');

          return (
            <div
              key={test.id}
              className="bg-slate-900 border border-slate-800 rounded-xl p-3.5 flex flex-col justify-between shadow-sm hover:border-slate-700 transition-all"
            >
              <div>
                <div className="flex items-center justify-between gap-2 mb-1.5">
                  <span className="text-[11px] font-mono text-slate-500 font-bold">
                    Case #{String(test.id).padStart(2, '0')}
                  </span>
                  <span
                    className={`text-[10px] font-semibold px-2 py-0.5 rounded-full ${
                      isNegative
                        ? 'bg-rose-500/10 text-rose-400 border border-rose-500/20'
                        : test.category === 'Optimization'
                        ? 'bg-amber-500/10 text-amber-400 border border-amber-500/20'
                        : 'bg-blue-500/10 text-blue-400 border border-blue-500/20'
                    }`}
                  >
                    {test.category}
                  </span>
                </div>

                <h4 className="text-xs font-bold text-slate-200 mb-1 leading-snug">
                  {test.name}
                </h4>
                <p className="text-[11px] text-slate-400 leading-normal mb-3">
                  {test.description}
                </p>
              </div>

              {/* Status footer */}
              <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between text-xs font-mono">
                {hasRun ? (
                  passed ? (
                    <div className="flex items-center gap-1.5 text-emerald-400 font-bold">
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      <span>PASS</span>
                    </div>
                  ) : (
                    <div className="flex items-center gap-1.5 text-rose-400 font-bold">
                      <XCircle className="w-3.5 h-3.5" />
                      <span>FAIL</span>
                    </div>
                  )
                ) : (
                  <div className="text-slate-500 text-[11px]">Ready to execute</div>
                )}

                {test.expectedOutput && (
                  <span className="text-[10px] text-slate-500">
                    Exp: {test.expectedOutput.join(', ')}
                  </span>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* Raw Output Log Console */}
      {hasRun && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-lg">
          <div className="bg-slate-950 px-4 py-2 border-b border-slate-800 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Terminal className="w-4 h-4 text-emerald-400" />
              <span className="text-xs font-bold uppercase tracking-wider text-slate-200">
                Test Suite Execution Output (Python test_cases.py)
              </span>
            </div>
            <span className="text-xs font-mono font-bold text-emerald-400">
              {passCount} / {PRESET_PROGRAMS.length} Tests Passed
            </span>
          </div>
          <pre className="p-4 bg-slate-950 text-xs font-mono text-slate-300 overflow-auto max-h-64 leading-relaxed whitespace-pre">
            {rawOutput}
          </pre>
        </div>
      )}
    </div>
  );
};
