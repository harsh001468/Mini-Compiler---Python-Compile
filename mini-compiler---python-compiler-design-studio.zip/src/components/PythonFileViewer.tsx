import React, { useState } from 'react';
import { FileCode, Copy, Check, Download, Folder, Code } from 'lucide-react';
import { PythonFileItem } from '../types';

interface PythonFileViewerProps {
  files: PythonFileItem[];
}

export const PythonFileViewer: React.FC<PythonFileViewerProps> = ({ files }) => {
  const [selectedFileName, setSelectedFileName] = useState<string>('lexer.py');
  const [copied, setCopied] = useState<boolean>(false);

  const selectedFile = files.find(f => f.name === selectedFileName) || files[0];

  const handleCopy = () => {
    if (selectedFile) {
      navigator.clipboard.writeText(selectedFile.content);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const handleDownloadSingle = () => {
    if (!selectedFile) return;
    const blob = new Blob([selectedFile.content], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = selectedFile.name;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const lines = selectedFile?.content.split('\n') || [];

  return (
    <div className="space-y-4">
      {/* Header Info */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 shadow-md">
        <div>
          <h2 className="text-sm font-bold text-slate-100 flex items-center gap-2">
            <Folder className="w-4 h-4 text-amber-400" />
            <span>Python Source Code Repository (<code className="text-blue-400 font-mono">mini_compiler/</code>)</span>
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            100% Pure Python implementation connecting all 6 compiler phases, Tkinter GUI, and automated test suite.
          </p>
        </div>
        <div className="text-xs text-slate-400 bg-slate-950 px-3 py-1.5 rounded-lg border border-slate-800 font-mono">
          {files.length} Project Files Ready
        </div>
      </div>

      {/* Main Layout: File list sidebar + Code viewer */}
      <div className="grid grid-cols-1 md:grid-cols-12 gap-4">
        {/* Sidebar: File List */}
        <div className="md:col-span-3 bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-lg p-2 space-y-1">
          <div className="px-3 py-2 text-[11px] font-bold uppercase tracking-wider text-slate-500">
            Project Modules
          </div>
          <div className="space-y-1 max-h-[580px] overflow-auto">
            {files.map(f => {
              const isSelected = f.name === selectedFileName;
              const isDoc = f.name.endsWith('.md');
              return (
                <button
                  key={f.name}
                  onClick={() => setSelectedFileName(f.name)}
                  className={`w-full flex items-center justify-between px-3 py-2 rounded-xl text-xs font-mono transition-all text-left cursor-pointer ${
                    isSelected
                      ? 'bg-blue-600 text-white font-bold shadow-md shadow-blue-600/30'
                      : 'text-slate-300 hover:bg-slate-800/80 hover:text-white'
                  }`}
                >
                  <div className="flex items-center gap-2 truncate">
                    <FileCode className={`w-3.5 h-3.5 shrink-0 ${isDoc ? 'text-amber-400' : 'text-blue-400'}`} />
                    <span className="truncate">{f.name}</span>
                  </div>
                  <span className={`text-[10px] ${isSelected ? 'text-blue-200' : 'text-slate-500'}`}>
                    {f.content.split('\n').length}L
                  </span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Code Content Viewer */}
        <div className="md:col-span-9 bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-lg flex flex-col h-[640px]">
          {/* Header */}
          <div className="bg-slate-950 px-4 py-2.5 border-b border-slate-800 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Code className="w-4 h-4 text-emerald-400" />
              <span className="font-mono text-xs font-bold text-slate-100">
                mini_compiler/{selectedFile?.name}
              </span>
              <span className="text-[11px] text-slate-500 font-mono">
                ({lines.length} lines • {(new Blob([selectedFile?.content || '']).size / 1024).toFixed(1)} KB)
              </span>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={handleCopy}
                className="flex items-center gap-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 px-3 py-1 rounded-lg text-xs font-medium transition-colors cursor-pointer"
              >
                {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copied ? 'Copied' : 'Copy'}</span>
              </button>

              <button
                onClick={handleDownloadSingle}
                className="flex items-center gap-1.5 bg-blue-600/80 hover:bg-blue-600 text-white px-3 py-1 rounded-lg text-xs font-medium transition-colors cursor-pointer"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Save</span>
              </button>
            </div>
          </div>

          {/* Code Viewer Body with Line Numbers */}
          <div className="flex-1 overflow-auto bg-slate-950 flex font-mono text-xs sm:text-[13px]">
            {/* Line numbers column */}
            <div className="w-12 bg-slate-950 text-slate-600 select-none py-3 pr-3 text-right border-r border-slate-800/80 font-mono text-xs shrink-0">
              {lines.map((_, idx) => (
                <div key={idx} className="leading-6">
                  {idx + 1}
                </div>
              ))}
            </div>

            {/* Code Content */}
            <pre className="p-3 text-slate-200 overflow-x-auto whitespace-pre leading-6 flex-1 font-mono selection:bg-blue-500/30">
              {selectedFile?.content}
            </pre>
          </div>
        </div>
      </div>
    </div>
  );
};
