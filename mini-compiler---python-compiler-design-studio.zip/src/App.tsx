import React, { useState, useEffect } from 'react';
import { Navbar } from './components/Navbar';
import { CompilerStudio } from './components/CompilerStudio';
import { PythonFileViewer } from './components/PythonFileViewer';
import { TestSuiteRunner } from './components/TestSuiteRunner';
import { VivaVoceGuide } from './components/VivaVoceGuide';
import { VSCodeGuide } from './components/VSCodeGuide';
import { PRESET_PROGRAMS } from './constants/presets';
import { CompileApiResponse, PythonFileItem } from './types';

export default function App() {
  const [activeTab, setActiveTab] = useState<'studio' | 'files' | 'tests' | 'viva' | 'vscode'>('studio');
  const [sourceCode, setSourceCode] = useState<string>(PRESET_PROGRAMS[0].code);
  const [compileResult, setCompileResult] = useState<CompileApiResponse | null>(null);
  const [loading, setLoading] = useState<boolean>(false);
  const [pythonFiles, setPythonFiles] = useState<PythonFileItem[]>([]);

  // Load Python files from API on mount
  useEffect(() => {
    fetch('/api/python-files')
      .then(res => res.json())
      .then(data => {
        if (data.files && Array.isArray(data.files)) {
          setPythonFiles(data.files);
        }
      })
      .catch(err => {
        console.error('Error fetching python files:', err);
      });
  }, []);

  const handleCompile = async (code: string, runVm: boolean = true) => {
    try {
      setLoading(true);
      const res = await fetch('/api/compile', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ code }),
      });

      const data = await res.json();
      setCompileResult(data);
    } catch (err: any) {
      console.error('Compilation fetch failed:', err);
      setCompileResult({
        success: false,
        phases: {
          lexical: { tokens: [], token_count: 0, errors: [] },
          syntax: { ast_dict: null, ast_tree: '', errors: [] },
          semantic: { symbol_table: [], errors: [], warnings: [] },
          intermediate: { quadruples: [], tac_text: '', quad_count: 0 },
          optimizer: { quadruples: [], tac_text: '', records: [], original_count: 0, optimized_count: 0, reduction_percent: 0 },
          target_code: { instructions: [], assembly_text: '', data_variables: {} },
        },
        errors: [{ phase: 'Connection', line: 1, column: 1, message: err.message || 'Server connection error' }],
        warnings: [],
        execution_output: [],
        execution_memory: {},
        execution_cycles: 0,
        error_phase: 'Connection',
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-blue-600/30 selection:text-white">
      {/* Top Navigation */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        pythonFiles={pythonFiles}
      />

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 sm:p-6">
        {activeTab === 'studio' && (
          <CompilerStudio
            compileResult={compileResult}
            loading={loading}
            onCompile={handleCompile}
            sourceCode={sourceCode}
            setSourceCode={setSourceCode}
          />
        )}

        {activeTab === 'files' && (
          <PythonFileViewer files={pythonFiles} />
        )}

        {activeTab === 'tests' && (
          <TestSuiteRunner />
        )}

        {activeTab === 'viva' && (
          <VivaVoceGuide />
        )}

        {activeTab === 'vscode' && (
          <VSCodeGuide />
        )}
      </main>

      {/* Footer */}
      <footer className="bg-slate-900/60 border-t border-slate-800/80 py-4 px-6 text-center text-xs text-slate-500">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-2">
          <div>
            <strong className="text-slate-400">Mini Compiler – Design and Implementation Using Python</strong> • B.Tech 2nd Year (AI & DS / CSE)
          </div>
          <div className="flex items-center gap-4 text-slate-400">
            <span>Lexical • Syntax • Semantic • TAC • Optimizer • Target Code</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
