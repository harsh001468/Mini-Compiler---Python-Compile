export interface TokenItem {
  type: string;
  value: string;
  line: number;
  column: number;
}

export interface ASTNodeItem {
  node_type: string;
  line?: number;
  column?: number;
  [key: string]: any;
}

export interface SymbolItem {
  name: string;
  type: string;
  line: number;
  scope: number;
  initialized: boolean;
  value: any;
}

export interface QuadrupleItem {
  op: string;
  arg1: string;
  arg2: string;
  result: string;
  tac: string;
}

export interface OptimizationRecordItem {
  type: string;
  details: string;
  before: string;
  after: string;
}

export interface AssemblyInstructionItem {
  label: string | null;
  op: string;
  args: string[];
  comment: string;
  text: string;
}

export interface CompilerPhaseResults {
  lexical: {
    tokens: TokenItem[];
    token_count: number;
    errors: any[];
  };
  syntax: {
    ast_dict: ASTNodeItem | null;
    ast_tree: string;
    errors: any[];
  };
  semantic: {
    symbol_table: SymbolItem[];
    errors: any[];
    warnings: any[];
  };
  intermediate: {
    quadruples: QuadrupleItem[];
    tac_text: string;
    quad_count: number;
  };
  optimizer: {
    quadruples: QuadrupleItem[];
    tac_text: string;
    records: OptimizationRecordItem[];
    original_count: number;
    optimized_count: number;
    reduction_percent: number;
  };
  target_code: {
    instructions: AssemblyInstructionItem[];
    assembly_text: string;
    data_variables: Record<string, string>;
  };
}

export interface CompileApiResponse {
  success: boolean;
  phases: CompilerPhaseResults;
  errors: Array<{
    phase?: string;
    message: string;
    line: number;
    column: number;
    char?: string;
  }>;
  warnings: Array<{
    phase?: string;
    message: string;
    line: number;
    column: number;
  }>;
  execution_output: string[];
  execution_memory: Record<string, any>;
  execution_cycles: number;
  error_phase?: string;
}

export interface PresetProgram {
  id: number;
  name: string;
  category: string;
  description: string;
  code: string;
  expectedOutput?: string[];
}

export interface PythonFileItem {
  name: string;
  path: string;
  content: string;
}

export interface VivaQuestion {
  id: number;
  question: string;
  category: string;
  answer: string;
  codeSnippet?: string;
}
